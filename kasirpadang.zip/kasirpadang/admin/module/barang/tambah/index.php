<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php $productCategories = $lihat->kategori(); ?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading inventory-page-heading">
			<div><p class="dashboard-eyebrow">Inventaris &amp; katalog</p><h1>Tambah Produk</h1></div>
		</div>

		<?php
			$inventoryErrors = array(
				'validation' => 'Periksa kembali nama, kategori, harga, satuan, dan stok.',
				'duplicate' => 'ID barang sudah digunakan. Muat ulang halaman untuk mendapatkan ID terbaru.',
				'image' => 'Foto produk gagal diunggah. Gunakan gambar JPG, JPEG, PNG, atau WebP maksimal 2 MB.'
			);
			$errorCode = isset($_GET['error']) && is_string($_GET['error']) ? $_GET['error'] : '';
			if (isset($inventoryErrors[$errorCode])) {
		?>
			<div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($inventoryErrors[$errorCode], ENT_QUOTES, 'UTF-8');?></div>
		<?php } ?>

		<div class="dashboard-card inventory-form-card">
			<form action="fungsi/tambah/tambah.php?barang=tambah" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field();?>
				<div class="inventory-create-grid">
					<div class="form-group">
						<label for="productId">ID Barang</label>
						<input type="text" id="productId" name="id" class="form-control" value="<?php echo htmlspecialchars($lihat->barang_id(), ENT_QUOTES, 'UTF-8');?>" readonly required>
					</div>
					<div class="form-group">
						<label for="productCategory">Kategori</label>
						<select id="productCategory" name="kategori" class="form-control" required>
							<option value="" selected disabled>Pilih kategori</option>
							<?php foreach ($productCategories as $category) { ?>
								<option value="<?php echo (int) $category['id_kategori'];?>"><?php echo htmlspecialchars($category['nama_kategori'], ENT_QUOTES, 'UTF-8');?></option>
							<?php } ?>
						</select>
						<?php if (!$productCategories) { ?><small class="text-danger">Belum ada kategori. <a href="index.php?page=kategori&amp;aksi=tambah">Tambah kategori</a> terlebih dahulu.</small><?php } ?>
					</div>
					<div class="form-group">
						<label for="productName">Nama Barang</label>
						<input type="text" id="productName" name="nama" class="form-control" maxlength="255" required>
					</div>
					<div class="form-group">
						<label for="productBrand">Merek</label>
						<input type="text" id="productBrand" name="merk" class="form-control" maxlength="255" required>
					</div>
					<div class="form-group">
						<label for="purchasePrice">Harga Beli</label>
						<input type="number" id="purchasePrice" name="beli" class="form-control" min="0" step="1" required>
					</div>
					<div class="form-group">
						<label for="sellingPrice">Harga Jual</label>
						<input type="number" id="sellingPrice" name="jual" class="form-control" min="0" step="1" required>
					</div>
					<div class="form-group">
						<label for="productStock">Stok Awal</label>
						<input type="number" id="productStock" name="stok" class="form-control" min="0" step="1" required>
					</div>
					<div class="form-group">
						<label for="productUnit">Satuan</label>
						<select id="productUnit" name="satuan" class="form-control" required>
							<option value="" selected disabled>Pilih satuan</option>
							<?php foreach (array('PCS', 'RIM', 'KOTAK', 'PAK', 'LUSIN', 'BATANG', 'BOTOL', 'SET', 'BOX', 'ROLL') as $unit) { ?>
								<option value="<?php echo $unit;?>"><?php echo htmlspecialchars(ucfirst(strtolower($unit)), ENT_QUOTES, 'UTF-8');?></option>
							<?php } ?>
						</select>
					</div>
					<div class="form-group inventory-create-image">
						<label for="newProductImage">Foto Produk (opsional)</label>
						<div class="product-image-upload">
							<img class="product-image-preview" id="newProductImagePreview" src="assets/img/produk/default-atk.svg" alt="Pratinjau foto produk">
							<input type="file" class="form-control" id="newProductImage" name="gambar" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" data-product-image-input data-preview-target="#newProductImagePreview">
							<small>JPG, JPEG, PNG, atau WebP; maksimal 2 MB.</small>
						</div>
					</div>
					<div class="form-group inventory-create-description">
						<label for="productDescription">Deskripsi (opsional)</label>
						<textarea id="productDescription" name="deskripsi" class="form-control" maxlength="4000" rows="3"></textarea>
					</div>
				</div>
				<div class="inventory-form-actions">
					<a class="btn btn-default" href="index.php?page=barang<?php echo isset($_GET['stok']) && $_GET['stok'] === 'yes' ? '&amp;stok=yes' : '';?>">Batal</a>
					<button type="submit" class="btn btn-primary" <?php echo !$productCategories ? 'disabled' : '';?>><i class="fa fa-check" aria-hidden="true"></i> Simpan Produk</button>
				</div>
			</form>
		</div>
	</section>
</section>
