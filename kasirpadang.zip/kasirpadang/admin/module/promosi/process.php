<?php
require __DIR__ . '/../../../fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses ditolak.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	http_response_code(405);
	exit('Metode permintaan tidak diizinkan.');
}
if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code(403);
	exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
}
require __DIR__ . '/../../../config.php';
require_once __DIR__ . '/../../../fungsi/customer_workflows.php';

$action = (string) ($_POST['action'] ?? '');
$voucherId = filter_var($_POST['voucher_id'] ?? 0, FILTER_VALIDATE_INT);
if ($voucherId === false || $voucherId < 0 || !in_array($action, array('save', 'deactivate'), true)) {
	header('Location: ../../../index.php?page=promosi&result=invalid');
	exit;
}

try {
	$config->beginTransaction();
	if ($action === 'deactivate') {
		$beforeQuery = $config->prepare('SELECT * FROM voucher WHERE id_voucher = ? FOR UPDATE');
		$beforeQuery->execute(array((int) $voucherId));
		$before = $beforeQuery->fetch(PDO::FETCH_ASSOC);
		if (!$before || !(int) $before['is_active']) {
			$config->rollBack();
			header('Location: ../../../index.php?page=promosi&result=invalid');
			exit;
		}
		$config->prepare('UPDATE voucher SET is_active = 0, tanggal_update = ? WHERE id_voucher = ?')
			->execute(array(date('Y-m-d H:i:s'), (int) $voucherId));
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Deactivate voucher', 'voucher', (int) $voucherId, array('is_active' => 1), array('is_active' => 0));
		$config->commit();
		header('Location: ../../../index.php?page=promosi&result=deactivated');
		exit;
	}

	$code = strtoupper(trim((string) ($_POST['kode'] ?? '')));
	$type = (string) ($_POST['jenis_diskon'] ?? '');
	$value = filter_var($_POST['nilai_diskon'] ?? null, FILTER_VALIDATE_INT);
	$minimum = filter_var($_POST['minimal_pembelian'] ?? null, FILTER_VALIDATE_INT);
	$maximumInput = trim((string) ($_POST['maksimal_potongan'] ?? ''));
	$maximum = $maximumInput === '' ? null : filter_var($maximumInput, FILTER_VALIDATE_INT);
	$quotaInput = trim((string) ($_POST['kuota_total'] ?? ''));
	$quota = $quotaInput === '' ? null : filter_var($quotaInput, FILTER_VALIDATE_INT);
	$perCustomer = filter_var($_POST['batas_per_pelanggan'] ?? null, FILTER_VALIDATE_INT);
	$startInput = (string) ($_POST['tanggal_mulai'] ?? '');
	$endInput = (string) ($_POST['tanggal_berakhir'] ?? '');
	$startDate = DateTime::createFromFormat('Y-m-d\TH:i', $startInput);
	$endDate = DateTime::createFromFormat('Y-m-d\TH:i', $endInput);
	$validDate = $startDate && $endDate
		&& $startDate->format('Y-m-d\TH:i') === $startInput
		&& $endDate->format('Y-m-d\TH:i') === $endInput
		&& $startDate < $endDate;
	$isValid = preg_match('/^[A-Z0-9_-]{3,40}$/', $code) === 1
		&& in_array($type, array('fixed', 'percentage'), true)
		&& $value !== false && $value > 0
		&& $minimum !== false && $minimum >= 0
		&& ($maximum === null || ($maximum !== false && $maximum > 0))
		&& ($quota === null || ($quota !== false && $quota > 0))
		&& $perCustomer !== false && $perCustomer > 0
		&& $validDate
		&& ($type !== 'percentage' || $value <= 100);
	if (!$isValid) {
		$config->rollBack();
		header('Location: ../../../index.php?page=promosi&result=invalid');
		exit;
	}
	if ($type === 'fixed') {
		$maximum = null;
	}
	$isActive = !empty($_POST['is_active']) ? 1 : 0;
	$before = array();
	if ((int) $voucherId > 0) {
		$beforeQuery = $config->prepare('SELECT * FROM voucher WHERE id_voucher = ? FOR UPDATE');
		$beforeQuery->execute(array((int) $voucherId));
		$before = $beforeQuery->fetch(PDO::FETCH_ASSOC);
		if (!$before) {
			$config->rollBack();
			header('Location: ../../../index.php?page=promosi&result=invalid');
			exit;
		}
		$save = $config->prepare(
			'UPDATE voucher SET kode = ?, jenis_diskon = ?, nilai_diskon = ?, minimal_pembelian = ?,
				maksimal_potongan = ?, tanggal_mulai = ?, tanggal_berakhir = ?, kuota_total = ?,
				batas_per_pelanggan = ?, is_active = ?, tanggal_update = ? WHERE id_voucher = ?'
		);
		$save->execute(array($code, $type, $value, $minimum, $maximum, $startDate->format('Y-m-d H:i:s'),
			$endDate->format('Y-m-d H:i:s'), $quota, $perCustomer, $isActive, date('Y-m-d H:i:s'), (int) $voucherId));
		$savedId = (int) $voucherId;
	} else {
		$save = $config->prepare(
			'INSERT INTO voucher
				(kode, jenis_diskon, nilai_diskon, minimal_pembelian, maksimal_potongan, tanggal_mulai,
					tanggal_berakhir, kuota_total, batas_per_pelanggan, is_active, id_member_pembuat, tanggal_input)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
		);
		$save->execute(array($code, $type, $value, $minimum, $maximum, $startDate->format('Y-m-d H:i:s'),
			$endDate->format('Y-m-d H:i:s'), $quota, $perCustomer, $isActive, (int) $_SESSION['admin']['id_member'], date('Y-m-d H:i:s')));
		$savedId = (int) $config->lastInsertId();
	}
	customer_workflow_audit(
		$config,
		(int) $_SESSION['admin']['id_member'],
		((int) $voucherId > 0 ? 'Update' : 'Create') . ' voucher',
		'voucher',
		$savedId,
		$before ? array('kode' => $before['kode'], 'is_active' => (int) $before['is_active']) : array(),
		array('kode' => $code, 'jenis_diskon' => $type, 'nilai_diskon' => (int) $value, 'is_active' => $isActive)
	);
	$config->commit();
	header('Location: ../../../index.php?page=promosi&result=saved');
	exit;
} catch (PDOException $exception) {
	if ($config->inTransaction()) $config->rollBack();
	if ((string) $exception->getCode() === '23000') {
		header('Location: ../../../index.php?page=promosi&result=duplicate');
		exit;
	}
	error_log('Voucher save failed: ' . $exception->getMessage());
	header('Location: ../../../index.php?page=promosi&result=error');
	exit;
} catch (Throwable $exception) {
	if ($config->inTransaction()) $config->rollBack();
	error_log('Voucher save failed: ' . $exception->getMessage());
	header('Location: ../../../index.php?page=promosi&result=error');
	exit;
}
