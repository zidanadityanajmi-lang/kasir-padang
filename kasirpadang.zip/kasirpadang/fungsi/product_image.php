<?php

function product_image_placeholder($categoryName, $productName = '', $brandName = '')
{
	return 'fungsi/product_placeholder.php?' . http_build_query(array(
		'name' => substr((string) $productName, 0, 120),
		'brand' => substr((string) $brandName, 0, 80),
		'category' => substr((string) $categoryName, 0, 120)
	));
}

function save_product_image_upload($fieldName)
{
	if (!isset($_FILES[$fieldName]) || !is_array($_FILES[$fieldName]) || ($_FILES[$fieldName]['error'] ?? null) === UPLOAD_ERR_NO_FILE) {
		return null;
	}

	$file = $_FILES[$fieldName];
	if (($file['error'] ?? null) !== UPLOAD_ERR_OK
		|| empty($file['tmp_name'])
		|| !is_uploaded_file($file['tmp_name'])) {
		throw new RuntimeException('Foto produk gagal diunggah. Silakan pilih ulang file gambar.');
	}

	$fileSize = filesize($file['tmp_name']);
	if ($fileSize === false || $fileSize < 1 || $fileSize > 2 * 1024 * 1024) {
		throw new RuntimeException('Foto produk harus berukuran maksimal 2 MB.');
	}

	$fileInfo = new finfo(FILEINFO_MIME_TYPE);
	$mimeType = $fileInfo->file($file['tmp_name']);
	$extensions = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
	$imageInfo = @getimagesize($file['tmp_name']);
	if (!$imageInfo || !isset($extensions[$mimeType]) || ($imageInfo['mime'] ?? '') !== $mimeType) {
		throw new RuntimeException('Format foto produk harus JPG, JPEG, PNG, atau WebP yang valid.');
	}

	$imageDirectory = dirname(__DIR__) . '/assets/img/produk/';
	if (!is_dir($imageDirectory) && !mkdir($imageDirectory, 0755, true) && !is_dir($imageDirectory)) {
		throw new RuntimeException('Folder foto produk tidak dapat dibuat.');
	}

	$imageName = bin2hex(random_bytes(16)) . '.' . $extensions[$mimeType];
	if (!move_uploaded_file($file['tmp_name'], $imageDirectory . $imageName)) {
		throw new RuntimeException('Foto produk gagal disimpan.');
	}

	return $imageName;
}

function delete_product_image($imageName, PDO $db)
{
	$imageName = (string) $imageName;
	if ($imageName === '' || basename($imageName) !== $imageName || strpos($imageName, '\\') !== false) {
		return;
	}

	$usageQuery = $db->prepare('SELECT COUNT(*) FROM barang WHERE gambar = ?');
	$usageQuery->execute(array($imageName));
	if ((int) $usageQuery->fetchColumn() > 0) {
		return;
	}

	$imageDirectory = realpath(dirname(__DIR__) . '/assets/img/produk');
	if ($imageDirectory === false) {
		return;
	}
	$imagePath = $imageDirectory . DIRECTORY_SEPARATOR . $imageName;
	if (is_file($imagePath) && !unlink($imagePath)) {
		error_log('Unable to remove product image: ' . $imageName);
	}
}
