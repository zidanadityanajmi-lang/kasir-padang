<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/customer_account.php';
require_once __DIR__ . '/fungsi/customer_workflows.php';

$customerSession = customer_account_session();
if (!$customerSession) {
	header('Location: masuk_pelanggan.php');
	exit;
}

$customerQuery = $config->prepare(
	"SELECT id_pelanggan, nama_pelanggan, email, no_hp, alamat, password_hash
		FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1"
);
$customerQuery->execute(array((int) $customerSession['id_pelanggan']));
$customer = $customerQuery->fetch(PDO::FETCH_ASSOC);
if (!$customer) {
	unset($_SESSION['customer']);
	header('Location: masuk_pelanggan.php?error=inactive');
	exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
		$error = 'Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.';
	} elseif (($_POST['action'] ?? '') === 'profile') {
		$name = trim((string) ($_POST['nama_pelanggan'] ?? ''));
		$phone = trim((string) ($_POST['no_hp'] ?? ''));
		$address = trim((string) ($_POST['alamat'] ?? ''));
		if ($name === '' || strlen($name) > 120 || !customer_account_phone_is_valid($phone)
			|| strlen($phone) > 30 || strlen($address) > 2000) {
			$error = 'Periksa kembali nama, nomor WhatsApp, dan alamat.';
		} else {
			$update = $config->prepare('UPDATE pelanggan SET nama_pelanggan = ?, no_hp = ?, alamat = ?, tanggal_update = ? WHERE id_pelanggan = ?');
			$update->execute(array($name, $phone, $address !== '' ? $address : null, date('Y-m-d H:i:s'), (int) $customer['id_pelanggan']));
			customer_workflow_audit($config, null, 'Update customer profile', 'pelanggan', (int) $customer['id_pelanggan'], array(), array('nama_pelanggan' => $name));
			$_SESSION['customer']['nama_pelanggan'] = $name;
			$_SESSION['customer']['no_hp'] = $phone;
			$_SESSION['customer']['alamat'] = $address;
			header('Location: profil_pelanggan.php?success=profile');
			exit;
		}
	} elseif (($_POST['action'] ?? '') === 'password') {
		$currentPassword = (string) ($_POST['current_password'] ?? '');
		$newPassword = (string) ($_POST['new_password'] ?? '');
		$confirmation = (string) ($_POST['new_password_confirmation'] ?? '');
		if (!password_verify($currentPassword, $customer['password_hash'])
			|| strlen($newPassword) < 8 || strlen($newPassword) > 4096 || $newPassword !== $confirmation) {
			$error = 'Password saat ini tidak cocok atau password baru tidak valid.';
		} else {
			$update = $config->prepare('UPDATE pelanggan SET password_hash = ?, tanggal_update = ? WHERE id_pelanggan = ?');
			$update->execute(array(password_hash($newPassword, PASSWORD_DEFAULT), date('Y-m-d H:i:s'), (int) $customer['id_pelanggan']));
			customer_workflow_audit($config, null, 'Change customer password', 'pelanggan', (int) $customer['id_pelanggan']);
			session_regenerate_id(true);
			header('Location: profil_pelanggan.php?success=password');
			exit;
		}
	} elseif (($_POST['action'] ?? '') === 'address_add') {
		$label = trim((string) ($_POST['label'] ?? ''));
		$recipient = trim((string) ($_POST['nama_penerima'] ?? ''));
		$phone = trim((string) ($_POST['no_hp_alamat'] ?? ''));
		$address = trim((string) ($_POST['alamat_lengkap'] ?? ''));
		if ($label === '' || strlen($label) > 60 || $recipient === '' || strlen($recipient) > 120
			|| !customer_account_phone_is_valid($phone) || strlen($phone) > 30
			|| $address === '' || strlen($address) > 2000) {
			$error = 'Lengkapi label, nama penerima, nomor WhatsApp, dan alamat dengan benar.';
		} else {
			$config->beginTransaction();
			try {
				$countAddresses = $config->prepare('SELECT COUNT(*) FROM pelanggan_alamat WHERE id_pelanggan = ?');
				$countAddresses->execute(array((int) $customer['id_pelanggan']));
				$isDefault = (int) $countAddresses->fetchColumn() === 0 || !empty($_POST['is_default']);
				if ($isDefault) {
					$config->prepare('UPDATE pelanggan_alamat SET is_default = 0 WHERE id_pelanggan = ?')
						->execute(array((int) $customer['id_pelanggan']));
				}
				$insertAddress = $config->prepare(
					'INSERT INTO pelanggan_alamat
						(id_pelanggan, label, nama_penerima, no_hp, alamat_lengkap, is_default, tanggal_input)
						VALUES (?, ?, ?, ?, ?, ?, ?)'
				);
				$insertAddress->execute(array(
					(int) $customer['id_pelanggan'], $label, $recipient, $phone, $address,
					$isDefault ? 1 : 0, date('Y-m-d H:i:s')
				));
				customer_workflow_audit($config, null, 'Add customer address', 'pelanggan_alamat', (int) $config->lastInsertId(), array(), array('label' => $label, 'is_default' => $isDefault));
				$config->commit();
				header('Location: profil_pelanggan.php?success=address#addresses');
				exit;
			} catch (Throwable $exception) {
				if ($config->inTransaction()) $config->rollBack();
				error_log('Customer address creation failed: ' . $exception->getMessage());
				$error = 'Alamat belum dapat disimpan. Silakan coba kembali.';
			}
		}
	} elseif (($_POST['action'] ?? '') === 'address_default' || ($_POST['action'] ?? '') === 'address_delete') {
		$addressId = filter_var($_POST['address_id'] ?? null, FILTER_VALIDATE_INT);
		if ($addressId === false || $addressId < 1) {
			$error = 'Alamat yang dipilih tidak valid.';
		} elseif ($_POST['action'] === 'address_default') {
			$ownedAddress = $config->prepare('SELECT id_alamat FROM pelanggan_alamat WHERE id_alamat = ? AND id_pelanggan = ?');
			$ownedAddress->execute(array((int) $addressId, (int) $customer['id_pelanggan']));
			if (!$ownedAddress->fetchColumn()) {
				$error = 'Alamat tidak ditemukan.';
			} else {
				$config->beginTransaction();
				$config->prepare('UPDATE pelanggan_alamat SET is_default = 0 WHERE id_pelanggan = ?')
					->execute(array((int) $customer['id_pelanggan']));
				$config->prepare('UPDATE pelanggan_alamat SET is_default = 1, tanggal_update = ? WHERE id_alamat = ? AND id_pelanggan = ?')
					->execute(array(date('Y-m-d H:i:s'), (int) $addressId, (int) $customer['id_pelanggan']));
				customer_workflow_audit($config, null, 'Set default customer address', 'pelanggan_alamat', (int) $addressId, array(), array('is_default' => true));
				$config->commit();
				header('Location: profil_pelanggan.php?success=address#addresses');
				exit;
			}
		} else {
			$wasDefaultQuery = $config->prepare('SELECT is_default FROM pelanggan_alamat WHERE id_alamat = ? AND id_pelanggan = ?');
			$wasDefaultQuery->execute(array((int) $addressId, (int) $customer['id_pelanggan']));
			$wasDefault = (int) $wasDefaultQuery->fetchColumn() === 1;
			$deleteAddress = $config->prepare('DELETE FROM pelanggan_alamat WHERE id_alamat = ? AND id_pelanggan = ?');
			$deleteAddress->execute(array((int) $addressId, (int) $customer['id_pelanggan']));
			if ($deleteAddress->rowCount() > 0) {
				if ($wasDefault) {
					$nextAddress = $config->prepare('SELECT id_alamat FROM pelanggan_alamat WHERE id_pelanggan = ? ORDER BY id_alamat DESC LIMIT 1');
					$nextAddress->execute(array((int) $customer['id_pelanggan']));
					$nextAddressId = $nextAddress->fetchColumn();
					if ($nextAddressId) {
						$config->prepare('UPDATE pelanggan_alamat SET is_default = 1, tanggal_update = ? WHERE id_alamat = ?')
							->execute(array(date('Y-m-d H:i:s'), (int) $nextAddressId));
					}
				}
				customer_workflow_audit($config, null, 'Delete customer address', 'pelanggan_alamat', (int) $addressId);
			}
			header('Location: profil_pelanggan.php?success=address#addresses');
			exit;
		}
	} elseif (($_POST['action'] ?? '') === 'wishlist_remove') {
		$productId = trim((string) ($_POST['product_id'] ?? ''));
		$removeWishlist = $config->prepare('DELETE FROM daftar_wishlist WHERE id_pelanggan = ? AND id_barang = ?');
		$removeWishlist->execute(array((int) $customer['id_pelanggan'], $productId));
		customer_workflow_audit($config, null, 'Remove wishlist product', 'daftar_wishlist', $productId);
		header('Location: profil_pelanggan.php?success=wishlist#wishlist');
		exit;
	} elseif (($_POST['action'] ?? '') === 'notifications_read') {
		$notificationId = filter_var($_POST['notification_id'] ?? null, FILTER_VALIDATE_INT);
		if ($notificationId === false || $notificationId < 1) {
			$error = 'Notifikasi tidak valid.';
		} else {
			$config->prepare(
				'UPDATE notifikasi_pelanggan SET tanggal_baca = ?
					WHERE id_notifikasi = ? AND id_pelanggan = ? AND tanggal_baca IS NULL'
			)->execute(array(date('Y-m-d H:i:s'), (int) $notificationId, (int) $customer['id_pelanggan']));
			header('Location: profil_pelanggan.php?success=notification#notifications');
			exit;
		}
	} elseif (($_POST['action'] ?? '') === 'notifications_read_all') {
		$config->prepare(
			'UPDATE notifikasi_pelanggan SET tanggal_baca = ?
				WHERE id_pelanggan = ? AND tanggal_baca IS NULL'
		)->execute(array(date('Y-m-d H:i:s'), (int) $customer['id_pelanggan']));
		header('Location: profil_pelanggan.php?success=notification#notifications');
		exit;
	} elseif (($_POST['action'] ?? '') === 'cancel_request') {
		$orderId = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT);
		$reason = trim((string) ($_POST['reason'] ?? ''));
		if ($orderId === false || $orderId < 1 || $reason === '' || strlen($reason) > 1000) {
			$error = 'Pilih pesanan dan tuliskan alasan pembatalan (maksimal 1000 karakter).';
		} else {
			try {
				$config->beginTransaction();
				$cancelOrderQuery = $config->prepare('SELECT * FROM pesanan WHERE id_pesanan = ? AND id_pelanggan = ? FOR UPDATE');
				$cancelOrderQuery->execute(array((int) $orderId, (int) $customer['id_pelanggan']));
				$cancelOrder = $cancelOrderQuery->fetch(PDO::FETCH_ASSOC);
				if (!$cancelOrder || !in_array($cancelOrder['status'], array('pending', 'processing'), true)
					|| !in_array($cancelOrder['status_pengiriman'], array('pending', 'not_applicable'), true)
					|| $cancelOrder['status_pembatalan'] !== 'none') {
					throw new DomainException('Pesanan ini sudah dikirim, selesai, atau memiliki permintaan pembatalan.');
				}
				$updateCancel = $config->prepare(
					"UPDATE pesanan SET alasan_pembatalan = ?, status_pembatalan = 'pending', tanggal_permintaan_pembatalan = ?
						WHERE id_pesanan = ? AND id_pelanggan = ? AND status IN ('pending', 'processing') AND status_pembatalan = 'none'"
				);
				$updateCancel->execute(array($reason, date('Y-m-d H:i:s'), (int) $orderId, (int) $customer['id_pelanggan']));
				if ($updateCancel->rowCount() !== 1) {
					throw new DomainException('Pesanan berubah saat permintaan dikirim. Muat ulang halaman.');
				}
				customer_workflow_record_status($config, (int) $orderId, $cancelOrder['status'], $cancelOrder['status'], 'Pelanggan meminta pembatalan: ' . $reason, null, (int) $customer['id_pelanggan']);
				customer_workflow_audit($config, null, 'Request order cancellation', 'pesanan', (int) $orderId, array('status_pembatalan' => 'none'), array('status_pembatalan' => 'pending', 'alasan' => $reason));
				customer_workflow_notify($config, (int) $customer['id_pelanggan'], (int) $orderId, 'Permintaan pembatalan diterima', 'Toko akan meninjau permintaan pembatalan pesanan ' . $cancelOrder['kode_pesanan'] . '.');
				$config->commit();
				header('Location: profil_pelanggan.php?success=cancel-request#pesanan');
				exit;
			} catch (DomainException $exception) {
				if ($config->inTransaction()) $config->rollBack();
				$error = $exception->getMessage();
			} catch (Throwable $exception) {
				if ($config->inTransaction()) $config->rollBack();
				error_log('Customer cancellation request failed: ' . $exception->getMessage());
				$error = 'Permintaan pembatalan belum dapat disimpan.';
			}
		}
	} elseif (($_POST['action'] ?? '') === 'confirm_received') {
		$orderId = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT);
		try {
			$config->beginTransaction();
			$confirmOrder = $config->prepare(
				"SELECT * FROM pesanan WHERE id_pesanan = ? AND id_pelanggan = ?
					AND status = 'processing' AND status_pengiriman = 'delivered' FOR UPDATE"
			);
			$confirmOrder->execute(array($orderId === false ? 0 : (int) $orderId, (int) $customer['id_pelanggan']));
			$receivedOrder = $confirmOrder->fetch(PDO::FETCH_ASSOC);
			if (!$receivedOrder) {
				$config->rollBack();
				$error = 'Pesanan belum dapat dikonfirmasi diterima.';
			} else {
				$confirmUpdate = $config->prepare(
					"UPDATE pesanan SET status_pengiriman = 'received'
						WHERE id_pesanan = ? AND id_pelanggan = ? AND status_pengiriman = 'delivered'"
				);
				$confirmUpdate->execute(array((int) $receivedOrder['id_pesanan'], (int) $customer['id_pelanggan']));
				if ($confirmUpdate->rowCount() !== 1) {
					throw new RuntimeException('Order receipt confirmation state changed unexpectedly.');
				}
				customer_workflow_record_status($config, (int) $receivedOrder['id_pesanan'], $receivedOrder['status'], $receivedOrder['status'], 'Pelanggan mengonfirmasi pesanan telah diterima', null, (int) $customer['id_pelanggan']);
				customer_workflow_notify($config, (int) $customer['id_pelanggan'], (int) $receivedOrder['id_pesanan'], 'Pesanan diterima', 'Konfirmasi penerimaan untuk pesanan ' . $receivedOrder['kode_pesanan'] . ' telah tercatat.');
				customer_workflow_audit($config, null, 'Confirm order receipt', 'pesanan', (int) $receivedOrder['id_pesanan'], array('status_pengiriman' => 'delivered'), array('status_pengiriman' => 'received'));
				$config->commit();
				header('Location: profil_pelanggan.php?success=received#pesanan');
				exit;
			}
		} catch (Throwable $exception) {
			if ($config->inTransaction()) $config->rollBack();
			error_log('Customer receipt confirmation failed: ' . $exception->getMessage());
			$error = 'Konfirmasi penerimaan belum dapat disimpan.';
		}
	} elseif (($_POST['action'] ?? '') === 'return_request') {
		$orderId = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT);
		$reason = trim((string) ($_POST['return_reason'] ?? ''));
		$returnItemsInput = $_POST['return_items'] ?? array();
		$returnImagePath = null;
		if ($orderId === false || $orderId < 1 || $reason === '' || strlen($reason) > 2000
			|| !is_array($returnItemsInput) || empty($_FILES['return_evidence'])) {
			$error = 'Pilih produk dan jumlah retur, jelaskan alasan, lalu unggah foto bukti.';
		} else {
			try {
				$config->beginTransaction();
				$returnOrderQuery = $config->prepare(
					"SELECT * FROM pesanan WHERE id_pesanan = ? AND id_pelanggan = ? AND status = 'completed' FOR UPDATE"
				);
				$returnOrderQuery->execute(array((int) $orderId, (int) $customer['id_pelanggan']));
				$returnOrder = $returnOrderQuery->fetch(PDO::FETCH_ASSOC);
				if (!$returnOrder) {
					throw new DomainException('Retur hanya dapat diajukan untuk pesanan selesai milik akun ini.');
				}
				$completedAt = !empty($returnOrder['tanggal_selesai']) ? strtotime($returnOrder['tanggal_selesai']) : strtotime($returnOrder['tanggal_input']);
				if (!$completedAt || $completedAt < strtotime('-7 days')) {
					throw new DomainException('Batas pengajuan retur adalah 7 hari sejak pesanan selesai.');
				}
				$existingReturn = $config->prepare(
					"SELECT id_retur FROM retur_pesanan
						WHERE id_pesanan = ? AND status IN ('pending', 'approved', 'received', 'inspected', 'refunded') LIMIT 1 FOR UPDATE"
				);
				$existingReturn->execute(array((int) $orderId));
				if ($existingReturn->fetchColumn()) {
					throw new DomainException('Pesanan ini sudah memiliki permintaan retur yang sedang diproses.');
				}

				$returnDetailsQuery = $config->prepare(
					'SELECT id_barang, nama_barang, jumlah FROM detail_pesanan WHERE id_pesanan = ? FOR UPDATE'
				);
				$returnDetailsQuery->execute(array((int) $orderId));
				$orderLines = array();
				foreach ($returnDetailsQuery->fetchAll(PDO::FETCH_ASSOC) as $line) {
					$orderLines[(string) $line['id_barang']] = $line;
				}
				$requestedItems = array();
				foreach ($returnItemsInput as $itemId => $requestedQuantity) {
					$requestedQuantity = filter_var($requestedQuantity, FILTER_VALIDATE_INT);
					if ($requestedQuantity === false || $requestedQuantity < 0) {
						throw new DomainException('Jumlah retur tidak valid.');
					}
					if ($requestedQuantity === 0) continue;
					if (!isset($orderLines[(string) $itemId]) || $requestedQuantity > (int) $orderLines[(string) $itemId]['jumlah']) {
						throw new DomainException('Jumlah retur melebihi produk yang tercatat dalam pesanan.');
					}
					$requestedItems[] = array(
						'id_barang' => (string) $itemId,
						'nama_barang' => (string) $orderLines[(string) $itemId]['nama_barang'],
						'jumlah' => $requestedQuantity
					);
				}
				if (!$requestedItems) {
					throw new DomainException('Pilih setidaknya satu produk dengan jumlah retur lebih dari nol.');
				}

				$file = $_FILES['return_evidence'];
				if ($file['error'] !== UPLOAD_ERR_OK || (int) $file['size'] < 1 || (int) $file['size'] > 5 * 1024 * 1024
					|| !is_uploaded_file($file['tmp_name']) || !function_exists('finfo_open')) {
					throw new DomainException('Foto bukti harus berukuran maksimal 5 MB dan berformat JPG, PNG, atau WebP.');
				}
				$fileInfo = finfo_open(FILEINFO_MIME_TYPE);
				$mimeType = $fileInfo ? finfo_file($fileInfo, $file['tmp_name']) : false;
				if ($fileInfo) finfo_close($fileInfo);
				$extensions = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp');
				$imageInfo = @getimagesize($file['tmp_name']);
				if (!isset($extensions[$mimeType]) || !$imageInfo || !isset($imageInfo['mime']) || $imageInfo['mime'] !== $mimeType) {
					throw new DomainException('Format foto bukti tidak valid. Gunakan JPG, PNG, atau WebP.');
				}
				$evidenceRoot = getenv('RETURN_EVIDENCE_DIR');
				$uploadDirectory = $evidenceRoot ? rtrim($evidenceRoot, DIRECTORY_SEPARATOR) : sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'atk-suka-suka-return-evidence';
				if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
					throw new RuntimeException('Return evidence directory could not be created.');
				}
				$fileName = bin2hex(random_bytes(20)) . '.' . $extensions[$mimeType];
				$uploadAbsolutePath = $uploadDirectory . '/' . $fileName;
				if (!move_uploaded_file($file['tmp_name'], $uploadAbsolutePath)) {
					throw new RuntimeException('Return evidence upload could not be moved.');
				}
				$insertReturn = $config->prepare(
					"INSERT INTO retur_pesanan
						(id_pesanan, id_pelanggan, alasan, bukti_foto, status, tanggal_input)
						VALUES (?, ?, ?, ?, 'pending', ?)"
				);
				$insertReturn->execute(array(
					(int) $orderId, (int) $customer['id_pelanggan'], $reason, $fileName, date('Y-m-d H:i:s')
				));
				$returnId = (int) $config->lastInsertId();
				$insertReturnDetail = $config->prepare(
					'INSERT INTO detail_retur (id_retur, id_barang, nama_barang, jumlah_diminta) VALUES (?, ?, ?, ?)'
				);
				foreach ($requestedItems as $requestedItem) {
					$insertReturnDetail->execute(array($returnId, $requestedItem['id_barang'], $requestedItem['nama_barang'], $requestedItem['jumlah']));
				}
				customer_workflow_notify($config, (int) $customer['id_pelanggan'], (int) $orderId, 'Permintaan retur diterima', 'Permintaan retur pesanan ' . $returnOrder['kode_pesanan'] . ' menunggu pemeriksaan admin.');
				customer_workflow_audit($config, null, 'Request order return', 'retur_pesanan', $returnId, array(), array('status' => 'pending', 'item_count' => count($requestedItems)));
				$config->commit();
				header('Location: profil_pelanggan.php?success=return#pesanan');
				exit;
			} catch (DomainException $exception) {
				if ($config->inTransaction()) $config->rollBack();
				if (isset($uploadAbsolutePath) && is_file($uploadAbsolutePath)) unlink($uploadAbsolutePath);
				$error = $exception->getMessage();
			} catch (Throwable $exception) {
				if ($config->inTransaction()) $config->rollBack();
				if (isset($uploadAbsolutePath) && is_file($uploadAbsolutePath)) unlink($uploadAbsolutePath);
				error_log('Customer return request failed: ' . $exception->getMessage());
				$error = 'Permintaan retur belum dapat disimpan. Silakan coba kembali.';
			}
		}
	} elseif (($_POST['action'] ?? '') === 'review') {
		$orderId = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT);
		$productId = trim((string) ($_POST['product_id'] ?? ''));
		$rating = filter_var($_POST['rating'] ?? null, FILTER_VALIDATE_INT);
		$reviewText = trim((string) ($_POST['review'] ?? ''));
		$eligibleOrder = $config->prepare(
			"SELECT p.id_pesanan FROM pesanan p
				INNER JOIN detail_pesanan d ON d.id_pesanan = p.id_pesanan
				WHERE p.id_pesanan = ? AND p.id_pelanggan = ? AND p.status = 'completed' AND d.id_barang = ? LIMIT 1"
		);
		$eligibleOrder->execute(array($orderId === false ? 0 : (int) $orderId, (int) $customer['id_pelanggan'], $productId));
		if (!$eligibleOrder->fetchColumn() || $rating === false || $rating < 1 || $rating > 5
			|| $reviewText === '' || strlen($reviewText) > 2000) {
			$error = 'Ulasan hanya dapat dikirim untuk produk yang sudah dibeli, dengan rating 1–5 dan teks maksimal 2000 karakter.';
		} else {
			$config->beginTransaction();
			try {
				$saveReview = $config->prepare(
					"INSERT INTO ulasan_produk (id_pelanggan, id_pesanan, id_barang, rating, ulasan, status, tanggal_input)
						VALUES (?, ?, ?, ?, ?, 'pending', ?)
						ON DUPLICATE KEY UPDATE rating = VALUES(rating), ulasan = VALUES(ulasan), status = 'pending',
							catatan_moderasi = NULL, tanggal_update = VALUES(tanggal_input)"
				);
				$saveReview->execute(array((int) $customer['id_pelanggan'], (int) $orderId, $productId, (int) $rating, $reviewText, date('Y-m-d H:i:s')));
				customer_workflow_audit($config, null, 'Submit product review', 'ulasan_produk', $orderId . ':' . $productId, array(), array('rating' => (int) $rating, 'status' => 'pending'));
				$config->commit();
				header('Location: profil_pelanggan.php?success=review#pesanan');
				exit;
			} catch (Throwable $exception) {
				if ($config->inTransaction()) $config->rollBack();
				error_log('Customer product review submission failed: ' . $exception->getMessage());
				$error = 'Ulasan belum dapat disimpan. Silakan coba kembali.';
			}
		}
	} else {
		$error = 'Aksi tidak dikenali.';
	}
}

$pageSize = 10;
$orderPage = filter_var($_GET['hal'] ?? 1, FILTER_VALIDATE_INT);
$orderPage = $orderPage === false ? 1 : max(1, $orderPage);
$countOrders = $config->prepare('SELECT COUNT(*) FROM pesanan WHERE id_pelanggan = ?');
$countOrders->execute(array((int) $customer['id_pelanggan']));
$orderCount = (int) $countOrders->fetchColumn();
$orderPages = max(1, (int) ceil($orderCount / $pageSize));
$orderPage = min($orderPage, $orderPages);
$ordersQuery = $config->prepare(
	'SELECT id_pesanan, kode_pesanan, total, subtotal_produk, diskon_voucher, kode_voucher,
			status, status_pembayaran, status_pengiriman, jasa_pengiriman, nomor_resi,
			status_pembatalan, alasan_pembatalan, tanggal_input, tanggal_selesai
		FROM pesanan WHERE id_pelanggan = ? ORDER BY tanggal_input DESC, id_pesanan DESC LIMIT ? OFFSET ?'
);
$ordersQuery->bindValue(1, (int) $customer['id_pelanggan'], PDO::PARAM_INT);
$ordersQuery->bindValue(2, $pageSize, PDO::PARAM_INT);
$ordersQuery->bindValue(3, ($orderPage - 1) * $pageSize, PDO::PARAM_INT);
$ordersQuery->execute();
$orders = $ordersQuery->fetchAll(PDO::FETCH_ASSOC);
$orderDetails = array();
$orderTimelines = array();
if ($orders) {
	$orderIds = array_map('intval', array_column($orders, 'id_pesanan'));
	$placeholders = implode(',', array_fill(0, count($orderIds), '?'));
	$detailQuery = $config->prepare(
		'SELECT id_pesanan, id_barang, nama_barang, jumlah, subtotal FROM detail_pesanan
			WHERE id_pesanan IN (' . $placeholders . ') ORDER BY id_pesanan, nama_barang'
	);
	$detailQuery->execute($orderIds);
	foreach ($detailQuery->fetchAll(PDO::FETCH_ASSOC) as $detail) {
		$orderDetails[(int) $detail['id_pesanan']][] = $detail;
	}
	$historyQuery = $config->prepare(
		'SELECT id_pesanan, status_sebelum, status_sesudah, catatan, tanggal_input
			FROM riwayat_status_pesanan WHERE id_pesanan IN (' . $placeholders . ')
			ORDER BY id_pesanan, tanggal_input DESC, id_riwayat_status DESC'
	);
	$historyQuery->execute($orderIds);
	foreach ($historyQuery->fetchAll(PDO::FETCH_ASSOC) as $history) {
		$orderTimelines[(int) $history['id_pesanan']][] = $history;
	}
}
$addressListQuery = $config->prepare(
	'SELECT id_alamat, label, nama_penerima, no_hp, alamat_lengkap, is_default
		FROM pelanggan_alamat WHERE id_pelanggan = ? ORDER BY is_default DESC, id_alamat DESC'
);
$addressListQuery->execute(array((int) $customer['id_pelanggan']));
$customerAddresses = $addressListQuery->fetchAll(PDO::FETCH_ASSOC);
$wishlistQuery = $config->prepare(
	'SELECT b.id_barang, b.nama_barang, b.merk, b.harga_jual, b.satuan_barang, b.stok
		FROM daftar_wishlist w INNER JOIN barang b ON b.id_barang = w.id_barang
		WHERE w.id_pelanggan = ? ORDER BY w.tanggal_input DESC'
);
$wishlistQuery->execute(array((int) $customer['id_pelanggan']));
$wishlistProducts = $wishlistQuery->fetchAll(PDO::FETCH_ASSOC);
$notificationQuery = $config->prepare(
	'SELECT id_notifikasi, id_pesanan, judul, pesan, tanggal_baca, tanggal_input
		FROM notifikasi_pelanggan WHERE id_pelanggan = ? ORDER BY id_notifikasi DESC LIMIT 50'
);
$notificationQuery->execute(array((int) $customer['id_pelanggan']));
$customerNotifications = $notificationQuery->fetchAll(PDO::FETCH_ASSOC);
$unreadNotificationQuery = $config->prepare('SELECT COUNT(*) FROM notifikasi_pelanggan WHERE id_pelanggan = ? AND tanggal_baca IS NULL');
$unreadNotificationQuery->execute(array((int) $customer['id_pelanggan']));
$unreadNotificationCount = (int) $unreadNotificationQuery->fetchColumn();
$reviewQuery = $config->prepare(
	'SELECT id_pesanan, id_barang, rating, ulasan, status FROM ulasan_produk WHERE id_pelanggan = ?'
);
$reviewQuery->execute(array((int) $customer['id_pelanggan']));
$customerReviews = array();
foreach ($reviewQuery->fetchAll(PDO::FETCH_ASSOC) as $review) {
	$customerReviews[(int) $review['id_pesanan'] . ':' . $review['id_barang']] = $review;
}
$orderReturns = array();
$returnDetails = array();
$orderRefunds = array();
$orderRefundHistories = array();
if ($orders) {
	$returnQuery = $config->prepare(
		'SELECT id_retur, id_pesanan, alasan, bukti_foto, status, catatan_admin, tanggal_input
			FROM retur_pesanan WHERE id_pesanan IN (' . $placeholders . ')
			ORDER BY id_pesanan, tanggal_input DESC'
	);
	$returnQuery->execute($orderIds);
	$returnIds = array();
	foreach ($returnQuery->fetchAll(PDO::FETCH_ASSOC) as $returnRow) {
		$returnRow['details'] = array();
		$orderReturns[(int) $returnRow['id_pesanan']][] = $returnRow;
		$returnIds[] = (int) $returnRow['id_retur'];
	}
	if ($returnIds) {
		$returnPlaceholders = implode(',', array_fill(0, count($returnIds), '?'));
		$returnDetailQuery = $config->prepare(
			'SELECT id_retur, nama_barang, jumlah_diminta, jumlah_diterima, jumlah_stok_dikembalikan
				FROM detail_retur WHERE id_retur IN (' . $returnPlaceholders . ') ORDER BY id_retur, nama_barang'
		);
		$returnDetailQuery->execute($returnIds);
		foreach ($returnDetailQuery->fetchAll(PDO::FETCH_ASSOC) as $returnDetail) {
			$returnDetails[(int) $returnDetail['id_retur']][] = $returnDetail;
		}
	}
	$refundQuery = $config->prepare(
		'SELECT id_pengembalian_dana, id_pesanan, nominal, tanggal_refund, metode_refund,
				referensi_transaksi, status, catatan_admin
			FROM pengembalian_dana WHERE id_pesanan IN (' . $placeholders . ')'
	);
	$refundQuery->execute($orderIds);
	foreach ($refundQuery->fetchAll(PDO::FETCH_ASSOC) as $refundRow) {
		$orderRefunds[(int) $refundRow['id_pesanan']] = $refundRow;
	}
	$refundHistoryQuery = $config->prepare(
		'SELECT history.*, refund.id_pesanan
			FROM riwayat_pengembalian_dana history
			INNER JOIN pengembalian_dana refund ON refund.id_pengembalian_dana = history.id_pengembalian_dana
			WHERE refund.id_pesanan IN (' . $placeholders . ')
			ORDER BY refund.id_pesanan, history.tanggal_input'
	);
	$refundHistoryQuery->execute($orderIds);
	foreach ($refundHistoryQuery->fetchAll(PDO::FETCH_ASSOC) as $refundHistoryRow) {
		$orderRefundHistories[(int) $refundHistoryRow['id_pesanan']][] = $refundHistoryRow;
	}
}
$orderStatusLabels = array('pending' => 'Menunggu', 'processing' => 'Diproses', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan');
$paymentStatusLabels = array('pending' => 'Menunggu konfirmasi', 'paid' => 'Terverifikasi', 'refund_pending' => 'Pengembalian dana sedang diproses', 'partially_refunded' => 'Pengembalian dana sebagian', 'refunded' => 'Dana telah dikembalikan');
$shipmentStatusLabels = array('pending' => 'Menunggu diproses', 'shipped' => 'Dalam pengiriman', 'delivered' => 'Terkirim', 'received' => 'Diterima', 'not_applicable' => 'Ambil di toko');
$returnStatusLabels = array('pending' => 'Menunggu persetujuan', 'approved' => 'Disetujui · menunggu barang diperiksa', 'received' => 'Barang diterima · menunggu pemeriksaan', 'inspected' => 'Barang diperiksa', 'rejected' => 'Permintaan ditolak', 'refunded' => 'Retur selesai');
$refundStatusLabels = array('waiting' => 'Menunggu', 'processing' => 'Diproses', 'success' => 'Berhasil', 'rejected' => 'Ditolak');
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Profil &amp; Pesanan | ATK Suka Suka</title>
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css" rel="stylesheet">
</head>
<body>
	<div class="shop-promo"><div class="shop-container shop-promo-inner"><span>Halo, <?php echo customer_account_escape($customer['nama_pelanggan']);?></span><a href="#notifications">Notifikasi<?php echo $unreadNotificationCount ? ' (' . $unreadNotificationCount . ')' : '';?></a><a href="logout_pelanggan.php">Keluar</a></div></div>
	<header class="shop-header"><div class="shop-container shop-header-inner">
		<a class="shop-brand" href="katalog_pelanggan.php"><span class="shop-brand-mark"><i class="fa fa-pencil" aria-hidden="true"></i></span><span><strong>ATK Suka Suka</strong><small>Lengkap, Murah, dan Berkualitas</small></span></a>
		<nav class="shop-navigation" aria-label="Navigasi utama"><a href="katalog_pelanggan.php">Beranda</a><a href="katalog_pelanggan.php#produk">Produk</a><a href="katalog_pelanggan.php#transaksi">Transaksi</a><a href="profil_pelanggan.php" aria-current="page">Profil &amp; Pesanan</a></nav>
	</div></header>
	<main class="shop-container order-history-page">
		<div class="section-heading"><div><span class="section-kicker">Akun pelanggan</span><h1>Profil &amp; Riwayat Pesanan</h1><p>Perbarui informasi kontak dan pantau status pesanan Anda.</p></div></div>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'registered') { ?><div class="shop-notice" role="status">Akun berhasil dibuat.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'profile') { ?><div class="shop-notice" role="status">Profil berhasil diperbarui.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'password') { ?><div class="shop-notice" role="status">Password berhasil diperbarui.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'address') { ?><div class="shop-notice" role="status">Perubahan alamat berhasil disimpan.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'wishlist') { ?><div class="shop-notice" role="status">Wishlist diperbarui.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'cancel-request') { ?><div class="shop-notice" role="status">Permintaan pembatalan telah dikirim dan menunggu tinjauan toko.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'review') { ?><div class="shop-notice" role="status">Ulasan dikirim untuk moderasi sebelum ditampilkan.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'received') { ?><div class="shop-notice" role="status">Konfirmasi penerimaan pesanan tercatat.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'notification') { ?><div class="shop-notice" role="status">Status notifikasi diperbarui.</div><?php } ?>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'return') { ?><div class="shop-notice" role="status">Permintaan retur dan bukti foto berhasil dikirim untuk ditinjau admin.</div><?php } ?>
		<?php if ($error !== '') { ?><div class="shop-notice shop-notice-danger" role="alert"><?php echo customer_account_escape($error);?></div><?php } ?>
		<section class="order-history-result">
			<h2>Informasi Profil</h2>
			<form class="order-lookup-form" method="POST" action="profil_pelanggan.php">
				<?php echo csrf_field();?><input type="hidden" name="action" value="profile">
				<label for="customerName">Nama lengkap</label>
				<input id="customerName" name="nama_pelanggan" maxlength="120" autocomplete="name" required value="<?php echo customer_account_escape($_POST['nama_pelanggan'] ?? $customer['nama_pelanggan']);?>">
				<label for="customerEmail">Email (akun)</label>
				<input id="customerEmail" type="email" value="<?php echo customer_account_escape($customer['email']);?>" disabled>
				<label for="customerPhone">Nomor WhatsApp</label>
				<input id="customerPhone" type="tel" name="no_hp" maxlength="30" autocomplete="tel" required value="<?php echo customer_account_escape($_POST['no_hp'] ?? $customer['no_hp']);?>">
				<label for="customerAddress">Alamat</label>
				<textarea id="customerAddress" name="alamat" maxlength="2000" autocomplete="street-address"><?php echo customer_account_escape($_POST['alamat'] ?? $customer['alamat']);?></textarea>
				<button class="store-button" type="submit">Simpan Profil</button>
			</form>
		</section>
		<section class="order-history-result">
			<h2>Ubah Password</h2>
			<form class="order-lookup-form" method="POST" action="profil_pelanggan.php">
				<?php echo csrf_field();?><input type="hidden" name="action" value="password">
				<label for="currentPassword">Password saat ini</label><input id="currentPassword" type="password" name="current_password" maxlength="4096" autocomplete="current-password" required>
				<label for="newPassword">Password baru (minimal 8 karakter)</label><input id="newPassword" type="password" name="new_password" minlength="8" maxlength="4096" autocomplete="new-password" required>
				<label for="newPasswordConfirmation">Ulangi password baru</label><input id="newPasswordConfirmation" type="password" name="new_password_confirmation" minlength="8" maxlength="4096" autocomplete="new-password" required>
				<button class="store-button" type="submit">Perbarui Password</button>
			</form>
		</section>
		<section class="order-history-result" id="addresses">
			<h2>Alamat Pengiriman</h2>
			<p>Alamat tersimpan hanya digunakan untuk pesanan yang Anda buat sendiri.</p>
			<?php foreach ($customerAddresses as $address) { ?>
				<div class="customer-address-card">
					<strong><?php echo customer_account_escape($address['label']);?><?php echo (int) $address['is_default'] === 1 ? ' · Utama' : '';?></strong>
					<p><?php echo customer_account_escape($address['nama_penerima']);?> · <?php echo customer_account_escape($address['no_hp']);?><br><?php echo nl2br(customer_account_escape($address['alamat_lengkap']));?></p>
					<?php if (!(int) $address['is_default']) { ?>
						<form method="POST" action="profil_pelanggan.php#addresses"><?php echo csrf_field();?><input type="hidden" name="action" value="address_default"><input type="hidden" name="address_id" value="<?php echo (int) $address['id_alamat'];?>"><button class="store-button store-button-outline" type="submit">Jadikan utama</button></form>
					<?php } ?>
					<form method="POST" action="profil_pelanggan.php#addresses" onsubmit="return confirm('Hapus alamat ini? Pesanan sebelumnya tetap menyimpan snapshot alamat.');"><?php echo csrf_field();?><input type="hidden" name="action" value="address_delete"><input type="hidden" name="address_id" value="<?php echo (int) $address['id_alamat'];?>"><button class="store-button store-button-outline" type="submit">Hapus</button></form>
				</div>
			<?php } ?>
			<form class="order-lookup-form" method="POST" action="profil_pelanggan.php#addresses">
				<?php echo csrf_field();?><input type="hidden" name="action" value="address_add">
				<label for="addressLabel">Label alamat</label><input id="addressLabel" name="label" maxlength="60" placeholder="Rumah, Kantor" required>
				<label for="addressRecipient">Nama penerima</label><input id="addressRecipient" name="nama_penerima" maxlength="120" autocomplete="name" required>
				<label for="addressPhone">Nomor WhatsApp penerima</label><input id="addressPhone" name="no_hp_alamat" type="tel" maxlength="30" autocomplete="tel" required>
				<label for="addressFull">Alamat lengkap</label><textarea id="addressFull" name="alamat_lengkap" maxlength="2000" autocomplete="street-address" required></textarea>
				<label><input type="checkbox" name="is_default" value="1"> Jadikan alamat utama</label>
				<button class="store-button" type="submit">Simpan Alamat</button>
			</form>
		</section>
		<section class="order-history-result" id="wishlist">
			<h2>Wishlist</h2>
			<?php if (!$wishlistProducts) { ?><p>Belum ada produk di wishlist.</p><?php } ?>
			<?php foreach ($wishlistProducts as $wishProduct) { ?>
				<div class="customer-address-card">
					<a href="produk.php?id=<?php echo rawurlencode((string) $wishProduct['id_barang']);?>"><strong><?php echo customer_account_escape($wishProduct['nama_barang']);?></strong></a>
					<p><?php echo customer_account_escape($wishProduct['merk']);?> · Rp <?php echo number_format((int) $wishProduct['harga_jual'], 0, ',', '.');?> · Stok <?php echo (int) $wishProduct['stok'];?></p>
					<form method="POST" action="profil_pelanggan.php#wishlist"><?php echo csrf_field();?><input type="hidden" name="action" value="wishlist_remove"><input type="hidden" name="product_id" value="<?php echo customer_account_escape($wishProduct['id_barang']);?>"><button class="store-button store-button-outline" type="submit">Hapus dari wishlist</button></form>
				</div>
			<?php } ?>
		</section>
		<section class="order-history-result" id="notifications">
			<h2>Notifikasi</h2>
			<?php if ($unreadNotificationCount > 0) { ?><form method="POST" action="profil_pelanggan.php#notifications"><?php echo csrf_field();?><input type="hidden" name="action" value="notifications_read_all"><button class="store-button store-button-outline" type="submit">Tandai semua dibaca</button></form><?php } ?>
			<?php if (!$customerNotifications) { ?><p>Belum ada notifikasi.</p><?php } ?>
			<?php foreach ($customerNotifications as $notification) { ?>
				<div class="customer-address-card">
					<strong><?php echo customer_account_escape($notification['judul']);?><?php echo empty($notification['tanggal_baca']) ? ' · Baru' : '';?></strong>
					<p><?php echo customer_account_escape($notification['pesan']);?><br><small><?php echo customer_account_escape($notification['tanggal_input']);?></small></p>
					<?php if (empty($notification['tanggal_baca'])) { ?>
						<form method="POST" action="profil_pelanggan.php#notifications"><?php echo csrf_field();?><input type="hidden" name="action" value="notifications_read"><input type="hidden" name="notification_id" value="<?php echo (int) $notification['id_notifikasi'];?>"><button class="store-button store-button-outline" type="submit">Tandai dibaca</button></form>
					<?php } ?>
				</div>
			<?php } ?>
		</section>
		<section class="order-history-result" id="pesanan">
			<div class="section-heading"><div><span class="section-kicker">Transaksi Anda</span><h2>Riwayat Pesanan</h2></div></div>
			<?php if (!$orders) { ?><p>Belum ada pesanan yang terhubung ke akun ini. <a href="katalog_pelanggan.php#produk">Mulai belanja</a>.</p><?php } ?>
			<?php foreach ($orders as $order) { ?>
				<article class="order-history-result customer-order-card" data-order-id="<?php echo (int) $order['id_pesanan'];?>">
					<div class="order-history-heading">
						<div><span class="section-kicker"><?php echo customer_account_escape($order['kode_pesanan']);?></span><p><?php echo customer_account_escape($order['tanggal_input']);?></p></div>
						<span class="online-order-status status-<?php echo customer_account_escape($order['status']);?>" data-order-status><?php echo customer_account_escape($orderStatusLabels[$order['status']] ?? $order['status']);?></span>
					</div>
					<p>Status pembayaran: <strong data-payment-status><?php echo customer_account_escape($paymentStatusLabels[$order['status_pembayaran'] ?? 'pending'] ?? 'Menunggu konfirmasi');?></strong></p>
					<p>Status pengiriman: <strong data-shipping-status><?php echo customer_account_escape($shipmentStatusLabels[$order['status_pengiriman']] ?? $order['status_pengiriman']);?></strong>
						<span data-shipping-meta><?php if (!empty($order['jasa_pengiriman'])) { ?> · <?php echo customer_account_escape($order['jasa_pengiriman']);?><?php } ?><?php if (!empty($order['nomor_resi'])) { ?> · Resi: <?php echo customer_account_escape($order['nomor_resi']);?><?php } ?></span>
					</p>
					<?php if ($order['status_pembatalan'] === 'pending') { ?><p>Permintaan pembatalan sedang ditinjau. Alasan: <?php echo customer_account_escape($order['alasan_pembatalan']);?></p><?php } ?>
					<?php if (!empty($orderTimelines[(int) $order['id_pesanan']])) { ?><details class="order-status-timeline"><summary>Riwayat status pesanan</summary><ol><?php foreach ($orderTimelines[(int) $order['id_pesanan']] as $history) { ?><li><strong><?php echo customer_account_escape($orderStatusLabels[$history['status_sesudah']] ?? $history['status_sesudah']);?></strong> · <?php echo customer_account_escape($history['tanggal_input']);?><?php if (!empty($history['catatan'])) { ?><br><span><?php echo customer_account_escape($history['catatan']);?></span><?php } ?></li><?php } ?></ol></details><?php } ?>
					<ul><?php foreach ($orderDetails[(int) $order['id_pesanan']] ?? array() as $detail) { ?><li><?php echo customer_account_escape($detail['nama_barang']);?> × <?php echo (int) $detail['jumlah'];?> — Rp <?php echo number_format((int) $detail['subtotal'], 0, ',', '.');?></li><?php } ?></ul>
					<?php if ((int) $order['diskon_voucher'] > 0) { ?><p>Subtotal Rp <?php echo number_format((int) $order['subtotal_produk'], 0, ',', '.');?> · Voucher <?php echo customer_account_escape($order['kode_voucher']);?> −Rp <?php echo number_format((int) $order['diskon_voucher'], 0, ',', '.');?></p><?php } ?>
					<div class="order-history-total"><span>Total pembayaran</span><strong>Rp <?php echo number_format((int) $order['total'], 0, ',', '.');?></strong></div>
					<?php if (isset($orderRefunds[(int) $order['id_pesanan']])) {
						$refund = $orderRefunds[(int) $order['id_pesanan']];
					?>
						<div class="customer-address-card">
							<strong>Status pengembalian dana: <?php echo customer_account_escape($refundStatusLabels[$refund['status']] ?? $refund['status']);?></strong>
							<?php if ((int) $refund['nominal'] > 0) { ?><p>Nominal Rp <?php echo number_format((int) $refund['nominal'], 0, ',', '.');?> · <?php echo customer_account_escape($refund['metode_refund']);?> · Tanggal <?php echo customer_account_escape($refund['tanggal_refund']);?><?php if (!empty($refund['referensi_transaksi'])) { ?><br>Referensi: <?php echo customer_account_escape($refund['referensi_transaksi']);?><?php } ?></p><?php } ?>
							<?php if (!empty($refund['catatan_admin'])) { ?><p>Catatan admin: <?php echo customer_account_escape($refund['catatan_admin']);?></p><?php } ?>
							<?php if (!empty($orderRefundHistories[(int) $order['id_pesanan']])) { ?><details class="order-status-timeline"><summary>Riwayat status refund</summary><ol><?php foreach ($orderRefundHistories[(int) $order['id_pesanan']] as $history) { ?><li><strong><?php echo customer_account_escape($refundStatusLabels[$history['status_sesudah']] ?? $history['status_sesudah']);?></strong> · <?php echo customer_account_escape($history['tanggal_input']);?><?php if (!empty($history['catatan'])) { ?><br><span><?php echo customer_account_escape($history['catatan']);?></span><?php } ?></li><?php } ?></ol></details><?php } ?>
						</div>
					<?php } ?>
					<?php $activeReturnExists = false; ?>
					<?php foreach ($orderReturns[(int) $order['id_pesanan']] ?? array() as $returnRow) {
						if (in_array($returnRow['status'], array('pending', 'approved', 'received', 'inspected'), true)) $activeReturnExists = true;
					?>
						<div class="customer-address-card">
							<strong>Permintaan retur #<?php echo (int) $returnRow['id_retur'];?> · <?php echo customer_account_escape($returnStatusLabels[$returnRow['status']] ?? $returnRow['status']);?></strong>
							<p><?php echo customer_account_escape($returnRow['alasan']);?><br><a href="bukti_retur.php?id=<?php echo (int) $returnRow['id_retur'];?>" target="_blank" rel="noopener">Lihat foto bukti</a></p>
							<ul><?php foreach ($returnDetails[(int) $returnRow['id_retur']] ?? array() as $returnDetail) { ?><li><?php echo customer_account_escape($returnDetail['nama_barang']);?> · diminta <?php echo (int) $returnDetail['jumlah_diminta'];?>, diterima <?php echo (int) $returnDetail['jumlah_diterima'];?>, stok dikembalikan <?php echo (int) $returnDetail['jumlah_stok_dikembalikan'];?></li><?php } ?></ul>
							<?php if (!empty($returnRow['catatan_admin'])) { ?><p>Catatan admin: <?php echo customer_account_escape($returnRow['catatan_admin']);?></p><?php } ?>
						</div>
					<?php } ?>
					<?php
						$returnDeadlineBase = !empty($order['tanggal_selesai']) ? strtotime($order['tanggal_selesai']) : strtotime($order['tanggal_input']);
						$returnWithinWindow = $returnDeadlineBase && $returnDeadlineBase >= strtotime('-7 days');
					?>
					<?php if ($order['status'] === 'completed' && !$activeReturnExists && $returnWithinWindow) { ?>
						<form class="order-lookup-form customer-return-form" method="POST" action="profil_pelanggan.php#pesanan" enctype="multipart/form-data">
							<?php echo csrf_field();?><input type="hidden" name="action" value="return_request"><input type="hidden" name="order_id" value="<?php echo (int) $order['id_pesanan'];?>">
							<strong>Ajukan retur (maksimal 7 hari setelah pesanan selesai)</strong>
							<p>Pilih jumlah tiap produk yang ingin diretur. Stok baru dikembalikan setelah admin menerima dan memeriksa barang.</p>
							<?php foreach ($orderDetails[(int) $order['id_pesanan']] ?? array() as $detail) { ?>
								<label for="returnItem<?php echo (int) $order['id_pesanan'];?>-<?php echo customer_account_escape($detail['id_barang']);?>"><?php echo customer_account_escape($detail['nama_barang']);?> (dibeli <?php echo (int) $detail['jumlah'];?>)</label>
								<input id="returnItem<?php echo (int) $order['id_pesanan'];?>-<?php echo customer_account_escape($detail['id_barang']);?>" type="number" name="return_items[<?php echo customer_account_escape($detail['id_barang']);?>]" min="0" max="<?php echo (int) $detail['jumlah'];?>" value="0">
							<?php } ?>
							<label for="returnReason<?php echo (int) $order['id_pesanan'];?>">Alasan retur</label><textarea id="returnReason<?php echo (int) $order['id_pesanan'];?>" name="return_reason" maxlength="2000" required></textarea>
							<label for="returnEvidence<?php echo (int) $order['id_pesanan'];?>">Foto bukti (JPG, PNG, WebP; maksimal 5 MB)</label><input id="returnEvidence<?php echo (int) $order['id_pesanan'];?>" type="file" name="return_evidence" accept="image/jpeg,image/png,image/webp" required>
							<button class="store-button store-button-outline" type="submit">Kirim Permintaan Retur</button>
						</form>
					<?php } ?>
					<?php if ($order['status'] === 'processing' && $order['status_pengiriman'] === 'delivered') { ?>
						<form method="POST" action="profil_pelanggan.php#pesanan" onsubmit="return confirm('Konfirmasi bahwa pesanan sudah diterima?');"><?php echo csrf_field();?><input type="hidden" name="action" value="confirm_received"><input type="hidden" name="order_id" value="<?php echo (int) $order['id_pesanan'];?>"><button class="store-button" type="submit">Konfirmasi Barang Diterima</button></form>
					<?php } ?>
					<?php if (in_array($order['status'], array('pending', 'processing'), true) && in_array($order['status_pengiriman'], array('pending', 'not_applicable'), true) && $order['status_pembatalan'] === 'none') { ?>
						<form class="order-lookup-form" method="POST" action="profil_pelanggan.php#pesanan" onsubmit="return confirm('Kirim permintaan pembatalan untuk ditinjau toko?');">
							<?php echo csrf_field();?><input type="hidden" name="action" value="cancel_request"><input type="hidden" name="order_id" value="<?php echo (int) $order['id_pesanan'];?>">
							<label for="cancelReason<?php echo (int) $order['id_pesanan'];?>">Alasan meminta pembatalan</label><textarea id="cancelReason<?php echo (int) $order['id_pesanan'];?>" name="reason" maxlength="1000" required></textarea><button class="store-button store-button-outline" type="submit">Minta Pembatalan</button>
						</form>
					<?php } ?>
					<?php if ($order['status'] === 'completed') { ?>
						<div class="customer-review-forms"><h3>Ulasan Produk</h3>
							<?php foreach ($orderDetails[(int) $order['id_pesanan']] ?? array() as $detail) {
								$reviewKey = (int) $order['id_pesanan'] . ':' . $detail['id_barang'];
								$savedReview = $customerReviews[$reviewKey] ?? null;
							?>
								<form class="order-lookup-form" method="POST" action="profil_pelanggan.php#pesanan">
									<?php echo csrf_field();?><input type="hidden" name="action" value="review"><input type="hidden" name="order_id" value="<?php echo (int) $order['id_pesanan'];?>"><input type="hidden" name="product_id" value="<?php echo customer_account_escape($detail['id_barang']);?>">
									<strong><?php echo customer_account_escape($detail['nama_barang']);?></strong>
									<?php if ($savedReview) { ?><small>Ulasan sebelumnya: <?php echo customer_account_escape($savedReview['status']);?>. Mengirim kembali akan mengajukan ulang untuk moderasi.</small><?php } ?>
									<label for="rating<?php echo (int) $order['id_pesanan'] . '-' . customer_account_escape($detail['id_barang']);?>">Rating</label>
									<select id="rating<?php echo (int) $order['id_pesanan'] . '-' . customer_account_escape($detail['id_barang']);?>" name="rating" required>
										<?php for ($ratingOption = 5; $ratingOption >= 1; $ratingOption--) { ?><option value="<?php echo $ratingOption;?>" <?php echo $savedReview && (int) $savedReview['rating'] === $ratingOption ? 'selected' : '';?>><?php echo $ratingOption;?> / 5</option><?php } ?>
									</select>
									<label for="review<?php echo (int) $order['id_pesanan'] . '-' . customer_account_escape($detail['id_barang']);?>">Ulasan</label>
									<textarea id="review<?php echo (int) $order['id_pesanan'] . '-' . customer_account_escape($detail['id_barang']);?>" name="review" maxlength="2000" required><?php echo customer_account_escape($savedReview['ulasan'] ?? '');?></textarea>
									<button class="store-button store-button-outline" type="submit">Kirim Ulasan</button>
								</form>
							<?php } ?>
						</div>
					<?php } ?>
				</article>
			<?php } ?>
			<?php if ($orderPages > 1) { ?>
				<nav class="catalog-pagination" aria-label="Halaman riwayat pesanan">
					<?php if ($orderPage > 1) { ?><a class="store-button store-button-outline" href="profil_pelanggan.php?hal=<?php echo $orderPage - 1;?>#pesanan">Sebelumnya</a><?php } ?>
					<span>Halaman <?php echo $orderPage;?> dari <?php echo $orderPages;?></span>
					<?php if ($orderPage < $orderPages) { ?><a class="store-button store-button-outline" href="profil_pelanggan.php?hal=<?php echo $orderPage + 1;?>#pesanan">Berikutnya</a><?php } ?>
				</nav>
			<?php } ?>
		</section>
	</main>
	<footer class="shop-footer"><div class="shop-container footer-bottom"><a href="katalog_pelanggan.php">Kembali ke toko</a><a href="riwayat_pesanan.php">Cek pesanan tanpa akun</a></div></footer>
	<script>
		(function () {
			var cards = document.querySelectorAll('.customer-order-card[data-order-id]');
			if (!cards.length) return;
			var labels = {
				order: {pending: 'Menunggu', processing: 'Diproses', completed: 'Selesai', cancelled: 'Dibatalkan'},
				payment: {pending: 'Menunggu konfirmasi', paid: 'Terverifikasi', refund_pending: 'Pengembalian dana sedang diproses', partially_refunded: 'Pengembalian dana sebagian', refunded: 'Dana telah dikembalikan'},
				shipment: {pending: 'Menunggu diproses', shipped: 'Dalam pengiriman', delivered: 'Terkirim', received: 'Diterima', not_applicable: 'Ambil di toko'}
			};
			function refreshStatuses() {
				fetch('status_pesanan_pelanggan.php', {credentials: 'same-origin', headers: {'Accept': 'application/json'}})
					.then(function (response) {
						if (!response.ok) throw new Error('Status pesanan tidak dapat diperbarui.');
						return response.json();
					})
					.then(function (statuses) {
						cards.forEach(function (card) {
							var order = statuses[card.getAttribute('data-order-id')];
							if (!order) return;
							var orderStatus = card.querySelector('[data-order-status]');
							var paymentStatus = card.querySelector('[data-payment-status]');
							var shippingStatus = card.querySelector('[data-shipping-status]');
							var shippingMeta = card.querySelector('[data-shipping-meta]');
							if (orderStatus && labels.order[order.status]) {
								orderStatus.textContent = labels.order[order.status];
								orderStatus.className = 'online-order-status status-' + order.status;
							}
							if (paymentStatus && labels.payment[order.payment_status]) {
								paymentStatus.textContent = labels.payment[order.payment_status];
							}
							if (shippingStatus && labels.shipment[order.shipping_status]) {
								shippingStatus.textContent = labels.shipment[order.shipping_status];
							}
							if (shippingMeta) {
								shippingMeta.textContent = (order.carrier ? ' · ' + order.carrier : '')
									+ (order.tracking_number ? ' · Resi: ' + order.tracking_number : '');
							}
						});
					})
					.catch(function (error) { console.error(error); });
			}
			window.setInterval(refreshStatuses, 30000);
		}());
	</script>
</body>
</html>
