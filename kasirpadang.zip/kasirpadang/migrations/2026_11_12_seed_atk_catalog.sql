START TRANSACTION;

INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT seed.`nama_kategori`, DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
FROM (
  SELECT 'Alat Tulis & Menulis' AS `nama_kategori`
  UNION ALL SELECT 'Kertas & Buku'
  UNION ALL SELECT 'Peralatan Arsip & Filing'
  UNION ALL SELECT 'Peralatan Menggambar & Seni'
  UNION ALL SELECT 'Peralatan Meja & Kantor'
) AS seed
WHERE NOT EXISTS (
  SELECT 1 FROM `kategori` existing
  WHERE existing.`nama_kategori` = seed.`nama_kategori`
);

INSERT INTO `barang`
  (`id_barang`, `id_kategori`, `nama_barang`, `merk`, `harga_beli`, `harga_jual`, `satuan_barang`, `stok`, `tgl_input`)
SELECT products.`id_barang`, categories.`id_kategori`, products.`nama_barang`, products.`merk`,
       products.`harga_beli`, products.`harga_jual`, products.`satuan_barang`, products.`stok`,
       DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
FROM (
  SELECT 'ATK0001' AS `id_barang`, 'Alat Tulis & Menulis' AS `kategori`, 'Pulpen AE7' AS `nama_barang`, 'Standard' AS `merk`, 1800 AS `harga_beli`, 2500 AS `harga_jual`, 'PCS' AS `satuan_barang`, 48 AS `stok`
  UNION ALL SELECT 'ATK0002', 'Alat Tulis & Menulis', 'Pulpen C60', 'Faster', 1200, 2000, 'PCS', 36
  UNION ALL SELECT 'ATK0003', 'Alat Tulis & Menulis', 'Pulpen G-2', 'Pilot', 9000, 12000, 'PCS', 18
  UNION ALL SELECT 'ATK0004', 'Alat Tulis & Menulis', 'Pulpen V-5', 'SNOWMAN', 6000, 8000, 'PCS', 20
  UNION ALL SELECT 'ATK0005', 'Alat Tulis & Menulis', 'Pensil 2B', 'Faber-Castell', 2500, 3500, 'PCS', 30
  UNION ALL SELECT 'ATK0006', 'Alat Tulis & Menulis', 'Pensil Luna', 'Staedtler', 1500, 2500, 'PCS', 24
  UNION ALL SELECT 'ATK0007', 'Alat Tulis & Menulis', 'Penghapus', 'Joyko', 800, 1500, 'PCS', 35
  UNION ALL SELECT 'ATK0008', 'Alat Tulis & Menulis', 'Serutan Pensil', 'Joyko', 1500, 2500, 'PCS', 16
  UNION ALL SELECT 'ATK0009', 'Kertas & Buku', 'Buku Tulis 58 Lembar', 'Sidu', 3500, 5000, 'PCS', 40
  UNION ALL SELECT 'ATK0010', 'Kertas & Buku', 'Kertas HVS A4 70gr', 'PaperOne', 52000, 58000, 'RIM', 12
  UNION ALL SELECT 'ATK0011', 'Kertas & Buku', 'Buku Kwitansi', 'Kiky', 4500, 6500, 'PCS', 15
  UNION ALL SELECT 'ATK0012', 'Kertas & Buku', 'Buku Memo', 'Sidu', 3000, 4500, 'PCS', 18
  UNION ALL SELECT 'ATK0013', 'Peralatan Arsip & Filing', 'Odner Folio', 'Bantex', 24000, 30000, 'PCS', 10
  UNION ALL SELECT 'ATK0014', 'Peralatan Arsip & Filing', 'Map Plastik Kancing', 'Joyko', 2500, 4000, 'PCS', 30
  UNION ALL SELECT 'ATK0015', 'Peralatan Arsip & Filing', 'Sticky Notes Post-it', '3M', 9000, 12000, 'PAK', 12
  UNION ALL SELECT 'ATK0016', 'Peralatan Arsip & Filing', 'Binder Clip No. 107', 'Joyko', 3500, 5000, 'KOTAK', 15
  UNION ALL SELECT 'ATK0017', 'Peralatan Menggambar & Seni', 'Pensil Warna 12 Warna', 'Faber-Castell', 18000, 24000, 'KOTAK', 10
  UNION ALL SELECT 'ATK0018', 'Peralatan Menggambar & Seni', 'Buku Gambar A4', 'Kiky', 4500, 6500, 'PCS', 20
  UNION ALL SELECT 'ATK0019', 'Peralatan Meja & Kantor', 'Stapler HD-10', 'Kenko', 12000, 16000, 'PCS', 8
  UNION ALL SELECT 'ATK0020', 'Peralatan Meja & Kantor', 'Cutter L-500', 'Joyko', 5000, 7500, 'PCS', 12
  UNION ALL SELECT 'ATK0021', 'Peralatan Meja & Kantor', 'Lakban Hitam', 'Daimaru', 6000, 8500, 'PCS', 10
  UNION ALL SELECT 'ATK0022', 'Peralatan Meja & Kantor', 'Gunting Kertas', 'Joyko', 7000, 10000, 'PCS', 12
) AS products
INNER JOIN (
  SELECT MIN(`id_kategori`) AS `id_kategori`, `nama_kategori`
  FROM `kategori`
  GROUP BY `nama_kategori`
) categories ON categories.`nama_kategori` = products.`kategori`
WHERE NOT EXISTS (
  SELECT 1 FROM `barang` existing WHERE existing.`id_barang` = products.`id_barang`
);

-- Keep any product referenced by a receipt or cart so historical sales remain intact.
DELETE product FROM `barang` product
INNER JOIN `kategori` category ON category.`id_kategori` = product.`id_kategori`
WHERE category.`nama_kategori` IN ('Sabun', 'Snack', 'Minuman')
  AND NOT EXISTS (SELECT 1 FROM `nota` receipt WHERE receipt.`id_barang` = product.`id_barang`)
  AND NOT EXISTS (SELECT 1 FROM `penjualan` cart WHERE cart.`id_barang` = product.`id_barang`);

DELETE category FROM `kategori` category
WHERE category.`nama_kategori` IN ('Sabun', 'Snack', 'Minuman')
  AND NOT EXISTS (SELECT 1 FROM `barang` product WHERE product.`id_kategori` = category.`id_kategori`);

COMMIT;
