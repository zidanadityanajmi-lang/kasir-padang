ALTER TABLE `barang`
  ADD COLUMN `gambar` varchar(255) DEFAULT NULL AFTER `merk`;
