<?php 
/*
  | Source Code Aplikasi Penjualan Barang Kasir dengan PHP & MYSQL
  | 
  | @package   : pos-kasir-php
  | @file	   : index.php 
  | @author    : fauzan1892 / Fauzan Falah
  | @copyright : Copyright (c) 2017-2021 Codekop.com (https://www.codekop.com)
  | @blog      : https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html
  | 
  | 
  | 
  | 
 */

	require __DIR__ . '/fungsi/session.php';
	start_secure_session();
	if (empty($_SESSION['admin']['id_member']) || !isset($_SESSION['admin']['level'])) {
		$_SESSION = array();
		session_destroy();
		header('Location: login.php');
		exit;
	}

	$role = $_SESSION['admin']['level'];
	if (!in_array($role, array('admin', 'pembeli'), true)) {
		$_SESSION = array();
		session_destroy();
		header('Location: login.php');
		exit;
	}
	define('APP_BOOTSTRAPPED', true);

	$routes = array(
		'dashboard' => 'admin/template/home.php',
		'katalog' => 'admin/module/katalog/index.php',
		'barang' => 'admin/module/barang/index.php',
		'barang/tambah' => 'admin/module/barang/tambah/index.php',
		'barang/details' => 'admin/module/barang/details/index.php',
		'barang/edit' => 'admin/module/barang/edit/index.php',
		'stok/riwayat' => 'admin/module/stok/riwayat.php',
		'pelanggan' => 'admin/module/pelanggan/index.php',
		'jual' => 'admin/module/jual/index.php',
		'pesanan' => 'admin/module/pesanan/index.php',
		'ulasan' => 'admin/module/ulasan/index.php',
		'audit' => 'admin/module/audit/index.php',
		'promosi' => 'admin/module/promosi/index.php',
		'retur' => 'admin/module/retur/index.php',
		'kategori' => 'admin/module/kategori/index.php',
		'kategori/tambah' => 'admin/module/kategori/tambah/index.php',
		'laporan' => 'admin/module/laporan/index.php',
		'riwayat' => 'admin/module/riwayat/index.php',
		'pengaturan' => 'admin/module/pengaturan/index.php',
		'user' => 'admin/module/user/index.php'
	);
	$adminPages = array('dashboard', 'barang', 'barang/tambah', 'barang/details', 'barang/edit', 'stok/riwayat', 'pelanggan', 'jual', 'pesanan', 'ulasan', 'audit', 'promosi', 'retur', 'kategori', 'kategori/tambah', 'laporan', 'riwayat', 'pengaturan', 'user', 'katalog');
	$buyerPages = array('katalog', 'jual');
	$defaultPage = $role === 'admin' ? 'dashboard' : 'katalog';
	$page = isset($_GET['page']) && is_string($_GET['page']) ? trim($_GET['page']) : '';
	if ($page === '') {
		$page = $defaultPage;
	}
	$action = isset($_GET['aksi']) && is_string($_GET['aksi']) ? trim($_GET['aksi']) : '';
	if (($page === 'barang' && $action === 'tambah') || $page === 'tambah-barang') {
		$page = 'barang/tambah';
	} elseif (($page === 'kategori' && $action === 'tambah') || $page === 'tambah-kategori') {
		$page = 'kategori/tambah';
	}

	$allowedPages = $role === 'admin' ? $adminPages : $buyerPages;
	if (!in_array($page, $allowedPages, true)) {
		header('Location: index.php?page=' . $defaultPage . '&access=denied');
		exit;
	}

	require 'config.php';
	if (isset($_GET['ajax']) && $_GET['ajax'] === 'online-order-count') {
		if ($role !== 'admin') {
			http_response_code(403);
			header('Content-Type: application/json; charset=utf-8');
			echo json_encode(array('error' => 'Akses ditolak.'));
			exit;
		}

		header('Content-Type: application/json; charset=utf-8');
		header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
		$orderCount = (int) $config->query("SELECT COUNT(*) FROM pesanan WHERE status = 'pending'")->fetchColumn();
		echo json_encode(array('count' => $orderCount));
		exit;
	}
	$pendingOnlineOrders = $role === 'admin'
		? (int) $config->query("SELECT COUNT(*) FROM pesanan WHERE status = 'pending'")->fetchColumn()
		: 0;
	include $view;
	$lihat = new view($config);
	$toko = $lihat->toko();
	include 'admin/template/header.php';
	include 'admin/template/sidebar.php';
	include $routes[$page];
	include 'admin/template/footer.php';
?>
