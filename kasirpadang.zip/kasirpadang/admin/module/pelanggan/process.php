<?php
require __DIR__ . '/../../../fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses ditolak.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	http_response_code(405);
	exit('Metode permintaan tidak diizinkan.');
}
if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code(403);
	exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
}
$customerId = filter_var($_POST['customer_id'] ?? null, FILTER_VALIDATE_INT);
$action = (string) ($_POST['action'] ?? '');
if ($customerId === false || $customerId < 1 || !in_array($action, array('activate', 'deactivate'), true)) {
	header('Location: ../../../index.php?page=pelanggan&error=invalid');
	exit;
}
require __DIR__ . '/../../../config.php';
$status = $action === 'activate' ? 'active' : 'disabled';
$update = $config->prepare('UPDATE pelanggan SET status = ?, tanggal_update = ? WHERE id_pelanggan = ?');
$update->execute(array($status, date('Y-m-d H:i:s'), $customerId));
if ($update->rowCount() < 1) {
	$exists = $config->prepare('SELECT 1 FROM pelanggan WHERE id_pelanggan = ?');
	$exists->execute(array($customerId));
	if (!$exists->fetchColumn()) {
		header('Location: ../../../index.php?page=pelanggan&error=invalid');
		exit;
	}
}
header('Location: ../../../index.php?page=pelanggan&success=status');
exit;
