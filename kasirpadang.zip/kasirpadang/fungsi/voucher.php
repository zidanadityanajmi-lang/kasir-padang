<?php

function voucher_customer_key($customerId, $phone)
{
	if ((int) $customerId > 0) {
		return 'customer:' . (int) $customerId;
	}

	$digits = preg_replace('/\D+/', '', (string) $phone);
	if (strpos($digits, '0062') === 0) {
		$digits = substr($digits, 2);
	}
	if (strpos($digits, '62') === 0) {
		$digits = '0' . substr($digits, 2);
	} elseif (strpos($digits, '8') === 0) {
		$digits = '0' . $digits;
	}
	if (strlen($digits) < 8 || strlen($digits) > 15) {
		throw new DomainException('Masukkan nomor WhatsApp yang valid untuk menggunakan voucher.');
	}

	return 'phone:' . hash('sha256', $digits);
}

function voucher_quote(PDO $db, $code, $subtotal, $customerKey, $lock = false)
{
	$code = strtoupper(trim((string) $code));
	if (!preg_match('/^[A-Z0-9_-]{3,40}$/', $code)) {
		throw new DomainException('Kode voucher tidak valid.');
	}
	if ((int) $subtotal < 0 || $customerKey === '') {
		throw new DomainException('Voucher tidak dapat divalidasi untuk transaksi ini.');
	}

	$sql = "SELECT * FROM voucher
		WHERE kode = ? AND is_active = 1 AND tanggal_mulai <= ? AND tanggal_berakhir >= ?
		LIMIT 1" . ($lock ? ' FOR UPDATE' : '');
	$query = $db->prepare($sql);
	$now = date('Y-m-d H:i:s');
	$query->execute(array($code, $now, $now));
	$voucher = $query->fetch(PDO::FETCH_ASSOC);
	if (!$voucher) {
		throw new DomainException('Voucher tidak ditemukan, belum berlaku, atau sudah tidak aktif.');
	}
	if ((int) $subtotal < (int) $voucher['minimal_pembelian']) {
		throw new DomainException('Subtotal belum memenuhi minimal pembelian voucher.');
	}

	$usageQuery = $db->prepare('SELECT COUNT(*) FROM voucher_pemakaian WHERE id_voucher = ?');
	$usageQuery->execute(array((int) $voucher['id_voucher']));
	$totalUses = (int) $usageQuery->fetchColumn();
	if ($voucher['kuota_total'] !== null && $totalUses >= (int) $voucher['kuota_total']) {
		throw new DomainException('Kuota voucher telah habis.');
	}

	$customerUsageQuery = $db->prepare('SELECT COUNT(*) FROM voucher_pemakaian WHERE id_voucher = ? AND customer_key = ?');
	$customerUsageQuery->execute(array((int) $voucher['id_voucher'], (string) $customerKey));
	if ((int) $customerUsageQuery->fetchColumn() >= (int) $voucher['batas_per_pelanggan']) {
		throw new DomainException('Batas penggunaan voucher untuk pelanggan ini telah tercapai.');
	}

	$value = (int) $voucher['nilai_diskon'];
	if ($voucher['jenis_diskon'] === 'fixed') {
		$discount = min((int) $subtotal, $value);
	} elseif ($voucher['jenis_diskon'] === 'percentage' && $value >= 1 && $value <= 100) {
		$discount = (int) floor((int) $subtotal * $value / 100);
		if ($voucher['maksimal_potongan'] !== null && (int) $voucher['maksimal_potongan'] > 0) {
			$discount = min($discount, (int) $voucher['maksimal_potongan']);
		}
		$discount = min((int) $subtotal, $discount);
	} else {
		throw new RuntimeException('Voucher has an unsupported discount configuration.');
	}

	return array(
		'voucher' => $voucher,
		'code' => $code,
		'subtotal' => (int) $subtotal,
		'discount' => $discount,
		'total' => (int) $subtotal - $discount
	);
}
