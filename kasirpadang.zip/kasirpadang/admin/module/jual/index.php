<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
require_once __DIR__ . '/../../../fungsi/product_image.php';
?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <?php 
		  $memberId = (int) $_SESSION['admin']['id_member'];
		  $cartRows = $lihat -> penjualan($memberId);
		  $cartTotal = 0;
		  foreach($cartRows as $cartItem){
			  $cartTotal += (int) $cartItem['total'];
		  }
		  $posProducts = array();
		  $posCategories = array();
		  if ($role === 'admin') {
			  $posProductsQuery = $config->query(
				  'SELECT barang.id_barang, barang.nama_barang, barang.merk, barang.gambar, barang.harga_jual, barang.stok,
						  barang.satuan_barang, barang.id_kategori, kategori.nama_kategori
					  FROM barang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori
					  WHERE CAST(COALESCE(barang.stok, 0) AS UNSIGNED) > 0
					  ORDER BY barang.nama_barang ASC'
			  );
			  $posProducts = $posProductsQuery->fetchAll(PDO::FETCH_ASSOC);
			  foreach ($posProducts as $posProduct) {
				  $categoryId = (int) $posProduct['id_kategori'];
				  $posCategories[$categoryId] = $posProduct['nama_kategori'] ?: 'Lainnya';
			  }
		  }
		  $cashierErrors = array(
			  'empty' => 'Keranjang masih kosong.',
			  'stock' => 'Stok untuk barang yang dipilih tidak mencukupi.',
			  'payment' => 'Nominal pembayaran kurang dari total belanja.',
			  'minqty' => 'Jumlah barang minimal 1.',
			  'cart' => 'Data keranjang tidak valid. Muat ulang halaman.',
			  'notfound' => 'Barang tidak ditemukan atau sudah dihapus.',
			  'checkout' => 'Transaksi tidak dapat diproses. Silakan coba kembali.'
		  );
      ?>
      <section id="main-content">
          <section class="wrapper">
              <div class="row">
                  <div class="col-lg-12 main-chart">
						<?php if($role === 'admin' && $pendingOnlineOrders > 0){?>
						<div class="pos-online-orders" role="status">
							<span><i class="fa fa-shopping-bag" aria-hidden="true"></i> <strong><?php echo $pendingOnlineOrders;?> pesanan pelanggan online</strong> menunggu diproses.</span>
							<a href="index.php?page=pesanan">Lihat pesanan <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
						</div>
						<?php }?>
						<div class="pos-page-heading">
							<div>
								<p class="pos-eyebrow">Point of Sale</p>
								<h3>Keranjang Penjualan</h3>
							</div>
						</div>
						<div id="posCartFeedback" class="alert pos-alert" role="status" aria-live="polite" hidden></div>
						<?php if(isset($_GET['success'])){
							$successMessages = array('added' => 'Barang berhasil ditambahkan ke keranjang.', 'updated' => 'Jumlah barang berhasil diperbarui.', 'paid' => 'Pembayaran berhasil. Stok sudah diperbarui dan keranjang dikosongkan.');
							$successCode = $_GET['success'];
							if(isset($successMessages[$successCode])){
						?>
						<div class="alert alert-success pos-alert"><i class="fa fa-check-circle" aria-hidden="true"></i> <?php echo $successMessages[$successCode];?></div>
						<?php }}?>
						<?php if(isset($_GET['error']) && isset($cashierErrors[$_GET['error']])){
							$errorMessage = $cashierErrors[$_GET['error']];
							if($_GET['error'] === 'stock' && !empty($_GET['barang'])){
								$errorMessage = 'Stok ' . htmlspecialchars($_GET['barang'], ENT_QUOTES, 'UTF-8') . ' tidak mencukupi.';
							}
						?>
						<div class="alert alert-danger pos-alert"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <?php echo $errorMessage;?></div>
						<script>
							if (window.Swal) {
								Swal.fire({
									icon: 'error',
									title: 'Transaksi tidak dapat diproses',
									text: <?php echo json_encode(strip_tags($errorMessage), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);?>,
									confirmButtonColor: '#176b4b'
								});
							}
						</script>
						<?php }?>
						<?php if(isset($_GET['remove'])){?>
						<div class="alert alert-info pos-alert"><i class="fa fa-info-circle" aria-hidden="true"></i> Barang dihapus dari keranjang.</div>
						<?php }?>
						<div class="pos-workspace">
						<div class="row pos-search-grid">
						<div class="col-sm-4 pos-search-box">
							<div class="panel pos-panel">
								<div class="panel-heading">
									<h4><i class="fa fa-search"></i> Cari Barang</h4>
								</div>
								<div class="panel-body">
									<label class="sr-only" for="cari">Cari berdasarkan kode, nama, atau merek</label>
									<div class="pos-search-input"><i class="fa fa-search" aria-hidden="true"></i><input type="search" id="cari" class="form-control" name="cari" autocomplete="off" placeholder="Kode, nama, atau merek barang"></div>
									<p class="pos-search-hint">Pilih barang langsung atau ketik untuk mencari.</p>
								</div>
							</div>
						</div>
						<div class="col-sm-8 pos-results-box" id="hasil-pencarian">
							<div class="panel pos-panel">
								<div class="panel-heading">
									<h4><i class="fa fa-list"></i> Hasil Pencarian</h4>
								</div>
								<div class="panel-body">
									<div class="pos-results-scroll">
									<?php if($role === 'admin' && $posProducts){?>
									<div class="pos-category-filters" id="posCategoryFilters" aria-label="Filter kategori produk">
										<button type="button" class="is-active" data-category-filter="all">Semua</button>
										<?php foreach($posCategories as $categoryId => $categoryName){?>
										<button type="button" data-category-filter="<?php echo (int) $categoryId;?>"><?php echo htmlspecialchars($categoryName, ENT_QUOTES, 'UTF-8');?></button>
										<?php }?>
									</div>
									<?php }?>
									<div id="hasil_cari">
										<?php if($role === 'admin' && $posProducts){?>
										<div class="pos-product-grid">
											<?php foreach($posProducts as $posProduct){?>
											<?php
												$productImageName = basename((string) ($posProduct['gambar'] ?? ''));
												$productImagePath = __DIR__ . '/../../../assets/img/produk/' . $productImageName;
												$productImageUrl = $productImageName !== '' && is_file($productImagePath)
													? 'assets/img/produk/' . rawurlencode($productImageName)
													: product_image_placeholder($posProduct['nama_kategori'] ?? '', $posProduct['nama_barang'] ?? '', $posProduct['merk'] ?? '');
											?>
											<article class="pos-product-card" data-category-id="<?php echo (int) $posProduct['id_kategori'];?>" title="<?php echo htmlspecialchars($posProduct['nama_barang'] . ' - ' . $posProduct['merk'], ENT_QUOTES, 'UTF-8');?>">
												<div class="pos-product-image-wrap"><img src="<?php echo htmlspecialchars($productImageUrl, ENT_QUOTES, 'UTF-8');?>" alt="" loading="lazy"></div>
												<div class="pos-product-card-top"><span><?php echo htmlspecialchars($posProduct['nama_kategori'] ?: 'Lainnya', ENT_QUOTES, 'UTF-8');?></span><small>Stok <?php echo (int) $posProduct['stok'];?></small></div>
												<strong><?php echo htmlspecialchars($posProduct['nama_barang'], ENT_QUOTES, 'UTF-8');?></strong>
												<small class="pos-product-brand"><?php echo htmlspecialchars($posProduct['merk'], ENT_QUOTES, 'UTF-8');?></small>
												<div class="pos-product-card-footer">
													<span>Rp <?php echo number_format((int) $posProduct['harga_jual'], 0, ',', '.');?> <small>/ <?php echo htmlspecialchars($posProduct['satuan_barang'], ENT_QUOTES, 'UTF-8');?></small></span>
													<form method="POST" action="fungsi/tambah/tambah.php?jual=jual" class="pos-product-add-form">
														<?php echo csrf_field();?>
														<input type="hidden" name="id" value="<?php echo htmlspecialchars($posProduct['id_barang'], ENT_QUOTES, 'UTF-8');?>">
														<input type="hidden" name="id_barang" value="<?php echo htmlspecialchars($posProduct['id_barang'], ENT_QUOTES, 'UTF-8');?>">
														<button type="submit" class="pos-product-add" aria-label="Tambah <?php echo htmlspecialchars($posProduct['nama_barang'], ENT_QUOTES, 'UTF-8');?> ke keranjang"><i class="fa fa-plus" aria-hidden="true"></i><span>Tambah</span></button>
													</form>
												</div>
											</article>
											<?php }?>
										</div>
										<?php } else {?>
										<p class="search-empty"><?php echo $role === 'admin' ? 'Belum ada produk dengan stok tersedia.' : 'Ketik nama, kode, atau merek barang untuk mencari.';?></p>
										<?php }?>
									</div>
									<div id="tunggu" role="status" aria-live="polite"></div>
									</div>
									
								</div>
							</div>
						</div>
						</div>
						

						<div class="col-sm-12 pos-cart-column">
							<div class="panel pos-panel pos-cart-panel">
								<div class="panel-heading">
									<h4><span><i class="fa fa-shopping-cart" aria-hidden="true"></i> Keranjang Kasir</span>
									<form method="POST" action="fungsi/hapus/hapus.php?penjualan=jual" class="delete-form" onsubmit="return confirm('Kosongkan keranjang belanja?');">
										<?php echo csrf_field();?>
										<button type="submit" class="btn btn-default btn-reset-cart"><i class="fa fa-trash-o" aria-hidden="true"></i> Reset</button>
									</form>
									</h4>
								</div>
								<div class="panel-body">
									<div id="keranjang">
										<div class="cart-date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo date('j F Y, G:i');?></div>
										<div class="table-responsive cart-table-wrap">
										<table class="table cart-table">
											<thead>
												<tr>
													<th>No</th>
													<th>Nama Barang</th>
													<th>Jumlah</th>
													<th>Total</th>
													<th>Kasir</th>
													<th>Aksi</th>
												</tr>
											</thead>
											<tbody>
												<?php $no=1; foreach($cartRows as $isi){?>
												<tr>
													<td><?php echo $no;?></td>
													<td><strong><?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?></strong><small class="cart-item-code"><?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?></small></td>
													<td>
														<form class="cart-quantity-form" method="POST" action="fungsi/edit/edit.php?jual=jual">
															<?php echo csrf_field();?>
															<input type="hidden" name="id" value="<?php echo (int) $isi['id_penjualan'];?>">
															<input type="hidden" name="id_barang" value="<?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?>">
															<div class="quantity-stepper">
																<button type="submit" name="delta" value="-1" class="quantity-button" aria-label="Kurangi jumlah <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" <?php echo (int) $isi['jumlah'] <= 1 ? 'disabled' : '';?>>-</button>
																<input type="number" min="1" max="<?php echo (int) $isi['stok'];?>" name="jumlah" value="<?php echo (int) $isi['jumlah'];?>" aria-label="Jumlah <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>">
																<button type="submit" name="delta" value="1" class="quantity-button" aria-label="Tambah jumlah <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>">+</button>
															</div>
															<button type="submit" class="btn-quantity-save">Simpan</button>
														</form>
													</td>
													<td class="cart-line-total">Rp.<?php echo number_format((int) $isi['total']);?></td>
													<td><?php echo htmlspecialchars($isi['nm_member'], ENT_QUOTES, 'UTF-8');?></td>
													<td>
														<form method="POST" action="fungsi/hapus/hapus.php?jual=jual" class="delete-form">
															<?php echo csrf_field();?>
															<input type="hidden" name="id" value="<?php echo (int) $isi['id_penjualan'];?>">
															<button type="submit" class="btn-remove-cart" title="Hapus dari keranjang" aria-label="Hapus <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
														</form>
													</td>
												</tr>
												<?php $no++; }?>
												<?php if(!$cartRows){?><tr><td colspan="6"><div class="cart-empty"><i class="fa fa-shopping-basket" aria-hidden="true"></i><strong>Keranjang masih kosong</strong><span>Cari barang di atas untuk memulai transaksi.</span></div></td></tr><?php }?>
											</tbody>
									</table>
										</div>
									<br/>
										<?php $cartSummary = $lihat -> jumlah($memberId); $cartTotal = (int) ($cartSummary['bayar'] ?? 0); ?>
														<div id="kasirnya" class="pos-checkout">
															<div class="checkout-total">
																<div><span>Total Belanja</span><small><?php echo count($cartRows);?> item</small></div>
																<strong>Rp <?php echo number_format($cartTotal, 0, ',', '.');?></strong>
															</div>
															<form class="checkout-form" method="POST" action="fungsi/tambah/tambah.php?nota=jual">
																<?php echo csrf_field();?>
																<label for="bayar">Uang diterima</label>
																<div class="checkout-controls">
																	<div class="checkout-input-wrap"><span>Rp</span><input type="number" id="bayar" name="bayar" min="<?php echo max(1, $cartTotal);?>" step="1" required placeholder="Masukkan nominal pembayaran" <?php echo !$cartRows ? 'disabled' : '';?>></div>
																	<button type="submit" class="btn-checkout" <?php echo !$cartRows ? 'disabled' : '';?>><i class="fa fa-check-circle" aria-hidden="true"></i> Bayar &amp; Selesaikan</button>
																</div>
															</form>
															<?php if(isset($_GET['success']) && $_GET['success'] === 'paid' && isset($_SESSION['last_receipt'])){?>
																<div class="receipt-summary"><span>Nota #<?php echo (int) $_SESSION['last_receipt']['number'];?></span><strong>Kembalian Rp <?php echo number_format((int) $_SESSION['last_receipt']['change'], 0, ',', '.');?></strong><a href="print.php?receipt=last" target="_blank" class="btn-print-receipt"><i class="fa fa-print" aria-hidden="true"></i> Cetak nota</a></div>
															<?php }?>
														</div>
														</div>
														</div>
													</div>
												</div>
											</div>
						</div>
				  </div>
              </div>
          </section>
      </section>
	

<script>
$(function () {
	var searchTimer;
	var searchRequest;
	var $searchInput = $('#cari');
	var $results = $('#hasil_cari');
	var $loading = $('#tunggu');
	var $categoryFilters = $('#posCategoryFilters');
	var defaultResults = $results.html();
	var activeCategory = 'all';

	function filterDefaultProducts() {
		$results.html(defaultResults).show();
		$results.find('.pos-product-card').each(function () {
			$(this).toggle(activeCategory === 'all' || String($(this).data('category-id')) === activeCategory);
		});
	}

	$categoryFilters.on('click', 'button', function () {
		activeCategory = String($(this).data('category-filter'));
		$categoryFilters.find('button').removeClass('is-active');
		$(this).addClass('is-active');
		filterDefaultProducts();
	});

	function showCartFeedback(message, isError) {
		var $feedback = $('#posCartFeedback');
		$feedback
			.toggleClass('alert-danger', !!isError)
			.toggleClass('alert-success', !isError)
			.text(message)
			.prop('hidden', false);
	}

	function refreshCartPanel() {
		return $.get('index.php?page=jual').then(function (html) {
			var refreshedPanel = new DOMParser().parseFromString(html, 'text/html').querySelector('.pos-cart-panel');
			var currentPanel = document.querySelector('.pos-cart-panel');
			if (!refreshedPanel || !currentPanel) {
				throw new Error('Keranjang diperbarui, tetapi tampilan keranjang gagal dimuat ulang.');
			}
			currentPanel.replaceWith(refreshedPanel);
		});
	}

	$(document).on('submit', '.pos-product-add-form, .pos-search-add-form', function (event) {
		event.preventDefault();
		var form = this;
		var $button = $(form).find('button[type="submit"]');
		$button.prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: form.action,
			data: new FormData(form),
			processData: false,
			contentType: false,
			headers: {'X-Requested-With': 'XMLHttpRequest'},
			success: function (response) {
				if (!response || !response.ok) {
					showCartFeedback(response && response.message ? response.message : 'Barang gagal ditambahkan.', true);
					$button.prop('disabled', false);
					return;
				}
				refreshCartPanel().then(function () {
					showCartFeedback(response.message, false);
					$button.prop('disabled', false);
				}).catch(function () {
					window.location.href = 'index.php?page=jual&success=added#keranjang';
				});
			},
			error: function (xhr) {
				var response = xhr.responseJSON;
				showCartFeedback(response && response.message ? response.message : 'Barang gagal ditambahkan. Periksa koneksi lalu coba kembali.', true);
				$button.prop('disabled', false);
			}
		});
	});

	$searchInput.on('input', function () {
		var keyword = $.trim($searchInput.val());
		window.clearTimeout(searchTimer);
		if (searchRequest) {
			searchRequest.abort();
		}
		if (!keyword) {
			$loading.empty();
			$categoryFilters.show();
			filterDefaultProducts();
			return;
		}

		$categoryFilters.hide();
		$results.hide();
		$loading.html('<p class="search-loading"><i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i> Mencari barang...</p>');
		searchTimer = window.setTimeout(function () {
			searchRequest = $.ajax({
				type: 'POST',
				url: 'fungsi/edit/edit.php?cari_barang=yes',
				data: {keyword: keyword},
				success: function (html) {
					$loading.empty();
					$results.html(html).show();
				},
				error: function (xhr, status) {
					if (status !== 'abort') {
						$loading.html('<p class="search-error">Pencarian gagal. Coba lagi.</p>');
					}
				}
			});
		}, 220);
	});
});
</script>