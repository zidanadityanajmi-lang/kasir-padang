CREATE TABLE `pesanan` (
  `id_pesanan` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kode_pesanan` varchar(40) NOT NULL,
  `nama_pelanggan` varchar(120) NOT NULL,
  `no_hp` varchar(30) NOT NULL,
  `metode_pengambilan` varchar(20) NOT NULL,
  `alamat_pengiriman` text NULL,
  `metode_pembayaran` varchar(20) NOT NULL,
  `total` bigint unsigned NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `tanggal_input` datetime NOT NULL,
  `tanggal_selesai` datetime DEFAULT NULL,
  `id_member_pemroses` int(11) DEFAULT NULL,
  `kode_transaksi` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id_pesanan`),
  UNIQUE KEY `uq_pesanan_kode` (`kode_pesanan`),
  KEY `idx_pesanan_status_tanggal` (`status`, `tanggal_input`),
  KEY `idx_pesanan_kode_transaksi` (`kode_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `detail_pesanan` (
  `id_detail_pesanan` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pesanan` bigint unsigned NOT NULL,
  `id_barang` varchar(255) NOT NULL,
  `nama_barang` text NOT NULL,
  `merk` varchar(255) NOT NULL,
  `satuan_barang` varchar(255) NOT NULL,
  `jumlah` int unsigned NOT NULL,
  `harga_jual` bigint unsigned NOT NULL,
  `harga_modal` bigint unsigned NOT NULL,
  `subtotal` bigint unsigned NOT NULL,
  PRIMARY KEY (`id_detail_pesanan`),
  UNIQUE KEY `uq_detail_pesanan_barang` (`id_pesanan`, `id_barang`),
  KEY `idx_detail_pesanan_barang` (`id_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
