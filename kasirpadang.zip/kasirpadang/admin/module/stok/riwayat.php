<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}

$search = trim((string) ($_GET['q'] ?? ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 100, 'UTF-8') : substr($search, 0, 100);
$pageSize = 25;
$pageNumber = filter_var($_GET['hal'] ?? 1, FILTER_VALIDATE_INT);
$pageNumber = $pageNumber === false ? 1 : max(1, $pageNumber);
$conditions = array();
$parameters = array();
if ($search !== '') {
	$conditions[] = '(riwayat.id_barang LIKE ? OR riwayat.nama_barang_snapshot LIKE ? OR riwayat.keterangan LIKE ? OR riwayat.referensi LIKE ?)';
	$searchPattern = '%' . $search . '%';
	$parameters = array($searchPattern, $searchPattern, $searchPattern, $searchPattern);
}
$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
$countQuery = $config->prepare('SELECT COUNT(*) FROM riwayat_stok riwayat' . $where);
$countQuery->execute($parameters);
$totalRows = (int) $countQuery->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $pageSize));
$pageNumber = min($pageNumber, $totalPages);
$historyQuery = $config->prepare(
	'SELECT riwayat.*, member.nm_member
		FROM riwayat_stok riwayat
		LEFT JOIN member ON member.id_member = riwayat.id_member'
		. $where . ' ORDER BY riwayat.id_riwayat_stok DESC LIMIT ? OFFSET ?'
);
$parameterIndex = 1;
foreach ($parameters as $parameter) {
	$historyQuery->bindValue($parameterIndex++, $parameter, PDO::PARAM_STR);
}
$historyQuery->bindValue($parameterIndex++, $pageSize, PDO::PARAM_INT);
$historyQuery->bindValue($parameterIndex, ($pageNumber - 1) * $pageSize, PDO::PARAM_INT);
$historyQuery->execute();
$movements = $historyQuery->fetchAll(PDO::FETCH_ASSOC);
$movementLabels = array('masuk' => 'Stok masuk', 'keluar' => 'Stok keluar', 'penyesuaian' => 'Penyesuaian');
?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading">
			<div><p class="dashboard-eyebrow">Inventaris &amp; katalog</p><h1>Riwayat Perubahan Stok</h1></div>
		</div>
		<div class="dashboard-card history-card">
			<div class="dashboard-card-heading">
				<div><p class="dashboard-eyebrow">Pergerakan inventaris</p><h2><?php echo number_format($totalRows);?> catatan</h2></div>
			</div>
			<form method="GET" action="index.php" class="inventory-list-tools">
				<input type="hidden" name="page" value="stok/riwayat">
				<label class="sr-only" for="stockHistorySearch">Cari nama barang, ID, keterangan, atau referensi</label>
				<input id="stockHistorySearch" type="search" name="q" class="form-control" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8');?>" placeholder="Cari nama barang, ID, keterangan, atau referensi">
				<button type="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i> Cari</button>
				<?php if ($search !== '') { ?><a class="btn btn-default" href="index.php?page=stok/riwayat">Bersihkan</a><?php } ?>
			</form>
			<?php if (!$movements) { ?>
				<p class="dashboard-empty"><?php echo $search !== '' ? 'Tidak ada catatan perubahan stok yang cocok.' : 'Belum ada riwayat perubahan stok. Catatan baru akan dibuat untuk perubahan stok berikutnya.';?></p>
			<?php } else { ?>
				<div class="table-responsive">
					<table class="table table-hover">
						<thead><tr><th>Tanggal</th><th>Produk</th><th>Jenis</th><th>Perubahan</th><th>Stok sebelum</th><th>Stok sesudah</th><th>Keterangan / Referensi</th><th>Pengguna</th></tr></thead>
						<tbody>
						<?php foreach ($movements as $movement) { ?>
							<tr>
								<td><?php echo htmlspecialchars($movement['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
								<td><strong><?php echo htmlspecialchars($movement['nama_barang_snapshot'], ENT_QUOTES, 'UTF-8');?></strong><small class="online-order-meta"><?php echo htmlspecialchars($movement['id_barang'], ENT_QUOTES, 'UTF-8');?></small></td>
								<td><?php echo htmlspecialchars($movementLabels[$movement['jenis_perubahan']] ?? $movement['jenis_perubahan'], ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo number_format((int) $movement['jumlah']);?></td>
								<td><?php echo number_format((int) $movement['stok_sebelum']);?></td>
								<td><?php echo number_format((int) $movement['stok_sesudah']);?></td>
								<td><?php echo htmlspecialchars($movement['keterangan'], ENT_QUOTES, 'UTF-8');?><?php if (!empty($movement['referensi'])) { ?><small class="online-order-meta"><?php echo htmlspecialchars($movement['referensi'], ENT_QUOTES, 'UTF-8');?></small><?php } ?></td>
								<td><?php echo htmlspecialchars($movement['nm_member'] ?? 'Pelanggan / sistem', ENT_QUOTES, 'UTF-8');?></td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
				<?php if ($totalPages > 1) { ?>
					<nav class="inventory-pagination" aria-label="Navigasi riwayat stok">
						<span>Halaman <?php echo $pageNumber;?> dari <?php echo $totalPages;?></span>
						<div>
							<?php if ($pageNumber > 1) { ?><a class="btn btn-default" href="index.php?<?php echo htmlspecialchars(http_build_query(array('page' => 'stok/riwayat', 'q' => $search, 'hal' => $pageNumber - 1)), ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-angle-left" aria-hidden="true"></i> Sebelumnya</a><?php } ?>
							<?php if ($pageNumber < $totalPages) { ?><a class="btn btn-default" href="index.php?<?php echo htmlspecialchars(http_build_query(array('page' => 'stok/riwayat', 'q' => $search, 'hal' => $pageNumber + 1)), ENT_QUOTES, 'UTF-8');?>">Berikutnya <i class="fa fa-angle-right" aria-hidden="true"></i></a><?php } ?>
						</div>
					</nav>
				<?php } ?>
			<?php } ?>
		</div>
	</section>
</section>
