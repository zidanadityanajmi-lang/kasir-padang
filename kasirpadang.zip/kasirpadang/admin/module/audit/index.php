<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}
$auditQuery = $config->query(
	'SELECT log.id_audit_log, log.id_member, log.aktivitas, log.entitas, log.id_entitas,
			log.data_sebelum, log.data_sesudah, log.alamat_ip, log.tanggal_input, member.nm_member
		FROM audit_log log LEFT JOIN member ON member.id_member = log.id_member
		ORDER BY log.id_audit_log DESC LIMIT 100'
);
$auditRows = $auditQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<section id="main-content"><section class="wrapper">
	<div class="page-heading"><div><p class="dashboard-eyebrow">Kontrol operasional</p><h1>Audit Aktivitas</h1></div></div>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Perubahan penting</p><h2>100 aktivitas terakhir</h2></div></div>
		<p class="online-orders-note">Riwayat ini mencatat perubahan status pesanan, pengiriman, pembatalan, pembayaran, dan moderasi ulasan. Data pribadi tidak ditampilkan kecuali yang diperlukan untuk konteks perubahan.</p>
		<?php if (!$auditRows) { ?><p class="dashboard-empty">Belum ada aktivitas yang tercatat.</p><?php } else { ?>
			<div class="table-responsive"><table class="table">
				<thead><tr><th>Waktu</th><th>Operator</th><th>Aktivitas</th><th>Objek</th><th>Perubahan</th><th>IP</th></tr></thead>
				<tbody><?php foreach ($auditRows as $row) { ?>
					<tr>
						<td><?php echo htmlspecialchars($row['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
						<td><?php echo htmlspecialchars($row['nm_member'] ?: 'Sistem/pelanggan', ENT_QUOTES, 'UTF-8');?></td>
						<td><?php echo htmlspecialchars($row['aktivitas'], ENT_QUOTES, 'UTF-8');?></td>
						<td><?php echo htmlspecialchars($row['entitas'] . ($row['id_entitas'] ? ' #' . $row['id_entitas'] : ''), ENT_QUOTES, 'UTF-8');?></td>
						<td><details><summary>Lihat perubahan</summary><small>Sebelum: <?php echo htmlspecialchars($row['data_sebelum'] ?: '—', ENT_QUOTES, 'UTF-8');?></small><br><small>Sesudah: <?php echo htmlspecialchars($row['data_sesudah'] ?: '—', ENT_QUOTES, 'UTF-8');?></small></details></td>
						<td><?php echo htmlspecialchars($row['alamat_ip'] ?: '—', ENT_QUOTES, 'UTF-8');?></td>
					</tr>
				<?php } ?></tbody>
			</table></div>
		<?php } ?>
	</div>
</section></section>
