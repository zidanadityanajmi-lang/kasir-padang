<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
$categoryId = filter_var($_GET['kategori'] ?? null, FILTER_VALIDATE_INT);
$searchTerm = trim((string) ($_GET['q'] ?? ''));
$categories = $lihat->kategori();
$conditions = array('barang.stok > 0');
$parameters = array();

if ($categoryId !== false && $categoryId !== null && $categoryId > 0) {
	$conditions[] = 'barang.id_kategori = ?';
	$parameters[] = $categoryId;
}else{
	$categoryId = 0;
}

if ($searchTerm !== '') {
	$conditions[] = '(barang.nama_barang LIKE ? OR barang.merk LIKE ? OR barang.id_barang LIKE ?)';
	$searchPattern = '%' . $searchTerm . '%';
	$parameters[] = $searchPattern;
	$parameters[] = $searchPattern;
	$parameters[] = $searchPattern;
}

$catalogQuery = $config->prepare('SELECT barang.id_barang, barang.nama_barang, barang.merk, barang.harga_jual, barang.stok, barang.satuan_barang, kategori.nama_kategori FROM barang INNER JOIN kategori ON kategori.id_kategori = barang.id_kategori WHERE ' . implode(' AND ', $conditions) . ' ORDER BY barang.nama_barang LIMIT 100');
$catalogQuery->execute($parameters);
$products = $catalogQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<section id="main-content">
	<section class="wrapper">
		<div class="catalog-heading">
			<div>
				<p class="catalog-eyebrow">Produk ATK</p>
				<h1>Katalog Produk</h1>
			</div>
			<a class="btn btn-primary" href="index.php?page=jual"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Keranjang</a>
		</div>

		<?php if (isset($_GET['access'])) {?>
			<div class="alert alert-warning">Akun pembeli hanya dapat mengakses katalog dan keranjang belanja.</div>
		<?php }?>
		<?php if (isset($_GET['error']) && $_GET['error'] === 'stock') {?>
			<div class="alert alert-danger">Stok produk tidak mencukupi. Periksa kembali jumlah di keranjang.</div>
		<?php }?>

		<form class="catalog-filters" method="GET" action="index.php">
			<input type="hidden" name="page" value="katalog">
			<div class="catalog-search-field">
				<label for="catalogSearch">Cari produk</label>
				<input id="catalogSearch" type="search" name="q" class="form-control" value="<?php echo htmlspecialchars($searchTerm, ENT_QUOTES, 'UTF-8');?>" placeholder="Nama, merek, atau kode barang">
			</div>
			<div class="catalog-category-field">
				<label for="catalogCategory">Kategori</label>
				<select id="catalogCategory" name="kategori" class="form-control">
					<option value="0">Semua kategori</option>
					<?php foreach ($categories as $category) {?>
						<option value="<?php echo (int) $category['id_kategori'];?>" <?php echo $categoryId === (int) $category['id_kategori'] ? 'selected' : '';?>><?php echo htmlspecialchars($category['nama_kategori'], ENT_QUOTES, 'UTF-8');?></option>
					<?php }?>
				</select>
			</div>
			<button type="submit" class="btn btn-success"><i class="fa fa-search" aria-hidden="true"></i> Cari</button>
		</form>

		<?php if ($products) {?>
			<div class="catalog-grid">
				<?php foreach ($products as $product) {?>
					<article class="catalog-product">
						<div class="catalog-product-top">
							<span class="catalog-product-icon"><i class="fa fa-pencil" aria-hidden="true"></i></span>
							<span class="catalog-stock"><?php echo (int) $product['stok'];?> <?php echo htmlspecialchars($product['satuan_barang'], ENT_QUOTES, 'UTF-8');?></span>
						</div>
						<p class="catalog-category"><?php echo htmlspecialchars($product['nama_kategori'], ENT_QUOTES, 'UTF-8');?></p>
						<h2><?php echo htmlspecialchars($product['nama_barang'], ENT_QUOTES, 'UTF-8');?></h2>
						<p class="catalog-brand"><?php echo htmlspecialchars($product['merk'], ENT_QUOTES, 'UTF-8');?> <span>· <?php echo htmlspecialchars($product['id_barang'], ENT_QUOTES, 'UTF-8');?></span></p>
						<div class="catalog-product-footer">
							<strong>Rp <?php echo number_format((int) $product['harga_jual'], 0, ',', '.');?></strong>
							<form method="POST" action="fungsi/tambah/tambah.php?jual=jual">
								<?php echo csrf_field();?>
								<input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id_barang'], ENT_QUOTES, 'UTF-8');?>">
								<button type="submit" class="btn btn-primary" aria-label="Tambah <?php echo htmlspecialchars($product['nama_barang'], ENT_QUOTES, 'UTF-8');?> ke keranjang"><i class="fa fa-cart-plus" aria-hidden="true"></i> Tambah</button>
							</form>
						</div>
					</article>
				<?php }?>
			</div>
		<?php }else{?>
			<div class="catalog-empty"><i class="fa fa-search" aria-hidden="true"></i><strong>Produk tidak ditemukan</strong><span>Ubah pencarian atau pilih kategori lain.</span></div>
		<?php }?>
	</section>
</section>