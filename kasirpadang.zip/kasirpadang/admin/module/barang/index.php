<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php require_once __DIR__ . '/../../../fungsi/product_image.php'; ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
						<div class="page-heading inventory-page-heading">
							<div>
								<p class="dashboard-eyebrow">Inventaris &amp; katalog</p>
								<h1><?php echo isset($_GET['stok']) && $_GET['stok'] === 'yes' ? 'Stok Menipis' : 'Data Produk ATK';?></h1>
							</div>
						</div>
						<?php if(isset($_GET['success-stok'])){?>
						<div class="alert alert-success">
							<p>Tambah Stok Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['success'])){?>
						<div class="alert alert-success">
							<p>Tambah Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['remove'])){?>
						<div class="alert alert-danger">
							<p>Hapus Data Berhasil !</p>
						</div>
						<?php }?>
						<?php
							$inventoryErrors = array(
								'validation' => 'Periksa kembali nama, kategori, harga, satuan, dan stok. Nilai harga dan stok harus bilangan bulat nol atau lebih.',
								'duplicate' => 'ID barang sudah digunakan. Muat ulang halaman untuk mendapatkan ID terbaru.',
								'notfound' => 'Barang yang akan diubah tidak ditemukan.',
								'image' => 'Foto produk gagal diunggah. Gunakan gambar JPG, JPEG, PNG, atau WebP maksimal 2 MB.',
								'linked' => 'Barang tidak dapat dihapus karena memiliki riwayat transaksi atau sedang dipesan pelanggan.'
							);
							if(isset($_GET['error']) && isset($inventoryErrors[$_GET['error']])){
								$errorMessage = $inventoryErrors[$_GET['error']];
							?>
							<div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8');?></div>
							<script>
								if (window.Swal) {
									Swal.fire({icon: 'error', title: 'Data barang belum tersimpan', text: <?php echo json_encode($errorMessage, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);?>, confirmButtonColor: '#176b4b'});
								}
							</script>
							<?php }
						?>
						
						<?php
							$lowStockOnly = isset($_GET['stok']) && $_GET['stok'] === 'yes';
							$searchTerm = trim((string) ($_GET['q'] ?? ''));
							$pageSize = 25;
							$currentPage = filter_var($_GET['hal'] ?? 1, FILTER_VALIDATE_INT);
							$currentPage = $currentPage === false ? 1 : max(1, $currentPage);
							$totalItems = $lihat->barang_count($lowStockOnly, $searchTerm);
							$totalPages = max(1, (int) ceil($totalItems / $pageSize));
							$currentPage = min($currentPage, $totalPages);
							$hasil = $lihat->barang_page($currentPage, $pageSize, $lowStockOnly, $searchTerm);
							$inventorySummary = $lihat->barang_summary($lowStockOnly, $searchTerm);
							$r = $lihat->barang_count(true);
							$paginationParams = array('page' => 'barang');
							if ($lowStockOnly) {
								$paginationParams['stok'] = 'yes';
							}
							if ($searchTerm !== '') {
								$paginationParams['q'] = $searchTerm;
							}
							$paginationUrl = 'index.php?' . http_build_query($paginationParams);
							if($r > 0){
						?>	
						<?php
								echo "
								<div class='alert alert-warning'>
									<i class='fa fa-exclamation-circle' aria-hidden='true'></i> Ada <strong>$r</strong> barang dengan stok 5 atau kurang. Silakan pesan kembali.
									<span class='pull-right'><a href='index.php?page=barang&stok=yes'>Cek Barang <i class='fa fa-angle-double-right'></i></a></span>
								</div>
								";	
							}
						?>

						<div class="inventory-toolbar">
							<span class="inventory-result-count"><?php echo number_format($totalItems);?> produk<?php echo $lowStockOnly ? ' perlu diperiksa' : ' dalam katalog';?></span>
							<div class="inventory-toolbar-actions">
								<a href="index.php?page=barang" class="btn btn-default"><i class="fa fa-refresh" aria-hidden="true"></i> Refresh</a>
								<a href="index.php?page=barang&amp;stok=yes" class="btn btn-warning"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Stok Menipis</a>
								<a href="index.php?page=barang&amp;aksi=tambah<?php echo $lowStockOnly ? '&amp;stok=yes' : '';?>" class="btn btn-primary">
									<i class="fa fa-plus" aria-hidden="true"></i> Tambah Produk</a>
							</div>
						</div>
						<form method="GET" action="index.php" class="inventory-list-tools">
							<input type="hidden" name="page" value="barang">
							<?php if($lowStockOnly){?><input type="hidden" name="stok" value="yes"><?php }?>
							<label class="sr-only" for="inventorySearch">Cari ID, nama, atau merek barang</label>
							<input id="inventorySearch" type="search" name="q" class="form-control" value="<?php echo htmlspecialchars($searchTerm, ENT_QUOTES, 'UTF-8');?>" placeholder="<?php echo $lowStockOnly ? 'Cari produk stok menipis' : 'Cari ID, nama, atau merek barang';?>">
							<button type="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i> Cari</button>
							<?php if($searchTerm !== ''){?><a class="btn btn-default" href="<?php echo htmlspecialchars($lowStockOnly ? 'index.php?page=barang&stok=yes' : 'index.php?page=barang', ENT_QUOTES, 'UTF-8');?>">Bersihkan</a><?php }?>
						</form>
						
						<!-- view barang -->
						<div class="modal-view table-responsive inventory-table-wrap">
							<table class="table table-bordered table-striped inventory-table">
								<thead>
									<tr>
										<th>No.</th>
										<th>ID Barang</th>
										<th>Foto</th>
										<th>Kategori</th>
										<th>Nama Barang</th>
										<th>Merk</th>
										<th>Stok</th>
										<th>Harga Beli</th>
										<th>Harga Jual</th>
										<th>Satuan</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
								<?php
									$totalBeli = (int) $inventorySummary['total_modal'];
									$totalJual = (int) $inventorySummary['total_jual'];
									$totalStok = (int) $inventorySummary['total_stok'];
									$no = (($currentPage - 1) * $pageSize) + 1;
									foreach($hasil as $isi) {
								?>
									<tr>
										<td><?php echo $no;?></td>
										<td><?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
										<?php
											$productImageName = basename((string) ($isi['gambar'] ?? ''));
											$productImagePath = __DIR__ . '/../../../assets/img/produk/' . $productImageName;
											$productImageHref = $productImageName !== '' && is_file($productImagePath)
												? 'assets/img/produk/' . rawurlencode($productImageName) . '?v=' . (int) filemtime($productImagePath)
												: product_image_placeholder($isi['nama_kategori'] ?? '', $isi['nama_barang'] ?? '', $isi['merk'] ?? '');
										?>
										<td><img class="inventory-product-thumbnail" src="<?php echo htmlspecialchars($productImageHref, ENT_QUOTES, 'UTF-8');?>" alt="Foto <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" loading="lazy"></td>
										<td><?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo htmlspecialchars($isi['merk'], ENT_QUOTES, 'UTF-8');?></td>
										<td>
											<?php if((int) $isi['stok'] <= 0){?>
												<span class="stock-badge stock-empty">Habis</span>
											<?php }elseif((int) $isi['stok'] <= 5){?>
												<span class="stock-badge stock-low"><?php echo (int) $isi['stok'];?> Menipis</span>
											<?php }else{?>
												<span class="stock-badge stock-available"><?php echo htmlspecialchars($isi['stok'], ENT_QUOTES, 'UTF-8');?> Tersedia</span>
											<?php }?>
										</td>
										<td>Rp.<?php echo number_format($isi['harga_beli']);?>,-</td>
										<td>Rp.<?php echo number_format($isi['harga_jual']);?>,-</td>
										<td><span class="unit-badge unit-<?php echo preg_replace('/[^a-z0-9-]/', '', strtolower($isi['satuan_barang']));?>"><?php echo htmlspecialchars($isi['satuan_barang'], ENT_QUOTES, 'UTF-8');?></span></td>
										<td>
											<div class="inventory-actions">
												<?php if((int) $isi['stok'] <= 5){?>
													<form class="restock-form" method="POST" action="fungsi/edit/edit.php?stok=edit">
														<?php echo csrf_field();?>
														<input type="number" min="1" step="1" required name="restok" class="form-control" aria-label="Jumlah stok tambahan untuk <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" placeholder="Tambah stok">
														<input type="hidden" name="id" value="<?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?>">
														<button type="submit" class="btn btn-success btn-xs" title="Tambah stok"><i class="fa fa-plus" aria-hidden="true"></i><span class="sr-only">Tambah stok</span></button>
													</form>
												<?php }?>
												<a class="btn btn-info btn-xs" title="Detail barang" aria-label="Detail <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" href="index.php?page=barang/details&barang=<?php echo urlencode($isi['id_barang']);?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
												<a class="btn btn-primary btn-xs" title="Edit barang" aria-label="Edit <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" href="index.php?page=barang/edit&barang=<?php echo urlencode($isi['id_barang']);?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
												<form method="POST" action="fungsi/hapus/hapus.php?barang=hapus" class="delete-form">
													<?php echo csrf_field();?>
													<input type="hidden" name="id" value="<?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?>">
													<button type="submit" class="btn btn-danger btn-xs js-confirm-delete" title="Hapus barang" aria-label="Hapus <?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>" data-delete-name="<?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-trash" aria-hidden="true"></i></button>
												</form>
											</div>
										</td>
									</tr>
								<?php
										$no++;
									}
								?>
								</tbody>
								<tfoot>
									<tr>
										<th colspan="6">Total</th>
										<th><?php echo $totalStok;?></th>
										<th>Rp.<?php echo number_format($totalBeli);?>,-</th>
										<th>Rp.<?php echo number_format($totalJual);?>,-</th>
										<th colspan="2"></th>
									</tr>
								</tfoot>
							</table>
						</div>
						<?php if($totalPages > 1){?>
							<nav class="inventory-pagination" aria-label="Navigasi halaman barang">
								<span>Halaman <?php echo $currentPage;?> dari <?php echo $totalPages;?> (<?php echo $totalItems;?> barang)</span>
								<div>
									<?php if($currentPage > 1){?><a class="btn btn-default" href="<?php echo htmlspecialchars($paginationUrl . '&hal=' . ($currentPage - 1), ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-angle-left" aria-hidden="true"></i> Sebelumnya</a><?php }?>
									<?php if($currentPage < $totalPages){?><a class="btn btn-default" href="<?php echo htmlspecialchars($paginationUrl . '&hal=' . ($currentPage + 1), ENT_QUOTES, 'UTF-8');?>">Berikutnya <i class="fa fa-angle-right" aria-hidden="true"></i></a><?php }?>
								</div>
							</nav>
						<?php }?>
						<div class="clearfix" style="margin-top:2pc;"></div>
					<!-- end view barang -->
							<script>
								$(function () {
									$(document).on('click', '.js-confirm-delete', function (event) {
										event.preventDefault();
										var productName = $(this).attr('data-delete-name');
										var deleteForm = $(this).closest('form');
										if (window.Swal) {
											Swal.fire({
												title: 'Hapus barang?',
												text: 'Data "' + productName + '" akan dihapus permanen.',
												icon: 'warning',
												showCancelButton: true,
												confirmButtonText: 'Ya, hapus',
												cancelButtonText: 'Batal',
												confirmButtonColor: '#c94d49',
												cancelButtonColor: '#687783'
											}).then(function (result) {
												if (result.isConfirmed) {
													deleteForm[0].submit();
												}
											});
										} else if (window.confirm('Hapus barang "' + productName + '"?')) {
											deleteForm[0].submit();
										}
									});
								});
							</script>
						</div>
						</div>
          	</section>
      	</section>
	
