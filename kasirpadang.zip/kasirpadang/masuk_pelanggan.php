<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/customer_account.php';

if (customer_account_session()) {
	header('Location: profil_pelanggan.php');
	exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$email = strtolower(trim((string) ($_POST['email'] ?? '')));
	$password = (string) ($_POST['password'] ?? '');
	if (!valid_csrf_token($_POST['_csrf'] ?? null) || !filter_var($email, FILTER_VALIDATE_EMAIL)
		|| strlen($email) > 190 || $password === '' || strlen($password) > 4096) {
		$error = 'Email atau password salah.';
	} else {
		$customerQuery = $config->prepare(
			"SELECT id_pelanggan, nama_pelanggan, email, no_hp, alamat, password_hash
				FROM pelanggan WHERE email = ? AND status = 'active' LIMIT 1"
		);
		$customerQuery->execute(array($email));
		$customer = $customerQuery->fetch(PDO::FETCH_ASSOC);
		if ($customer && password_verify($password, $customer['password_hash'])) {
			session_regenerate_id(true);
			$_SESSION['customer'] = array(
				'id_pelanggan' => (int) $customer['id_pelanggan'],
				'nama_pelanggan' => $customer['nama_pelanggan'],
				'email' => $customer['email'],
				'no_hp' => $customer['no_hp'],
				'alamat' => $customer['alamat'] ?? ''
			);
			header('Location: profil_pelanggan.php');
			exit;
		}
		$error = 'Email atau password salah.';
	}
}

$storeName = 'ATK Suka Suka';
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Masuk Pelanggan | <?php echo customer_account_escape($storeName);?></title>
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css" rel="stylesheet">
</head>
<body>
	<div class="shop-promo"><div class="shop-container shop-promo-inner"><span><?php echo customer_account_escape($storeName);?></span><a href="katalog_pelanggan.php">Kembali ke katalog</a></div></div>
	<main class="shop-container order-history-page">
		<div class="section-heading"><div><span class="section-kicker">Akun pelanggan</span><h1>Masuk</h1><p>Masuk untuk melihat profil dan riwayat pesanan Anda.</p></div></div>
		<?php if ($error !== '') { ?><div class="shop-notice shop-notice-danger" role="alert"><?php echo customer_account_escape($error);?></div><?php } ?>
		<form class="order-lookup-form" method="POST" action="masuk_pelanggan.php">
			<?php echo csrf_field();?>
			<label for="customerEmail">Email</label>
			<input id="customerEmail" type="email" name="email" maxlength="190" autocomplete="email" required value="<?php echo customer_account_escape($_POST['email'] ?? '');?>">
			<label for="customerPassword">Password</label>
			<input id="customerPassword" type="password" name="password" maxlength="4096" autocomplete="current-password" required>
			<button class="store-button" type="submit"><i class="fa fa-sign-in" aria-hidden="true"></i> Masuk</button>
		</form>
		<p>Belum mempunyai akun? <a href="daftar_pelanggan.php">Daftar pelanggan</a>.</p>
	</main>
	<footer class="shop-footer"><div class="shop-container footer-bottom"><a href="riwayat_pesanan.php">Cek pesanan tanpa akun</a><a href="katalog_pelanggan.php#kontak">Kontak toko</a></div></footer>
</body>
</html>
