<?php
/*
  | Source Code Aplikasi Penjualan Barang Kasir dengan PHP & MYSQL
  | 
  | @package   : pos-kasir-php
  | @file	   : config.php ( untuk mengatur koneksi php ke database mysql )
  | @author    : fauzan1892 / Fauzan Falah
  | @copyright : Copyright (c) 2017-2021 Codekop.com (https://www.codekop.com)
  | @blog      : https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html
  |
  | 
  | keterangan : untuk login aplikasi dengan username : admin dan password : 123
  | 
  | 
  | 
 */

date_default_timezone_set("Asia/Jakarta");
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');

$host = getenv('DB_HOST') ?: 'localhost';
$port = getenv('DB_PORT') ?: '3306';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';
$dbname = getenv('DB_NAME') ?: 'db_toko';

$databaseErrorId = bin2hex(random_bytes(4));
$databaseErrorTitle = 'Koneksi database gagal';
$databaseErrorHint = 'Pastikan MySQL aktif, lalu cocokkan host, port, nama database, username, dan password di konfigurasi.';
$databaseDebug = filter_var(getenv('APP_DEBUG') ?: '0', FILTER_VALIDATE_BOOLEAN)
	&& in_array(strtolower((string) ($_SERVER['REMOTE_ADDR'] ?? '')), array('127.0.0.1', '::1'), true);

if (!extension_loaded('pdo_mysql')) {
	$databaseException = new RuntimeException('Ekstensi PDO MySQL (pdo_mysql) belum aktif pada PHP.');
	$databaseErrorTitle = 'Driver MySQL PHP tidak aktif';
	$databaseErrorHint = 'Aktifkan ekstensi pdo_mysql pada php.ini yang digunakan Apache, lalu restart Apache.';
} elseif (!ctype_digit((string) $port) || (int) $port < 1 || (int) $port > 65535) {
	$databaseException = new InvalidArgumentException('DB_PORT harus berupa angka antara 1 dan 65535.');
	$databaseErrorTitle = 'Konfigurasi port database tidak valid';
	$databaseErrorHint = 'Atur DB_PORT sesuai port MySQL pada XAMPP (umumnya 3306).';
} else {
	try {
		$config = new PDO(
			"mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
			$user,
			$pass,
			array(
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
				PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
				PDO::ATTR_EMULATE_PREPARES => false,
				PDO::ATTR_TIMEOUT => 5
			)
		);
	} catch (PDOException $exception) {
		$databaseException = $exception;
		$errorInfo = $exception->errorInfo;
		$driverCode = isset($errorInfo[1]) ? (int) $errorInfo[1] : 0;
		$sqlState = isset($errorInfo[0]) ? (string) $errorInfo[0] : (string) $exception->getCode();

		if ($driverCode === 1049) {
			$databaseErrorTitle = 'Database tidak ditemukan';
			$databaseErrorHint = 'Import db_toko.sql melalui phpMyAdmin atau sesuaikan DB_NAME dengan nama database yang sudah di-import.';
		} elseif ($driverCode === 1045) {
			$databaseErrorTitle = 'Akses database ditolak';
			$databaseErrorHint = 'Periksa DB_USER dan DB_PASS. Nilai bawaan XAMPP biasanya root dengan password kosong, kecuali sudah diubah.';
		} elseif (in_array($driverCode, array(2002, 2003, 2006, 2013), true)) {
			$databaseErrorTitle = 'Server MySQL tidak merespons';
			$databaseErrorHint = 'Pastikan MySQL berstatus Running di XAMPP Control Panel dan DB_HOST/DB_PORT sesuai konfigurasi MySQL.';
		}
	}
}

if (isset($databaseException)) {
	$exceptionInfo = isset($databaseException->errorInfo) && is_array($databaseException->errorInfo)
		? $databaseException->errorInfo
		: array();
	$sqlState = isset($sqlState) ? $sqlState : (string) $databaseException->getCode();
	$driverCode = isset($driverCode) ? $driverCode : (isset($exceptionInfo[1]) ? (int) $exceptionInfo[1] : 0);
	error_log(sprintf(
		'[%s] Database connection failed: host=%s port=%s database=%s user=%s SQLSTATE=%s driver_code=%d message=%s',
		$databaseErrorId,
		$host,
		$port,
		$dbname,
		$user,
		$sqlState,
		$driverCode,
		$databaseException->getMessage()
	));

	http_response_code(500);
	header('Content-Type: text/html; charset=utf-8');
	?>
	<!DOCTYPE html>
	<html lang="id">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo htmlspecialchars($databaseErrorTitle, ENT_QUOTES, 'UTF-8');?></title>
		<style>
			body { margin: 0; padding: 32px 16px; background: #f4f7f8; color: #172b2a; font: 15px/1.6 "Segoe UI", Arial, sans-serif; }
			main { max-width: 720px; margin: 6vh auto; padding: 28px; border: 1px solid #e2e9e9; border-radius: 12px; background: #fff; box-shadow: 0 8px 26px rgba(17,47,45,.07); }
			h1 { margin-top: 0; color: #004643; font-size: 24px; }
			li { margin: 8px 0; }
			code { padding: 2px 6px; border-radius: 4px; background: #f1f5f5; }
			.ref { color: #687b7b; font-size: 13px; }
			pre { overflow-x: auto; padding: 12px; border-radius: 8px; background: #f4f7f8; white-space: pre-wrap; }
		</style>
	</head>
	<body>
		<main>
			<h1><?php echo htmlspecialchars($databaseErrorTitle, ENT_QUOTES, 'UTF-8');?></h1>
			<p><?php echo htmlspecialchars($databaseErrorHint, ENT_QUOTES, 'UTF-8');?></p>
			<ul>
				<li>Buka XAMPP Control Panel dan pastikan MySQL berstatus <strong>Running</strong>.</li>
				<li>Periksa DB_HOST dan DB_PORT; XAMPP umumnya menggunakan <code>localhost:3306</code>.</li>
				<li>Pastikan database yang di-import bernama <code>db_toko</code>, atau sesuaikan DB_NAME.</li>
				<li>Baca log PHP/Apache untuk detail; ID diagnostik: <code><?php echo htmlspecialchars($databaseErrorId, ENT_QUOTES, 'UTF-8');?></code>.</li>
			</ul>
			<?php if ($databaseDebug) {?>
				<p><strong>Detail developer (APP_DEBUG aktif di localhost):</strong></p>
				<pre><?php echo htmlspecialchars(sprintf('SQLSTATE %s; driver %d: %s', $sqlState, $driverCode, $databaseException->getMessage()), ENT_QUOTES, 'UTF-8');?></pre>
			<?php }?>
		</main>
	</body>
	</html>
	<?php
	exit;
}

$view = 'fungsi/view/view.php'; // direktori fungsi select data
?>
