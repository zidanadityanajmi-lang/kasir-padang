<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
						<div class="page-heading">
							<div><p class="dashboard-eyebrow">Inventaris &amp; katalog</p><h1>Data Kategori</h1></div>
							<a href="index.php?page=kategori&amp;aksi=tambah" class="btn btn-primary">
								<i class="fa fa-plus" aria-hidden="true"></i> Tambah Kategori
							</a>
						</div>
						<?php if(isset($_GET['success'])){?>
						<div class="alert alert-success">
							<p>Tambah Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['success-edit'])){?>
						<div class="alert alert-success">
							<p>Update Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['remove'])){?>
						<div class="alert alert-danger">
							<p>Hapus Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['error']) && $_GET['error'] === 'used'){?>
						<div class="alert alert-warning">Kategori tidak dapat dihapus karena masih digunakan oleh produk.</div>
						<?php }?>
						<?php if(isset($_GET['error']) && $_GET['error'] === 'duplicate'){?>
						<div class="alert alert-warning">Nama kategori sudah digunakan.</div>
						<?php }?>
						<?php if(isset($_GET['error']) && $_GET['error'] === 'validation'){?>
						<div class="alert alert-danger">Masukkan nama kategori yang valid (maksimal 255 karakter).</div>
						<?php }?>
						<div class="dashboard-card category-table-card">
						<div class="table-responsive">
						<table class="table table-hover" id="example1">
							<thead>
								<tr style="background:#DFF0D8;color:#333;">
									<th>No.</th>
									<th>Kategori</th>
									<th>Tanggal Input</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
							<?php 
								$hasil = $lihat -> kategori();
								$no=1;
								foreach($hasil as $isi){
							?>
								<tr>
									<td><?php echo $no;?></td>
									<td><?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?></td>
									<td><?php echo htmlspecialchars($isi['tgl_input'], ENT_QUOTES, 'UTF-8');?></td>
									<td class="category-actions">
										<button type="button" class="btn btn-warning btn-xs js-edit-category" title="Edit kategori" aria-label="Edit kategori <?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?>" data-toggle="modal" data-target="#categoryModal" data-mode="edit" data-id="<?php echo (int) $isi['id_kategori'];?>" data-name="<?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-pencil" aria-hidden="true"></i><span class="sr-only">Edit</span></button>
										<form method="POST" action="fungsi/hapus/hapus.php?kategori=hapus" class="delete-form">
											<?php echo csrf_field();?>
											<input type="hidden" name="id" value="<?php echo (int) $isi['id_kategori'];?>">
											<button type="submit" class="btn btn-danger btn-xs js-confirm-category-delete" title="Hapus kategori" aria-label="Hapus kategori <?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?>" data-delete-name="<?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-trash" aria-hidden="true"></i><span class="sr-only">Hapus</span></button>
										</form>
									</td>
								</tr>
							<?php $no++; }?>
							</tbody>
						</table>
						</div>
						</div>
						<div class="modal fade" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModalTitle">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Tutup">&times;</button>
										<h4 class="modal-title" id="categoryModalTitle">Edit Kategori</h4>
									</div>
									<form method="POST" action="fungsi/edit/edit.php?kategori=edit" id="categoryForm">
										<?php echo csrf_field();?>
										<div class="modal-body">
											<input type="hidden" name="id" id="categoryId" value="">
											<label for="categoryName">Nama kategori</label>
											<input type="text" class="form-control" id="categoryName" name="kategori" maxlength="255" required placeholder="Contoh: Alat Tulis &amp; Menulis">
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
											<button type="submit" class="btn btn-primary" id="categorySubmit"><i class="fa fa-check" aria-hidden="true"></i> Simpan Perubahan</button>
										</div>
									</form>
								</div>
							</div>
						</div>
						<script>
							document.addEventListener('click', function (event) {
								var editButton = event.target.closest('.js-edit-category');
								if (editButton) {
									document.getElementById('categoryForm').action = 'fungsi/edit/edit.php?kategori=edit';
									document.getElementById('categoryId').value = editButton.getAttribute('data-id');
									document.getElementById('categoryName').value = editButton.getAttribute('data-name');
								}

								var deleteButton = event.target.closest('.js-confirm-category-delete');
								if (!deleteButton) {
									return;
								}
								event.preventDefault();
								var categoryName = deleteButton.getAttribute('data-delete-name');
								var deleteForm = deleteButton.closest('form');
								if (window.Swal) {
									Swal.fire({
										title: 'Hapus kategori?',
										text: 'Kategori "' + categoryName + '" akan dihapus.',
										icon: 'warning',
										showCancelButton: true,
										confirmButtonText: 'Ya, hapus',
										cancelButtonText: 'Batal',
										confirmButtonColor: '#c94d49',
										cancelButtonColor: '#687783'
									}).then(function (result) {
										if (result.isConfirmed) {
											deleteForm.submit();
										}
									});
								} else if (window.confirm('Hapus kategori "' + categoryName + '"?')) {
									deleteForm.submit();
								}
							});
						</script>
						<div class="clearfix" style="padding-top:16%;"></div>
				  </div>
              </div>
          </section>
      </section>
	
