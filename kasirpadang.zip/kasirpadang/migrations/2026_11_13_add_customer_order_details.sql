ALTER TABLE `pesanan`
  ADD COLUMN `catatan_pesanan` text DEFAULT NULL AFTER `alamat_pengiriman`;

ALTER TABLE `barang`
  ADD COLUMN `deskripsi` text DEFAULT NULL AFTER `gambar`;
