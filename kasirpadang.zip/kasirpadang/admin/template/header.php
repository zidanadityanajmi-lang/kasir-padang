<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sistem kasir dan inventaris ATK Suka Suka">

    <title><?php echo htmlspecialchars($toko['nama_toko'] ?? 'ATK Suka Suka', ENT_QUOTES, 'UTF-8');?> | Sistem Kasir</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="assets/datatables/jquery.dataTables.css"/>
    <link rel="stylesheet" type="text/css" href="assets/lineicons/style.css">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/modern.css" rel="stylesheet">
    <link href="assets/css/admin-redesign.css" rel="stylesheet">
    <?php if(isset($page) && in_array($page, array('barang', 'kategori', 'jual'), true)){?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php }?>
    <?php if(isset($page) && $page === 'dashboard'){?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
    <?php }?>
    <style>
      #hidden {display:none}
    </style>
  </head>
  <body>
	<section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index.php" class="logo">
              <span class="store-logo-mark" aria-hidden="true"><i class="fa fa-pencil"></i></span>
              <span class="store-logo-copy"><b><?php echo htmlspecialchars($toko['nama_toko'] ?? 'ATK Suka Suka', ENT_QUOTES, 'UTF-8');?></b>
              <small class="store-address"><?php echo htmlspecialchars($toko['alamat_toko'] ?? '', ENT_QUOTES, 'UTF-8');?></small>
              </span>
            </a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                   
                <!--  notification end -->
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <?php if($role === 'admin'){?>
                    <li><a class="header-catalog-link" href="katalog_pelanggan.php"><i class="fa fa-external-link" aria-hidden="true"></i> Katalog Pelanggan</a></li>
                    <?php }?>
                    <?php $lowStockCount = $role === 'admin' ? $lihat->barang_count(true) : 0;?>
                    <?php if($role === 'admin'){?>
                    <li><a class="top-notification online-order-notification<?php echo $pendingOnlineOrders > 0 ? ' has-pending' : '';?>" href="index.php?page=pesanan" aria-label="<?php echo (int) $pendingOnlineOrders;?> pesanan online menunggu diproses" data-order-count="<?php echo (int) $pendingOnlineOrders;?>"><i class="fa fa-shopping-bag" aria-hidden="true"></i><span class="notification-count" data-order-badge aria-live="polite" aria-atomic="true"<?php echo $pendingOnlineOrders > 0 ? '' : ' hidden';?>><?php echo (int) $pendingOnlineOrders;?></span></a></li>
                    <?php }?>
                    <?php if($role === 'admin'){?>
                    <li><a class="top-notification" href="index.php?page=barang&amp;stok=yes" aria-label="<?php echo (int) $lowStockCount;?> produk stok menipis"><i class="fa fa-bell" aria-hidden="true"></i><?php if($lowStockCount > 0){?><span class="notification-count"><?php echo (int) $lowStockCount;?></span><?php }?></a></li>
                    <?php }?>
                    <li>
                      <details class="top-profile">
                        <summary><i class="fa fa-user-circle" aria-hidden="true"></i><span><?php echo htmlspecialchars($_SESSION['admin']['nm_member'] ?? 'Pengguna', ENT_QUOTES, 'UTF-8');?></span><i class="fa fa-angle-down" aria-hidden="true"></i></summary>
                        <div class="profile-menu">
                          <span class="profile-role"><?php echo $role === 'admin' ? 'Administrator' : 'Kasir';?></span>
                          <?php if($role === 'admin'){?><a href="index.php?page=user"><i class="fa fa-user" aria-hidden="true"></i> Profil</a><?php }?>
                          <form method="POST" action="logout.php">
                            <?php echo csrf_field();?>
                            <button type="submit" class="profile-logout"><i class="fa fa-sign-out" aria-hidden="true"></i> Keluar</button>
                          </form>
                        </div>
                      </details>
                    </li>
            	</ul>
            </div>
        </header>
      <!--header end-->
