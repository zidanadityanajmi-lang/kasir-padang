<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
						<h3>Pengaturan Toko</h3>
						<br>
						<?php if(isset($_GET['success'])){?>
						<div class="alert alert-success">
							<p>Ubah Data Berhasil !</p>
						</div>
						<?php }?>
						<table class="table table-stripped">
							<thead>
								<tr>
									<td>Nama Toko</td>
									<td>Alamat Toko</td>
									<td>Kontak (Hp)</td>
									<td>Nama Pemilik Toko</td>
									<td>Aksi</td>
								</tr>
							</thead>
							<tbody>
								<form method="post" action="fungsi/edit/edit.php?pengaturan=ubah">		
								<?php echo csrf_field();?>
								<tr>
									<td><input class="form-control" name="namatoko" value="<?php echo htmlspecialchars($toko['nama_toko'], ENT_QUOTES, 'UTF-8');?>" placeholder="Nama Toko"></td>
									<td><input class="form-control" name="alamat" value="<?php echo htmlspecialchars($toko['alamat_toko'], ENT_QUOTES, 'UTF-8');?>" placeholder="Alamat Toko"></td>
									<td><input class="form-control" name="kontak" value="<?php echo htmlspecialchars($toko['tlp'], ENT_QUOTES, 'UTF-8');?>" placeholder="Kontak (Hp)"></td>
									<td><input class="form-control" name="pemilik" value="<?php echo htmlspecialchars($toko['nama_pemilik'], ENT_QUOTES, 'UTF-8');?>" placeholder="Nama Pemilik Toko"></td>
									<td><button id="tombol-simpan" class="btn btn-primary"><i class="fa fa-pencil"></i> Update Data</button></td>
								</tr>
								</form>
							</tbody>
						</table>
						<div class="clearfix" style="padding-top:41%;"></div>
				  </div>
              </div>
          </section>
      </section>
	
