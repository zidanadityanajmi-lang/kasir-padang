<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php
$transactions = $lihat->transaksi_terbaru(100);
?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading">
			<div><p class="dashboard-eyebrow">Kasir &amp; penjualan</p><h1>Riwayat Transaksi</h1></div>
		</div>
		<div class="dashboard-card history-card">
			<div class="dashboard-card-heading">
				<div><p class="dashboard-eyebrow">Transaksi terbaru</p><h2>Daftar Nota</h2></div>
				<a class="btn btn-success" href="index.php?page=jual"><i class="fa fa-plus" aria-hidden="true"></i> Transaksi Baru</a>
			</div>
			<?php if (!$transactions) { ?>
				<p class="dashboard-empty">Belum ada transaksi yang tercatat.</p>
			<?php } else { ?>
				<div class="table-responsive">
					<table class="table table-hover" id="example1">
						<thead><tr><th>No. Nota</th><th>Tanggal</th><th>Kasir</th><th>Jenis Produk</th><th>Jumlah Item</th><th>Total</th></tr></thead>
						<tbody>
						<?php foreach ($transactions as $transaction) { ?>
							<tr>
								<td>#<?php echo (int) $transaction['receipt_number'];?></td>
								<td><?php echo htmlspecialchars($transaction['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo htmlspecialchars($transaction['nm_member'] ?? 'Kasir', ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo number_format((int) $transaction['jenis_barang']);?></td>
								<td><?php echo number_format((int) $transaction['jumlah']);?></td>
								<td><strong>Rp <?php echo number_format((int) $transaction['total'], 0, ',', '.');?></strong></td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			<?php } ?>
		</div>
	</section>
</section>
