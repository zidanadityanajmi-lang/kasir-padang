<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses laporan hanya untuk admin.');
}

require 'config.php';
include $view;
$lihat = new view($config);

$bulanTes = array(
	'01' => 'Januari', '02' => 'Februari', '03' => 'Maret',
	'04' => 'April', '05' => 'Mei', '06' => 'Juni',
	'07' => 'Juli', '08' => 'Agustus', '09' => 'September',
	'10' => 'Oktober', '11' => 'November', '12' => 'Desember'
);
$reportMode = 'month';
$reportMonth = date('m');
$reportYear = date('Y');
$reportDay = date('Y-m-d');

if(isset($_GET['cari'])){
	$requestedMonth = (string) ($_GET['bln'] ?? '');
	$requestedYear = filter_var($_GET['thn'] ?? null, FILTER_VALIDATE_INT);
	if(!preg_match('/^(0[1-9]|1[0-2])$/', $requestedMonth) || $requestedYear === false || $requestedYear < 2017 || $requestedYear > (int) date('Y')){
	http_response_code(400);
	exit('Filter bulan/tahun tidak valid.');
	}
	$reportMonth = $requestedMonth;
	$reportYear = (string) $requestedYear;
	$hasil = $lihat->periode_jual($reportMonth . '-' . $reportYear);
	$reportTitle = 'Data Laporan Penjualan ' . $bulanTes[$reportMonth] . ' ' . $reportYear;
	$filenamePeriod = $reportYear . '-' . $reportMonth;
}elseif(isset($_GET['hari'])){
	$requestedDay = (string) ($_GET['tgl'] ?? '');
	$parsedDay = DateTime::createFromFormat('!Y-m-d', $requestedDay);
	if(!$parsedDay || $parsedDay->format('Y-m-d') !== $requestedDay){
	http_response_code(400);
	exit('Filter tanggal tidak valid.');
	}
	$reportMode = 'day';
	$reportDay = $requestedDay;
	$hasil = $lihat->hari_jual($reportDay);
	$dayParts = explode('-', $reportDay);
	$reportTitle = 'Data Laporan Penjualan ' . (int) $dayParts[2] . ' ' . $bulanTes[$dayParts[1]] . ' ' . $dayParts[0];
	$filenamePeriod = $reportDay;
}else{
	$hasil = $lihat->periode_jual($reportMonth . '-' . $reportYear);
	$reportTitle = 'Data Laporan Penjualan ' . $bulanTes[$reportMonth] . ' ' . $reportYear;
	$filenamePeriod = $reportYear . '-' . $reportMonth;
}

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="data-laporan-' . $filenamePeriod . '.xls"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="UTF-8">
	<title><?php echo htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8');?></title>
</head>
<body>
	<h3 style="text-align:center;"><?php echo htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8');?></h3>
	<table border="1" width="100%" cellpadding="4" cellspacing="0">
		<thead>
			<tr style="background:#e8f1eb;">
				<th>No.</th>
				<th>ID Barang</th>
				<th>Nama Barang</th>
				<th>Jumlah</th>
				<th>Modal</th>
				<th>Omzet</th>
				<th>Kasir</th>
				<th>Tanggal Input</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$number = 1;
			$quantityTotal = 0;
			$modalTotal = 0;
			$omzetTotal = 0;
			$hasEstimatedModal = false;
			foreach($hasil as $row){
				$quantity = (int) $row['jumlah'];
				$unitCost = isset($row['harga_modal']) && $row['harga_modal'] !== null && $row['harga_modal'] !== '' ? (int) $row['harga_modal'] : (int) ($row['harga_beli'] ?? 0);
				if (!isset($row['harga_modal']) || $row['harga_modal'] === null || $row['harga_modal'] === '') {
					$hasEstimatedModal = true;
				}
				$lineModal = $unitCost * $quantity;
				$lineOmzet = (int) $row['total'];
				$quantityTotal += $quantity;
				$modalTotal += $lineModal;
				$omzetTotal += $lineOmzet;
			?>
			<tr>
				<td><?php echo $number++;?></td>
				<td><?php echo htmlspecialchars($row['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
				<td><?php echo htmlspecialchars($row['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
				<td><?php echo $quantity;?></td>
				<td><?php echo $lineModal;?></td>
				<td><?php echo $lineOmzet;?></td>
				<td><?php echo htmlspecialchars($row['nm_member'], ENT_QUOTES, 'UTF-8');?></td>
				<td><?php echo htmlspecialchars($row['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
			</tr>
			<?php }?>
			<?php if(!$hasil){?><tr><td colspan="8">Tidak ada transaksi pada periode ini.</td></tr><?php }?>
			<tr style="font-weight:bold;background:#f2f7f4;">
				<td colspan="3">Total Terjual</td>
				<td><?php echo $quantityTotal;?></td>
				<td><?php echo $modalTotal;?></td>
				<td><?php echo $omzetTotal;?></td>
				<td colspan="2">Profit Bersih: <?php echo $omzetTotal - $modalTotal;?></td>
			</tr>
		</tbody>
	</table>
	<?php if($hasEstimatedModal){?><p>Catatan: transaksi lama tanpa snapshot harga modal menggunakan harga beli saat ini sebagai estimasi profit.</p><?php }?>
</body>
</html>