<?php

function customer_workflow_notify(PDO $db, $customerId, $orderId, $title, $message)
{
	if (!$customerId) {
		return;
	}

	$query = $db->prepare(
		'INSERT INTO notifikasi_pelanggan (id_pelanggan, id_pesanan, judul, pesan, tanggal_input)
			VALUES (?, ?, ?, ?, ?)'
	);
	$query->execute(array(
		(int) $customerId,
		$orderId ? (int) $orderId : null,
		(string) $title,
		(string) $message,
		date('Y-m-d H:i:s')
	));
}

function customer_workflow_record_status(PDO $db, $orderId, $previous, $next, $note, $memberId, $customerId)
{
	$query = $db->prepare(
		'INSERT INTO riwayat_status_pesanan
			(id_pesanan, status_sebelum, status_sesudah, catatan, id_member, id_pelanggan, tanggal_input)
			VALUES (?, ?, ?, ?, ?, ?, ?)'
	);
	$query->execute(array(
		(int) $orderId,
		$previous !== null ? (string) $previous : null,
		(string) $next,
		$note !== '' ? (string) $note : null,
		$memberId ? (int) $memberId : null,
		$customerId ? (int) $customerId : null,
		date('Y-m-d H:i:s')
	));
}

function customer_workflow_audit(PDO $db, $memberId, $activity, $entity, $entityId, array $before = array(), array $after = array())
{
	$query = $db->prepare(
		'INSERT INTO audit_log
			(id_member, aktivitas, entitas, id_entitas, data_sebelum, data_sesudah, alamat_ip, tanggal_input)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
	);
	$query->execute(array(
		$memberId ? (int) $memberId : null,
		(string) $activity,
		(string) $entity,
		$entityId !== null ? (string) $entityId : null,
		$before ? json_encode($before, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
		$after ? json_encode($after, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
		substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null,
		date('Y-m-d H:i:s')
	));
}
