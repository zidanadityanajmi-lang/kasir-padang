CREATE TABLE `voucher` (
  `id_voucher` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(40) NOT NULL,
  `jenis_diskon` varchar(20) NOT NULL,
  `nilai_diskon` bigint unsigned NOT NULL,
  `minimal_pembelian` bigint unsigned NOT NULL DEFAULT 0,
  `maksimal_potongan` bigint unsigned DEFAULT NULL,
  `tanggal_mulai` datetime NOT NULL,
  `tanggal_berakhir` datetime NOT NULL,
  `kuota_total` int unsigned DEFAULT NULL,
  `batas_per_pelanggan` int unsigned NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `id_member_pembuat` int(11) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_voucher`),
  UNIQUE KEY `uq_voucher_code` (`kode`),
  KEY `idx_voucher_active_dates` (`is_active`, `tanggal_mulai`, `tanggal_berakhir`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `voucher_pemakaian` (
  `id_pemakaian_voucher` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_voucher` bigint unsigned NOT NULL,
  `id_pesanan` bigint unsigned NOT NULL,
  `id_pelanggan` bigint unsigned DEFAULT NULL,
  `customer_key` varchar(100) NOT NULL,
  `kode_voucher` varchar(40) NOT NULL,
  `subtotal_produk` bigint unsigned NOT NULL,
  `diskon` bigint unsigned NOT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_pemakaian_voucher`),
  UNIQUE KEY `uq_voucher_order` (`id_pesanan`),
  KEY `idx_voucher_customer_usage` (`id_voucher`, `customer_key`, `tanggal_input`),
  KEY `idx_voucher_quota_usage` (`id_voucher`, `tanggal_input`),
  CONSTRAINT `fk_voucher_usage_voucher` FOREIGN KEY (`id_voucher`)
    REFERENCES `voucher` (`id_voucher`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_voucher_usage_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_voucher_usage_customer` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `pesanan`
  ADD COLUMN `id_voucher` bigint unsigned DEFAULT NULL AFTER `id_alamat`,
  ADD COLUMN `kode_voucher` varchar(40) DEFAULT NULL AFTER `id_voucher`,
  ADD COLUMN `subtotal_produk` bigint unsigned NOT NULL DEFAULT 0 AFTER `total`,
  ADD COLUMN `diskon_voucher` bigint unsigned NOT NULL DEFAULT 0 AFTER `subtotal_produk`,
  ADD KEY `idx_pesanan_voucher` (`id_voucher`),
  ADD CONSTRAINT `fk_pesanan_voucher` FOREIGN KEY (`id_voucher`)
    REFERENCES `voucher` (`id_voucher`) ON DELETE SET NULL ON UPDATE CASCADE;

UPDATE `pesanan` SET `subtotal_produk` = `total` WHERE `subtotal_produk` = 0;

CREATE TABLE `retur_pesanan` (
  `id_retur` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pesanan` bigint unsigned NOT NULL,
  `id_pelanggan` bigint unsigned NOT NULL,
  `alasan` varchar(2000) NOT NULL,
  `bukti_foto` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `catatan_admin` varchar(1000) DEFAULT NULL,
  `id_member_peninjau` int(11) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  `tanggal_barang_diterima` datetime DEFAULT NULL,
  `tanggal_pemeriksaan` datetime DEFAULT NULL,
  PRIMARY KEY (`id_retur`),
  KEY `idx_return_order_status` (`id_pesanan`, `status`, `tanggal_input`),
  KEY `idx_return_customer_date` (`id_pelanggan`, `tanggal_input`),
  CONSTRAINT `fk_return_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_return_customer` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `detail_retur` (
  `id_detail_retur` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_retur` bigint unsigned NOT NULL,
  `id_barang` varchar(255) NOT NULL,
  `nama_barang` text NOT NULL,
  `jumlah_diminta` int unsigned NOT NULL,
  `jumlah_diterima` int unsigned NOT NULL DEFAULT 0,
  `jumlah_stok_dikembalikan` int unsigned NOT NULL DEFAULT 0,
  `catatan_pemeriksaan` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_detail_retur`),
  UNIQUE KEY `uq_return_product` (`id_retur`, `id_barang`),
  CONSTRAINT `fk_return_detail_return` FOREIGN KEY (`id_retur`)
    REFERENCES `retur_pesanan` (`id_retur`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `pengembalian_dana` (
  `id_pengembalian_dana` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pesanan` bigint unsigned NOT NULL,
  `id_retur` bigint unsigned DEFAULT NULL,
  `nominal` bigint unsigned NOT NULL,
  `tanggal_refund` datetime NOT NULL,
  `metode_refund` varchar(60) NOT NULL,
  `referensi_transaksi` varchar(120) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'waiting',
  `catatan_admin` varchar(1000) DEFAULT NULL,
  `id_member_pemroses` int(11) DEFAULT NULL,
  `id_member_verifikator` int(11) DEFAULT NULL,
  `tanggal_verifikasi` datetime DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pengembalian_dana`),
  UNIQUE KEY `uq_refund_order` (`id_pesanan`),
  UNIQUE KEY `uq_refund_return` (`id_retur`),
  KEY `idx_refund_status_date` (`status`, `tanggal_update`),
  CONSTRAINT `fk_refund_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_refund_return` FOREIGN KEY (`id_retur`)
    REFERENCES `retur_pesanan` (`id_retur`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `riwayat_pengembalian_dana` (
  `id_riwayat_refund` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pengembalian_dana` bigint unsigned NOT NULL,
  `status_sebelum` varchar(20) DEFAULT NULL,
  `status_sesudah` varchar(20) NOT NULL,
  `catatan` varchar(1000) DEFAULT NULL,
  `id_member` int(11) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_riwayat_refund`),
  KEY `idx_refund_history` (`id_pengembalian_dana`, `tanggal_input`),
  CONSTRAINT `fk_refund_history_refund` FOREIGN KEY (`id_pengembalian_dana`)
    REFERENCES `pengembalian_dana` (`id_pengembalian_dana`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pengembalian_dana`
  (`id_pesanan`, `nominal`, `tanggal_refund`, `metode_refund`, `status`, `tanggal_input`)
SELECT `id_pesanan`, 0, `tanggal_input`, 'Belum dicatat', 'waiting', `tanggal_input`
FROM `pesanan`
WHERE `status` = 'cancelled' AND `status_pembayaran` = 'refund_pending';

INSERT INTO `riwayat_pengembalian_dana`
  (`id_pengembalian_dana`, `status_sebelum`, `status_sesudah`, `catatan`, `tanggal_input`)
SELECT `id_pengembalian_dana`, NULL, 'waiting', 'Pengembalian dana lama menunggu pencatatan manual', `tanggal_input`
FROM `pengembalian_dana`
WHERE `status` = 'waiting';
