<?php 
require __DIR__ . '/../session.php';
start_secure_session();
	if (empty($_SESSION['admin']['id_member']) || !isset($_SESSION['admin']['level']) || !in_array($_SESSION['admin']['level'], array('admin', 'pembeli'), true)) {
		http_response_code(401);
	exit('Silakan login kembali.');
}
	$role = $_SESSION['admin']['level'];
	$adminActions = array('kategori', 'barang', 'laporan');
	if ($role !== 'admin') {
		foreach ($adminActions as $action) {
			if (isset($_GET[$action])) {
				http_response_code(403);
				exit('Akses ditolak.');
			}
		}
	}
	$deleteActions = array('kategori', 'barang', 'jual', 'penjualan', 'laporan');
	foreach ($deleteActions as $action) {
		if (isset($_GET[$action])) {
			if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
				http_response_code(405);
				exit('Metode permintaan tidak diizinkan.');
			}
			if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
				http_response_code(403);
				exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
			}
		}
	}
	{
	require '../../config.php';
	require_once __DIR__ . '/../product_image.php';
	if(!empty($_GET['kategori'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		if ($id === false) {
			http_response_code(400);
			exit('ID kategori tidak valid.');
		}
		$usedCategory = $config->prepare('SELECT 1 FROM barang WHERE id_kategori = ? LIMIT 1');
		$usedCategory->execute(array($id));
		if ($usedCategory->fetchColumn()) {
			header('Location: ../../index.php?page=kategori&error=used');
			exit;
		}
		$data[] = $id;
		$sql = 'DELETE FROM kategori WHERE id_kategori=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		header('Location: ../../index.php?page=kategori&remove=deleted');
		exit;
	}
	if(!empty($_GET['barang'])){
		$id = trim((string) ($_POST['id'] ?? ''));
		if ($id === '') {
			http_response_code(400);
			exit('ID barang tidak valid.');
		}
		$config->beginTransaction();
		$productLock = $config->prepare('SELECT id_barang, gambar FROM barang WHERE id_barang = ? FOR UPDATE');
		$productLock->execute(array($id));
		$product = $productLock->fetch(PDO::FETCH_ASSOC);
		if (!$product) {
			$config->rollBack();
			header('Location: ../../index.php?page=barang&error=notfound');
			exit;
		}
		$usedProduct = $config->prepare(
			'SELECT 1 FROM nota WHERE id_barang = ?
				UNION ALL SELECT 1 FROM penjualan WHERE id_barang = ?
				UNION ALL
				SELECT 1 FROM detail_pesanan detail
					INNER JOIN pesanan online_order ON online_order.id_pesanan = detail.id_pesanan
					WHERE detail.id_barang = ? AND online_order.status = ? LIMIT 1'
		);
		$usedProduct->execute(array($id, $id, $id, 'pending'));
		if ($usedProduct->fetchColumn()) {
			$config->rollBack();
			header('Location: ../../index.php?page=barang&error=linked');
			exit;
		}
		$row = $config->prepare('DELETE FROM barang WHERE id_barang = ?');
		$row->execute(array($id));
		$config->commit();
		delete_product_image($product['gambar'] ?? '', $config);
		header('Location: ../../index.php?page=barang&remove=deleted');
		exit;
	}
	if(!empty($_GET['jual'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		$memberId = (int) $_SESSION['admin']['id_member'];
		if ($id !== false) {
			$config->beginTransaction();
			$memberLock = $config->prepare('SELECT id_member FROM member WHERE id_member = ? FOR UPDATE');
			$memberLock->execute(array($memberId));
			$sql = 'DELETE FROM penjualan WHERE id_penjualan = ? AND id_member = ?';
			$row = $config->prepare($sql);
			$row->execute(array($id, $memberId));
			$config->commit();
		}
		header('Location: ../../index.php?page=jual');
		exit;
	}
	if(!empty($_GET['penjualan'])){
		$memberId = (int) $_SESSION['admin']['id_member'];
		$config->beginTransaction();
		$memberLock = $config->prepare('SELECT id_member FROM member WHERE id_member = ? FOR UPDATE');
		$memberLock->execute(array($memberId));
		$sql = 'DELETE FROM penjualan WHERE id_member = ?';
		$row = $config -> prepare($sql);
		$row -> execute(array($memberId));
		$config->commit();
		header('Location: ../../index.php?page=jual');
		exit;
	}
	if(!empty($_GET['laporan'])){
		http_response_code(410);
		exit('Penghapusan massal riwayat laporan dinonaktifkan untuk menjaga data transaksi.');
	}
}
