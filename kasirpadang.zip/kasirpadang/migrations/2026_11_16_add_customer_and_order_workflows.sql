CREATE TABLE `pelanggan_alamat` (
  `id_alamat` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pelanggan` bigint unsigned NOT NULL,
  `label` varchar(60) NOT NULL,
  `nama_penerima` varchar(120) NOT NULL,
  `no_hp` varchar(30) NOT NULL,
  `alamat_lengkap` text NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `tanggal_input` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_alamat`),
  KEY `idx_pelanggan_alamat_owner` (`id_pelanggan`, `is_default`, `id_alamat`),
  CONSTRAINT `fk_pelanggan_alamat_owner` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `daftar_wishlist` (
  `id_pelanggan` bigint unsigned NOT NULL,
  `id_barang` varchar(255) NOT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_pelanggan`, `id_barang`),
  KEY `idx_wishlist_product` (`id_barang`),
  CONSTRAINT `fk_wishlist_customer` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ulasan_produk` (
  `id_ulasan` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pelanggan` bigint unsigned NOT NULL,
  `id_pesanan` bigint unsigned NOT NULL,
  `id_barang` varchar(255) NOT NULL,
  `rating` tinyint unsigned NOT NULL,
  `ulasan` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `catatan_moderasi` varchar(500) DEFAULT NULL,
  `id_member_moderator` int(11) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_ulasan`),
  UNIQUE KEY `uq_ulasan_customer_order_product` (`id_pelanggan`, `id_pesanan`, `id_barang`),
  KEY `idx_ulasan_product_status_date` (`id_barang`, `status`, `tanggal_input`),
  KEY `idx_ulasan_customer_date` (`id_pelanggan`, `tanggal_input`),
  CONSTRAINT `fk_ulasan_customer` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ulasan_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notifikasi_pelanggan` (
  `id_notifikasi` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pelanggan` bigint unsigned NOT NULL,
  `id_pesanan` bigint unsigned DEFAULT NULL,
  `judul` varchar(160) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal_baca` datetime DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_notifikasi`),
  KEY `idx_notifikasi_customer_unread` (`id_pelanggan`, `tanggal_baca`, `id_notifikasi`),
  KEY `idx_notifikasi_order` (`id_pesanan`),
  CONSTRAINT `fk_notifikasi_customer` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notifikasi_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `riwayat_status_pesanan` (
  `id_riwayat_status` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pesanan` bigint unsigned NOT NULL,
  `status_sebelum` varchar(30) DEFAULT NULL,
  `status_sesudah` varchar(30) NOT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `id_member` int(11) DEFAULT NULL,
  `id_pelanggan` bigint unsigned DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_riwayat_status`),
  KEY `idx_order_status_history` (`id_pesanan`, `tanggal_input`),
  CONSTRAINT `fk_order_status_history_order` FOREIGN KEY (`id_pesanan`)
    REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_log` (
  `id_audit_log` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_member` int(11) DEFAULT NULL,
  `aktivitas` varchar(120) NOT NULL,
  `entitas` varchar(60) NOT NULL,
  `id_entitas` varchar(255) DEFAULT NULL,
  `data_sebelum` longtext DEFAULT NULL,
  `data_sesudah` longtext DEFAULT NULL,
  `alamat_ip` varchar(45) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_audit_log`),
  KEY `idx_audit_entity_date` (`entitas`, `id_entitas`, `tanggal_input`),
  KEY `idx_audit_actor_date` (`id_member`, `tanggal_input`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `pesanan`
  ADD COLUMN `id_alamat` bigint unsigned DEFAULT NULL AFTER `id_pelanggan`,
  ADD COLUMN `status_pengiriman` varchar(20) NOT NULL DEFAULT 'not_applicable' AFTER `status_pembayaran`,
  ADD COLUMN `jasa_pengiriman` varchar(100) DEFAULT NULL AFTER `status_pengiriman`,
  ADD COLUMN `nomor_resi` varchar(100) DEFAULT NULL AFTER `jasa_pengiriman`,
  ADD COLUMN `tanggal_dikirim` datetime DEFAULT NULL AFTER `nomor_resi`,
  ADD COLUMN `alasan_pembatalan` varchar(1000) DEFAULT NULL AFTER `tanggal_dikirim`,
  ADD COLUMN `status_pembatalan` varchar(20) NOT NULL DEFAULT 'none' AFTER `alasan_pembatalan`,
  ADD COLUMN `catatan_pembatalan_admin` varchar(1000) DEFAULT NULL AFTER `status_pembatalan`,
  ADD COLUMN `tanggal_permintaan_pembatalan` datetime DEFAULT NULL AFTER `catatan_pembatalan_admin`,
  ADD COLUMN `biaya_pengiriman` bigint unsigned NOT NULL DEFAULT 0 AFTER `total`,
  ADD KEY `idx_pesanan_shipping_status` (`status_pengiriman`, `tanggal_input`),
  ADD KEY `idx_pesanan_cancel_status` (`status_pembatalan`, `tanggal_permintaan_pembatalan`),
  ADD CONSTRAINT `fk_pesanan_alamat` FOREIGN KEY (`id_alamat`)
    REFERENCES `pelanggan_alamat` (`id_alamat`) ON DELETE SET NULL ON UPDATE CASCADE;

INSERT INTO `riwayat_status_pesanan`
  (`id_pesanan`, `status_sebelum`, `status_sesudah`, `catatan`, `tanggal_input`)
SELECT `id_pesanan`, NULL, `status`, 'Status saat sistem pelacakan diaktifkan', `tanggal_input`
FROM `pesanan`;
