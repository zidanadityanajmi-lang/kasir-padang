(function () {
	'use strict';

	document.querySelectorAll('[data-product-image-input]').forEach(function (input) {
		input.addEventListener('change', function () {
			var file = input.files && input.files[0];
			var previewSelector = input.getAttribute('data-preview-target');
			var preview = previewSelector ? document.querySelector(previewSelector) : null;
			if (!file || !preview) {
				return;
			}

			if (file.size > 2 * 1024 * 1024) {
				input.value = '';
				window.alert('Ukuran foto produk maksimal 2 MB.');
				return;
			}

			var previousUrl = input.dataset.previewObjectUrl;
			var previewUrl = URL.createObjectURL(file);
			preview.onload = function () {
				if (previousUrl) {
					URL.revokeObjectURL(previousUrl);
				}
				preview.onload = null;
			};
			preview.src = previewUrl;
			input.dataset.previewObjectUrl = previewUrl;
		});
	});
}());
