<?php

function start_secure_session()
{
	if (session_status() === PHP_SESSION_ACTIVE) {
		return;
	}

	$isHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
	ini_set('session.use_strict_mode', '1');
	ini_set('session.use_only_cookies', '1');
	session_set_cookie_params(array(
		'lifetime' => 0,
		'path' => '/',
		'domain' => '',
		'secure' => $isHttps,
		'httponly' => true,
		'samesite' => 'Lax'
	));
	session_start();
}

function csrf_token()
{
	if (empty($_SESSION['_csrf_token'])) {
		$_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
	}

	return $_SESSION['_csrf_token'];
}

function csrf_field()
{
	return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function valid_csrf_token($token)
{
	return is_string($token)
		&& isset($_SESSION['_csrf_token'])
		&& hash_equals($_SESSION['_csrf_token'], $token);
}
