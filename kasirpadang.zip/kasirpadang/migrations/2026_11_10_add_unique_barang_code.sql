-- Check for duplicate codes before applying this migration:
-- SELECT `id_barang`, COUNT(*) FROM `barang` GROUP BY `id_barang` HAVING COUNT(*) > 1;
ALTER TABLE `barang`
  ADD UNIQUE KEY `uq_barang_id_barang` (`id_barang`);