<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}

$reviewStatuses = array('pending' => 'Menunggu moderasi', 'approved' => 'Ditampilkan', 'rejected' => 'Ditolak');
$filter = isset($_GET['status']) && isset($reviewStatuses[$_GET['status']]) ? $_GET['status'] : 'pending';
$reviewQuery = $config->prepare(
	'SELECT r.id_ulasan, r.id_pesanan, r.id_barang, r.rating, r.ulasan, r.status, r.catatan_moderasi,
			r.tanggal_input, p.nama_pelanggan, b.nama_barang
		FROM ulasan_produk r
		INNER JOIN pelanggan p ON p.id_pelanggan = r.id_pelanggan
		LEFT JOIN barang b ON b.id_barang = r.id_barang
		WHERE r.status = ?
		ORDER BY r.tanggal_input DESC, r.id_ulasan DESC LIMIT 100'
);
$reviewQuery->execute(array($filter));
$reviews = $reviewQuery->fetchAll(PDO::FETCH_ASSOC);
$reviewNotice = array(
	'updated' => 'Status ulasan diperbarui dan pelanggan telah diberi notifikasi.',
	'invalid' => 'Permintaan moderasi tidak valid.',
	'error' => 'Ulasan tidak dapat diperbarui.'
);
?>
<section id="main-content"><section class="wrapper">
	<div class="page-heading"><div><p class="dashboard-eyebrow">Katalog pelanggan</p><h1>Moderasi Ulasan</h1></div></div>
	<?php if (isset($_GET['result']) && is_string($_GET['result']) && isset($reviewNotice[$_GET['result']])) { ?><div class="alert alert-<?php echo $_GET['result'] === 'updated' ? 'success' : 'warning';?>"><?php echo htmlspecialchars($reviewNotice[$_GET['result']], ENT_QUOTES, 'UTF-8');?></div><?php } ?>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Ulasan berbasis pesanan selesai</p><h2><?php echo htmlspecialchars($reviewStatuses[$filter], ENT_QUOTES, 'UTF-8');?></h2></div>
			<form method="GET" action="index.php"><input type="hidden" name="page" value="ulasan"><select name="status" aria-label="Filter status ulasan"><?php foreach ($reviewStatuses as $status => $label) { ?><option value="<?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8');?>" <?php echo $filter === $status ? 'selected' : '';?>><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8');?></option><?php } ?></select><button class="btn btn-primary btn-sm" type="submit">Filter</button></form>
		</div>
		<?php if (!$reviews) { ?><p class="dashboard-empty">Tidak ada ulasan pada status ini.</p><?php } else { ?>
			<div class="table-responsive"><table class="table">
				<thead><tr><th>Produk</th><th>Pelanggan &amp; Pesanan</th><th>Ulasan</th><th>Status</th><th>Aksi</th></tr></thead>
				<tbody><?php foreach ($reviews as $review) { ?>
					<tr>
						<td><strong><?php echo htmlspecialchars($review['nama_barang'] ?: $review['id_barang'], ENT_QUOTES, 'UTF-8');?></strong><br><?php echo (int) $review['rating'];?> / 5</td>
						<td><?php echo htmlspecialchars($review['nama_pelanggan'], ENT_QUOTES, 'UTF-8');?><br><small>Pesanan #<?php echo (int) $review['id_pesanan'];?> · <?php echo htmlspecialchars($review['tanggal_input'], ENT_QUOTES, 'UTF-8');?></small></td>
						<td><?php echo nl2br(htmlspecialchars($review['ulasan'], ENT_QUOTES, 'UTF-8'));?><?php if (!empty($review['catatan_moderasi'])) { ?><br><small>Catatan: <?php echo htmlspecialchars($review['catatan_moderasi'], ENT_QUOTES, 'UTF-8');?></small><?php } ?></td>
						<td><?php echo htmlspecialchars($reviewStatuses[$review['status']] ?? $review['status'], ENT_QUOTES, 'UTF-8');?></td>
						<td><?php if ($review['status'] === 'pending') { ?>
							<form method="POST" action="admin/module/ulasan/process.php"><?php echo csrf_field();?><input type="hidden" name="review_id" value="<?php echo (int) $review['id_ulasan'];?>"><input type="hidden" name="status" value="approved"><button class="btn btn-success btn-sm" type="submit">Setujui</button></form>
							<form method="POST" action="admin/module/ulasan/process.php"><input type="hidden" name="_csrf" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');?>"><input type="hidden" name="review_id" value="<?php echo (int) $review['id_ulasan'];?>"><input type="hidden" name="status" value="rejected"><input type="text" name="note" maxlength="500" placeholder="Alasan penolakan" required><button class="btn btn-default btn-sm" type="submit">Tolak</button></form>
						<?php } ?></td>
					</tr>
				<?php } ?></tbody>
			</table></div>
		<?php } ?>
	</div>
</section></section>
