<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$customerId = (int) ($_SESSION['customer']['id_pelanggan'] ?? 0);
if ($customerId < 1) {
	http_response_code(401);
	echo json_encode(array('error' => 'Silakan masuk untuk melihat status pesanan.'));
	exit;
}

require __DIR__ . '/config.php';
$activeCustomer = $config->prepare("SELECT 1 FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1");
$activeCustomer->execute(array($customerId));
if (!$activeCustomer->fetchColumn()) {
	unset($_SESSION['customer']);
	http_response_code(403);
	echo json_encode(array('error' => 'Akun pelanggan tidak aktif.'));
	exit;
}
$query = $config->prepare(
	'SELECT id_pesanan, status, status_pembayaran, status_pengiriman, status_pembatalan, jasa_pengiriman, nomor_resi
		FROM pesanan
		WHERE id_pelanggan = ? ORDER BY tanggal_input DESC LIMIT 50'
);
$query->execute(array($customerId));
$statuses = array();
foreach ($query->fetchAll(PDO::FETCH_ASSOC) as $order) {
	$statuses[(string) $order['id_pesanan']] = array(
		'status' => $order['status'],
		'payment_status' => $order['status_pembayaran'],
		'shipping_status' => $order['status_pengiriman'],
		'cancellation_status' => $order['status_pembatalan'],
		'carrier' => $order['jasa_pengiriman'],
		'tracking_number' => $order['nomor_resi']
	);
}
echo json_encode($statuses);
