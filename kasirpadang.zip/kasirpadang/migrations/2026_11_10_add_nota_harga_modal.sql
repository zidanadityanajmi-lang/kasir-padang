ALTER TABLE `nota`
  ADD COLUMN `harga_modal` varchar(255) DEFAULT NULL AFTER `total`;