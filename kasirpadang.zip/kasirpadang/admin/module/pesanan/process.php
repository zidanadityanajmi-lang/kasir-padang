<?php
require __DIR__ . '/../../../fungsi/session.php';
start_secure_session();

if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses ditolak.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	http_response_code(405);
	exit('Metode permintaan tidak diizinkan.');
}
if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code(403);
	exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
}

$orderId = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT);
$action = (string) ($_POST['action'] ?? '');
if ($orderId === false || $orderId < 1 || !in_array($action, array(
	'process', 'verify_payment', 'complete', 'cancel',
	'approve_cancel', 'reject_cancel', 'save_shipping', 'mark_delivered'
), true)) {
	header('Location: ../../../index.php?page=pesanan&error=invalid');
	exit;
}

require __DIR__ . '/../../../config.php';
require_once __DIR__ . '/../../../fungsi/stock_movement.php';
require_once __DIR__ . '/../../../fungsi/customer_workflows.php';
require_once __DIR__ . '/../../../fungsi/refund_workflow.php';
require_once __DIR__ . '/../../../fungsi/order_pricing.php';
$redirect = 'Location: ../../../index.php?page=pesanan';

try {
	$config->beginTransaction();
	$orderQuery = $config->prepare('SELECT * FROM pesanan WHERE id_pesanan = ? FOR UPDATE');
	$orderQuery->execute(array($orderId));
	$order = $orderQuery->fetch(PDO::FETCH_ASSOC);
	if (!$order) {
		$config->rollBack();
		header($redirect . '&error=notfound');
		exit;
	}
	if ($action === 'reject_cancel') {
		if ($order['status_pembatalan'] !== 'pending' || !in_array($order['status'], array('pending', 'processing'), true)) {
			$config->rollBack();
			header($redirect . '&error=cancelstate');
			exit;
		}
		$adminNote = trim((string) ($_POST['admin_note'] ?? ''));
		if (strlen($adminNote) > 1000) {
			$config->rollBack();
			header($redirect . '&error=invalid');
			exit;
		}
		$config->prepare(
			"UPDATE pesanan SET status_pembatalan = 'rejected', catatan_pembatalan_admin = ?
				WHERE id_pesanan = ? AND status_pembatalan = 'pending'"
		)->execute(array($adminNote !== '' ? $adminNote : null, $orderId));
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Permintaan pembatalan ditolak', 'Permintaan pembatalan pesanan ' . $order['kode_pesanan'] . ' tidak dapat disetujui.' . ($adminNote !== '' ? ' Catatan toko: ' . $adminNote : ''));
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Reject cancellation request', 'pesanan', $orderId, array('status_pembatalan' => 'pending'), array('status_pembatalan' => 'rejected', 'catatan' => $adminNote));
		$config->commit();
		header($redirect . '&success=cancel-rejected');
		exit;
	}
	if ($order['status_pembatalan'] === 'pending' && $action !== 'approve_cancel') {
		$config->rollBack();
		header($redirect . '&error=cancelstate');
		exit;
	}

	if ($action === 'save_shipping') {
		if ($order['status'] !== 'processing' || $order['metode_pengambilan'] !== 'delivery'
			|| !in_array($order['status_pengiriman'], array('pending', 'shipped'), true)) {
			$config->rollBack();
			header($redirect . '&error=shippingstate');
			exit;
		}
		$carrier = trim((string) ($_POST['jasa_pengiriman'] ?? ''));
		$trackingNumber = trim((string) ($_POST['nomor_resi'] ?? ''));
		if ($carrier === '' || strlen($carrier) > 100 || $trackingNumber === '' || strlen($trackingNumber) > 100) {
			$config->rollBack();
			header($redirect . '&error=invalid');
			exit;
		}
		$config->prepare(
			"UPDATE pesanan SET status_pengiriman = 'shipped', jasa_pengiriman = ?, nomor_resi = ?, tanggal_dikirim = ?
				WHERE id_pesanan = ? AND status = 'processing' AND status_pengiriman IN ('pending', 'shipped')"
		)->execute(array($carrier, $trackingNumber, date('Y-m-d H:i:s'), $orderId));
		customer_workflow_record_status($config, $orderId, $order['status'], $order['status'], 'Pesanan dikirim via ' . $carrier . ' dengan nomor resi ' . $trackingNumber, (int) $_SESSION['admin']['id_member'], $order['id_pelanggan']);
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pesanan dalam pengiriman', 'Pesanan ' . $order['kode_pesanan'] . ' dikirim via ' . $carrier . '. Nomor resi: ' . $trackingNumber . '.');
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Update shipment tracking', 'pesanan', $orderId, array('status_pengiriman' => $order['status_pengiriman']), array('status_pengiriman' => 'shipped', 'jasa_pengiriman' => $carrier, 'nomor_resi' => $trackingNumber));
		$config->commit();
		header($redirect . '&success=shipped');
		exit;
	}

	if ($action === 'mark_delivered') {
		if ($order['status'] !== 'processing' || $order['status_pengiriman'] !== 'shipped') {
			$config->rollBack();
			header($redirect . '&error=shippingstate');
			exit;
		}
		$config->prepare("UPDATE pesanan SET status_pengiriman = 'delivered' WHERE id_pesanan = ? AND status_pengiriman = 'shipped'")
			->execute(array($orderId));
		customer_workflow_record_status($config, $orderId, $order['status'], $order['status'], 'Admin menandai pesanan telah terkirim; menunggu konfirmasi pelanggan', (int) $_SESSION['admin']['id_member'], $order['id_pelanggan']);
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pesanan telah terkirim', 'Pesanan ' . $order['kode_pesanan'] . ' ditandai terkirim. Konfirmasikan penerimaan dari halaman profil.');
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Mark shipment delivered', 'pesanan', $orderId, array('status_pengiriman' => 'shipped'), array('status_pengiriman' => 'delivered'));
		$config->commit();
		header($redirect . '&success=delivered');
		exit;
	}

	if (!in_array($order['status'], array('pending', 'processing'), true)
		|| ($action === 'process' && $order['status'] !== 'pending')) {
		$config->rollBack();
		header($redirect . '&error=notpending');
		exit;
	}

	if ($action === 'verify_payment') {
		if ($order['metode_pembayaran'] !== 'bank_transfer' || $order['status_pembayaran'] !== 'pending') {
			$config->rollBack();
			header($redirect . '&error=paymentstate');
			exit;
		}
		$verifyPayment = $config->prepare(
			"UPDATE pesanan SET status_pembayaran = 'paid', tanggal_pembayaran = ?, id_member_pemroses = ?
				WHERE id_pesanan = ? AND status IN ('pending', 'processing') AND status_pembayaran = 'pending'"
		);
		$verifyPayment->execute(array(date('Y-m-d H:i:s'), (int) $_SESSION['admin']['id_member'], $orderId));
		if ($verifyPayment->rowCount() !== 1) {
			throw new RuntimeException('Online order payment changed while verifying.');
		}
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pembayaran terverifikasi', 'Pembayaran pesanan ' . $order['kode_pesanan'] . ' telah diterima dan diverifikasi oleh toko.');
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Verify order payment', 'pesanan', $orderId, array('status_pembayaran' => 'pending'), array('status_pembayaran' => 'paid'));
		$config->commit();
		header($redirect . '&success=payment-verified');
		exit;
	}

	if ($action === 'process') {
		$updateOrder = $config->prepare(
			"UPDATE pesanan SET status = 'processing', id_member_pemroses = ?
				WHERE id_pesanan = ? AND status = 'pending'"
		);
		$updateOrder->execute(array((int) $_SESSION['admin']['id_member'], $orderId));
		if ($updateOrder->rowCount() !== 1) {
			throw new RuntimeException('Online order status changed while starting processing.');
		}
		customer_workflow_record_status($config, $orderId, 'pending', 'processing', 'Pesanan mulai diproses', (int) $_SESSION['admin']['id_member'], $order['id_pelanggan']);
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pesanan diproses', 'Pesanan ' . $order['kode_pesanan'] . ' sedang disiapkan oleh toko.');
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Process online order', 'pesanan', $orderId, array('status' => 'pending'), array('status' => 'processing'));
		$config->commit();
		header($redirect . '&success=started');
		exit;
	}

	$detailQuery = $config->prepare('SELECT * FROM detail_pesanan WHERE id_pesanan = ? ORDER BY id_barang FOR UPDATE');
	$detailQuery->execute(array($orderId));
	$details = $detailQuery->fetchAll(PDO::FETCH_ASSOC);
	if (!$details) {
		throw new RuntimeException('Pending online order has no detail rows.');
	}

	if ($action === 'cancel' || $action === 'approve_cancel') {
		if ($action === 'approve_cancel' && $order['status_pembatalan'] !== 'pending') {
			$config->rollBack();
			header($redirect . '&error=cancelstate');
			exit;
		}
		if (!in_array($order['status_pengiriman'], array('pending', 'not_applicable'), true)) {
			$config->rollBack();
			header($redirect . '&error=shippingstate');
			exit;
		}
		$stockQuery = $config->prepare('SELECT stok FROM barang WHERE id_barang = ? FOR UPDATE');
		$restoreStock = $config->prepare('UPDATE barang SET stok = CAST(stok AS UNSIGNED) + ? WHERE id_barang = ?');
		foreach ($details as $detail) {
			$stockQuery->execute(array($detail['id_barang']));
			$currentStock = $stockQuery->fetchColumn();
			if ($currentStock === false) {
				throw new RuntimeException('Product is missing while cancelling online order.');
			}
			$restoreStock->execute(array((int) $detail['jumlah'], $detail['id_barang']));
			if ($restoreStock->rowCount() !== 1) {
				throw new RuntimeException('Product is missing while cancelling online order.');
			}
			record_stock_movement(
				$config,
				$detail['id_barang'],
				'masuk',
				(int) $detail['jumlah'],
				(int) $currentStock,
				(int) $currentStock + (int) $detail['jumlah'],
				'Pengembalian stok pesanan dibatalkan',
				$order['kode_pesanan'],
				(int) $_SESSION['admin']['id_member']
			);
		}
		$updateOrder = $config->prepare(
			"UPDATE pesanan SET status = 'cancelled', status_pembatalan = 'approved',
				catatan_pembatalan_admin = CASE WHEN ? = '' THEN catatan_pembatalan_admin ELSE ? END,
				status_pembayaran = CASE
					WHEN status_pembayaran = 'paid' AND total > 0 THEN 'refund_pending'
					ELSE status_pembayaran END
				WHERE id_pesanan = ? AND status IN ('pending', 'processing')"
		);
		$adminNote = trim((string) ($_POST['admin_note'] ?? ''));
		$updateOrder->execute(array($adminNote, $adminNote, $orderId));
		if ($updateOrder->rowCount() !== 1) {
			throw new RuntimeException('Online order status changed while cancelling.');
		}
		customer_workflow_record_status($config, $orderId, $order['status'], 'cancelled', $action === 'approve_cancel' ? 'Permintaan pembatalan disetujui admin' : 'Pesanan dibatalkan admin', (int) $_SESSION['admin']['id_member'], $order['id_pelanggan']);
		if ($order['status_pembayaran'] === 'paid' && (int) $order['total'] > 0) {
			refund_workflow_create_waiting($config, $orderId, null, (int) $_SESSION['admin']['id_member']);
		}
		$refundNotice = $order['status_pembayaran'] === 'paid' && (int) $order['total'] > 0
			? ' Pengembalian dana akan dikonfirmasi setelah dana ditransfer kembali.'
			: '';
		customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pesanan dibatalkan', 'Pesanan ' . $order['kode_pesanan'] . ' dibatalkan oleh toko. Stok telah dikembalikan.' . $refundNotice);
		customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], $action === 'approve_cancel' ? 'Approve cancellation request' : 'Cancel online order', 'pesanan', $orderId, array('status' => $order['status'], 'status_pembatalan' => $order['status_pembatalan']), array('status' => 'cancelled', 'status_pembatalan' => 'approved'));
		$config->commit();
		header($redirect . '&success=cancelled');
		exit;
	}

	$productSubtotal = 0;
	foreach ($details as $detail) {
		$expectedSubtotal = (int) $detail['jumlah'] * (int) $detail['harga_jual'];
		if ((int) $detail['subtotal'] !== $expectedSubtotal) {
			throw new RuntimeException('Online order subtotal does not match its saved price snapshot.');
		}
		$productSubtotal += $expectedSubtotal;
	}
	$orderDiscount = (int) ($order['diskon_voucher'] ?? 0);
	$shippingCost = (int) ($order['biaya_pengiriman'] ?? 0);
	if ($productSubtotal !== (int) ($order['subtotal_produk'] ?? $order['total'])
		|| $orderDiscount < 0 || $orderDiscount > $productSubtotal
		|| $productSubtotal - $orderDiscount + $shippingCost !== (int) $order['total']) {
		throw new RuntimeException('Online order total does not match its saved subtotal, discount, and shipping snapshots.');
	}
	$total = (int) $order['total'];
	if ($order['metode_pembayaran'] === 'bank_transfer' && $order['status_pembayaran'] !== 'paid') {
		$config->rollBack();
		header($redirect . '&error=paymentrequired');
		exit;
	}
	if ($order['metode_pengambilan'] === 'delivery' && $order['status_pengiriman'] !== 'received') {
		$config->rollBack();
		header($redirect . '&error=shippingrequired');
		exit;
	}

	$receiptDate = date('j F Y, G:i');
	$transactionCode = 'ONL' . date('ymdHis') . bin2hex(random_bytes(5));
	$insertNota = $config->prepare(
		'INSERT INTO nota
			(kode_transaksi, id_barang, nama_barang_snapshot, id_member, jumlah, total, harga_modal, tanggal_input, periode)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
	);
	$receiptRows = array();
	$receiptNumber = null;
	$netLineSubtotals = order_net_line_subtotals($details, $orderDiscount, $productSubtotal);
	$receiptDetails = array();
	foreach ($details as $detail) {
		$detail['net_subtotal'] = $netLineSubtotals[(string) $detail['id_barang']];
		$receiptDetails[] = $detail;
	}
	foreach ($receiptDetails as $detail) {
		$insertNota->execute(array(
			$transactionCode,
			$detail['id_barang'],
			$detail['nama_barang'],
			(int) $_SESSION['admin']['id_member'],
			(int) $detail['jumlah'],
			(int) $detail['net_subtotal'],
			(int) $detail['harga_modal'],
			$receiptDate,
			date('m-Y')
		));
		if ($receiptNumber === null) {
			$receiptNumber = (int) $config->lastInsertId();
		}
		$receiptRows[] = array(
			'nama_barang' => $detail['nama_barang'],
			'jumlah' => (int) $detail['jumlah'],
			'total' => (int) $detail['net_subtotal']
		);
	}

	$paymentUpdate = $order['metode_pembayaran'] === 'pay_at_store'
		? ", status_pembayaran = 'paid', tanggal_pembayaran = ?"
		: '';
	$updateOrder = $config->prepare(
		"UPDATE pesanan SET status = 'completed', tanggal_selesai = ?, id_member_pemroses = ?, kode_transaksi = ? $paymentUpdate
			WHERE id_pesanan = ? AND status IN ('pending', 'processing')"
	);
	$updateParameters = array(
		date('Y-m-d H:i:s'),
		(int) $_SESSION['admin']['id_member'],
		$transactionCode
	);
	if ($order['metode_pembayaran'] === 'pay_at_store') {
		$updateParameters[] = date('Y-m-d H:i:s');
	}
	$updateParameters[] = $orderId;
	$updateOrder->execute($updateParameters);
	if ($updateOrder->rowCount() !== 1) {
		throw new RuntimeException('Online order status changed while completing.');
	}
	customer_workflow_record_status($config, $orderId, $order['status'], 'completed', 'Pesanan selesai dan dicatat ke nota', (int) $_SESSION['admin']['id_member'], $order['id_pelanggan']);
	customer_workflow_notify($config, $order['id_pelanggan'], $orderId, 'Pesanan selesai', 'Pesanan ' . $order['kode_pesanan'] . ' telah diselesaikan. Terima kasih telah berbelanja.');
	customer_workflow_audit($config, (int) $_SESSION['admin']['id_member'], 'Complete online order', 'pesanan', $orderId, array('status' => $order['status']), array('status' => 'completed', 'kode_transaksi' => $transactionCode));

	$config->commit();
	$_SESSION['last_receipt'] = array(
		'number' => $receiptNumber,
		'rows' => $receiptRows,
		'cashier' => $_SESSION['admin']['nm_member'] ?? 'Kasir',
		'total' => $total,
		'paid' => $total,
		'change' => 0,
		'date' => $receiptDate,
		'customer_name' => $order['nama_pelanggan'],
		'customer_phone' => $order['no_hp'],
		'order_code' => $order['kode_pesanan'],
		'pickup_method' => $order['metode_pengambilan'],
		'payment_method' => $order['metode_pembayaran']
	);
	header($redirect . '&success=completed');
	exit;
} catch (Throwable $exception) {
	if ($config->inTransaction()) {
		$config->rollBack();
	}
	error_log('Online order processing failed: ' . $exception->getMessage());
	header($redirect . '&error=processing');
	exit;
}
