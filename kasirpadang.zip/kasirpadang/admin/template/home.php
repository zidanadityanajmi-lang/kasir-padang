<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php
$dashboard = $lihat->dashboard_data();
$recentTransactions = $lihat->transaksi_terbaru(5);
$memberName = trim((string) ($_SESSION['admin']['nm_member'] ?? 'Kasir'));
$dateLabels = array(
	'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
	'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu'
);
$monthLabels = array(
	'January' => 'Januari', 'February' => 'Februari', 'March' => 'Maret', 'April' => 'April',
	'May' => 'Mei', 'June' => 'Juni', 'July' => 'Juli', 'August' => 'Agustus',
	'September' => 'September', 'October' => 'Oktober', 'November' => 'November', 'December' => 'Desember'
);
$todayLabel = $dateLabels[date('l')] . ', ' . date('j') . ' ' . $monthLabels[date('F')] . ' ' . date('Y');
$requestedYear = filter_var($_GET['year'] ?? date('Y'), FILTER_VALIDATE_INT);
$requestedYear = $requestedYear === false ? (int) date('Y') : $requestedYear;
$monthlySales = $lihat->dashboard_monthly_sales($requestedYear);
$selectedYear = in_array($requestedYear, $monthlySales['years'], true) ? $requestedYear : (int) date('Y');
if ($selectedYear !== $monthlySales['year']) {
	$monthlySales = $lihat->dashboard_monthly_sales($selectedYear);
}
$monthNames = array('Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
?>
<section id="main-content">
	<section class="wrapper">
		<div class="dashboard-welcome">
			<div class="dashboard-welcome-copy">
				<p class="dashboard-eyebrow">Ringkasan toko</p>
				<h1>Selamat datang, <?php echo htmlspecialchars($memberName, ENT_QUOTES, 'UTF-8');?>!</h1>
				<p>Kelola toko ATK Anda dengan mudah dan efisien.</p>
			</div>
			<div class="welcome-stationery" aria-hidden="true">
				<svg viewBox="0 0 220 150" role="presentation">
					<rect x="38" y="24" width="104" height="112" rx="12" fill="#F8FCFA"/>
					<rect x="52" y="40" width="76" height="8" rx="4" fill="#C5DED7"/>
					<rect x="52" y="58" width="56" height="6" rx="3" fill="#DCEBE6"/>
					<rect x="52" y="73" width="66" height="6" rx="3" fill="#DCEBE6"/>
					<rect x="52" y="88" width="42" height="6" rx="3" fill="#DCEBE6"/>
					<path d="M151 32l18 8-46 86-19 8 1-20z" fill="#F3C66B"/>
					<path d="M104 114l19 12-20 8z" fill="#F8FCFA"/>
					<path d="M151 32l7-12a7 7 0 0 1 10-3l7 4a7 7 0 0 1 3 10l-7 12z" fill="#F28C75"/>
					<circle cx="177" cy="106" r="20" fill="#94CDB8"/>
					<path d="M170 106h14M177 99v14" stroke="#fff" stroke-width="4" stroke-linecap="round"/>
				</svg>
			</div>
			<div class="dashboard-welcome-actions">
				<span class="dashboard-date"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo htmlspecialchars($todayLabel, ENT_QUOTES, 'UTF-8');?></span>
				<a href="index.php?page=jual" class="btn btn-success dashboard-new-sale">
					<i class="fa fa-plus" aria-hidden="true"></i> Transaksi Kasir Baru
				</a>
			</div>
		</div>

		<?php if (isset($_GET['success-stok'])) { ?>
			<div class="alert alert-success" role="status">Stok produk berhasil diperbarui.</div>
		<?php } ?>
		<?php if ($dashboard['low_stock_count'] > 0) { ?>
			<div class="alert alert-warning dashboard-stock-alert" role="status">
				<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
				Ada <strong><?php echo (int) $dashboard['low_stock_count'];?></strong> produk dengan stok 5 atau kurang.
				<a href="index.php?page=barang&amp;stok=yes">Lihat stok menipis <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
			</div>
		<?php } ?>

		<div class="dashboard-section-heading">
			<div><p class="dashboard-eyebrow">Performa hari ini</p><h2>Ringkasan Operasional</h2></div>
		</div>
		<div class="row dashboard-stats">
			<div class="col-sm-6 col-lg-3">
				<article class="stat-card stat-card-sales">
					<div class="stat-card-top"><span class="stat-icon"><i class="fa fa-money" aria-hidden="true"></i></span><span class="stat-period">Hari ini</span></div>
					<p class="stat-label">Total Penjualan Hari Ini</p>
					<strong class="stat-value stat-value-currency">Rp <?php echo number_format($dashboard['today_revenue'], 0, ',', '.');?></strong>
					<a class="stat-link" href="index.php?page=laporan">Lihat laporan <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
				</article>
			</div>
			<div class="col-sm-6 col-lg-3">
				<article class="stat-card stat-card-items">
					<div class="stat-card-top"><span class="stat-icon"><i class="fa fa-file-text-o" aria-hidden="true"></i></span><span class="stat-period">Hari ini</span></div>
					<p class="stat-label">Total Transaksi</p>
					<strong class="stat-value"><?php echo number_format($dashboard['today_transactions']);?></strong>
					<a class="stat-link" href="index.php?page=riwayat">Riwayat transaksi <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
				</article>
			</div>
			<div class="col-sm-6 col-lg-3">
				<article class="stat-card stat-card-stock">
					<div class="stat-card-top"><span class="stat-icon"><i class="fa fa-cubes" aria-hidden="true"></i></span><span class="stat-period">Katalog</span></div>
					<p class="stat-label">Total Produk ATK</p>
					<strong class="stat-value"><?php echo number_format($dashboard['product_count']);?></strong>
					<a class="stat-link" href="index.php?page=barang">Kelola produk <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
				</article>
			</div>
			<div class="col-sm-6 col-lg-3">
				<article class="stat-card stat-card-warning">
					<div class="stat-card-top"><span class="stat-icon"><i class="fa fa-exclamation-circle" aria-hidden="true"></i></span><span class="stat-period">Perlu restock</span></div>
					<p class="stat-label">Peringatan Stok Menipis</p>
					<strong class="stat-value"><?php echo number_format($dashboard['low_stock_count']);?></strong>
					<a class="stat-link" href="index.php?page=barang&amp;stok=yes">Cek stok <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
				</article>
			</div>
		</div>
		<div class="row dashboard-stats dashboard-stats-secondary">
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-items"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-tags" aria-hidden="true"></i></span><span class="stat-period">Katalog</span></div><p class="stat-label">Total Kategori</p><strong class="stat-value"><?php echo number_format($dashboard['category_count']);?></strong><a class="stat-link" href="index.php?page=kategori">Kelola kategori <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-stock"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-users" aria-hidden="true"></i></span><span class="stat-period">Pelanggan</span></div><p class="stat-label">Akun Pelanggan</p><strong class="stat-value"><?php echo number_format($dashboard['customer_count']);?></strong><a class="stat-link" href="index.php?page=pelanggan">Kelola pelanggan <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-warning"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-bell" aria-hidden="true"></i></span><span class="stat-period">Perlu ditinjau</span></div><p class="stat-label">Pesanan Baru</p><strong class="stat-value"><?php echo number_format($dashboard['pending_order_count']);?></strong><a class="stat-link" href="index.php?page=pesanan">Tinjau pesanan <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-sales"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-refresh" aria-hidden="true"></i></span><span class="stat-period">Operasional</span></div><p class="stat-label">Pesanan Diproses</p><strong class="stat-value"><?php echo number_format($dashboard['processing_order_count']);?></strong><a class="stat-link" href="index.php?page=pesanan">Lihat pesanan <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
		</div>
		<div class="row dashboard-stats dashboard-stats-secondary">
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-sales"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-money" aria-hidden="true"></i></span><span class="stat-period">Semua waktu</span></div><p class="stat-label">Total Pendapatan</p><strong class="stat-value stat-value-currency">Rp <?php echo number_format($dashboard['all_time_revenue'], 0, ',', '.');?></strong><a class="stat-link" href="index.php?page=laporan">Buka laporan <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
			<div class="col-sm-6 col-lg-3"><article class="stat-card stat-card-items"><div class="stat-card-top"><span class="stat-icon"><i class="fa fa-files-o" aria-hidden="true"></i></span><span class="stat-period">Semua waktu</span></div><p class="stat-label">Total Transaksi</p><strong class="stat-value"><?php echo number_format($dashboard['all_time_transactions']);?></strong><a class="stat-link" href="index.php?page=riwayat">Lihat riwayat <i class="fa fa-arrow-right" aria-hidden="true"></i></a></article></div>
		</div>

		<div class="row dashboard-content">
			<div class="col-lg-8">
				<section class="dashboard-card">
					<div class="dashboard-card-heading">
						<div>
							<p class="dashboard-eyebrow">Performa penjualan</p>
							<h2>Tren Pendapatan &amp; Produk Terjual</h2>
							<p class="dashboard-card-subtitle">Pendapatan dan jumlah unit terjual per bulan</p>
						</div>
						<form method="GET" action="index.php" class="dashboard-year-filter">
							<input type="hidden" name="page" value="dashboard">
							<label for="dashboardYear">Pilih Tahun</label>
							<select id="dashboardYear" name="year" class="form-control" onchange="this.form.submit()">
								<?php foreach ($monthlySales['years'] as $yearOption) { ?>
									<option value="<?php echo (int) $yearOption;?>" <?php echo (int) $yearOption === $selectedYear ? 'selected' : '';?>><?php echo (int) $yearOption;?></option>
								<?php } ?>
							</select>
						</form>
					</div>
					<div class="dashboard-chart-wrap">
						<canvas id="monthlySalesChart" class="dashboard-chart-canvas" aria-label="Grafik perbandingan pendapatan dan penjualan bulanan tahun <?php echo $selectedYear;?>" role="img"></canvas>
						<div id="monthlySalesFallback" class="dashboard-chart-fallback">
							<p>Grafik interaktif tidak dapat dimuat. Ringkasan bulanan:</p>
							<div class="table-responsive">
								<table class="table table-condensed">
									<thead><tr><th>Bulan</th><th>Pendapatan</th><th>Terjual</th></tr></thead>
									<tbody>
									<?php foreach ($monthlySales['months'] as $monthIndex => $month) { ?>
										<tr>
											<td><?php echo htmlspecialchars($monthNames[$monthIndex], ENT_QUOTES, 'UTF-8');?></td>
											<td>Rp <?php echo number_format($month['revenue'], 0, ',', '.');?></td>
											<td><?php echo number_format($month['quantity']);?> unit</td>
										</tr>
									<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</section>
			</div>
			<div class="col-lg-4">
				<section class="dashboard-card dashboard-list-card">
					<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Minggu ini</p><h2>Produk Terlaris</h2></div><i class="fa fa-trophy dashboard-heading-icon" aria-hidden="true"></i></div>
					<?php if (!$dashboard['best_sellers']) { ?>
						<p class="dashboard-empty">Belum ada transaksi dalam 7 hari terakhir.</p>
					<?php } else { ?>
						<ol class="dashboard-ranking">
							<?php foreach ($dashboard['best_sellers'] as $index => $product) { ?>
								<li>
									<span class="ranking-number"><?php echo $index + 1;?></span>
									<span class="ranking-product">
										<strong class="ranking-name"><?php echo htmlspecialchars($product['nama_barang'], ENT_QUOTES, 'UTF-8');?></strong>
										<small class="ranking-price">Rata-rata Rp <?php echo number_format((int) $product['revenue'] / max(1, (int) $product['quantity']), 0, ',', '.');?> / unit</small>
									</span>
									<span class="ranking-quantity"><?php echo number_format((int) $product['quantity']);?> terjual</span>
								</li>
							<?php } ?>
						</ol>
					<?php } ?>
				</section>
			</div>
		</div>

		<div class="row dashboard-content dashboard-activity-row">
			<div class="col-lg-8">
				<section class="dashboard-card recent-transactions-card">
					<div class="dashboard-card-heading">
						<div><p class="dashboard-eyebrow">Aktivitas toko</p><h2>Transaksi Terbaru</h2></div>
						<a class="dashboard-inline-link" href="index.php?page=riwayat">Lihat semua <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
					</div>
					<?php if (!$recentTransactions) { ?>
						<p class="dashboard-empty">Belum ada transaksi yang tercatat.</p>
					<?php } else { ?>
						<div class="table-responsive">
							<table class="table dashboard-transactions-table">
								<thead><tr><th>No. Nota</th><th>Tanggal</th><th>Kasir</th><th>Jumlah item</th><th>Total</th><th>Status</th></tr></thead>
								<tbody>
								<?php foreach ($recentTransactions as $transaction) { ?>
									<tr>
										<td><strong>#<?php echo (int) $transaction['receipt_number'];?></strong></td>
										<td><?php echo htmlspecialchars($transaction['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo htmlspecialchars($transaction['nm_member'] ?? 'Kasir', ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo number_format((int) $transaction['jumlah']);?></td>
										<td><strong>Rp <?php echo number_format((int) $transaction['total'], 0, ',', '.');?></strong></td>
										<td><span class="transaction-status-badge">Selesai</span></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						</div>
					<?php } ?>
				</section>
			</div>
			<div class="col-lg-4">
				<section class="dashboard-card system-status-card">
					<div class="dashboard-card-heading">
						<div><p class="dashboard-eyebrow">Kondisi operasional</p><h2>Status Sistem</h2></div>
						<span class="system-status-badge"><i class="fa fa-check-circle" aria-hidden="true"></i> Aktif</span>
					</div>
					<ul class="system-status-list">
						<li><span><i class="fa fa-database" aria-hidden="true"></i> Data toko</span><strong>Terhubung</strong></li>
						<li><span><i class="fa fa-cubes" aria-hidden="true"></i> Produk tercatat</span><strong><?php echo number_format($dashboard['product_count']);?> produk</strong></li>
						<li><span><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Perlu restock</span><strong><?php echo number_format($dashboard['low_stock_count']);?> produk</strong></li>
					</ul>
					<p class="system-status-note">Ringkasan diperbarui saat halaman dimuat.</p>
				</section>
			</div>
		</div>

		<section class="dashboard-card dashboard-low-stock">
			<div class="dashboard-card-heading">
				<div><p class="dashboard-eyebrow">Perlu diperhatikan</p><h2>Stok Hampir Habis</h2></div>
				<a class="btn btn-default btn-sm" href="index.php?page=barang&amp;stok=yes">Semua stok menipis</a>
			</div>
			<?php if (!$dashboard['low_stock']) { ?>
				<p class="dashboard-empty">Semua stok produk berada pada kondisi aman.</p>
			<?php } else { ?>
				<div class="table-responsive">
					<table class="table dashboard-stock-table">
						<thead><tr><th>Produk</th><th>Merk</th><th>Stok tersisa</th><th>Aksi</th></tr></thead>
						<tbody>
						<?php foreach ($dashboard['low_stock'] as $product) { ?>
							<tr>
								<td><?php echo htmlspecialchars($product['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo htmlspecialchars($product['merk'], ENT_QUOTES, 'UTF-8');?></td>
								<td><span class="stock-badge stock-low"><?php echo htmlspecialchars($product['stok'], ENT_QUOTES, 'UTF-8');?> <?php echo htmlspecialchars($product['satuan_barang'], ENT_QUOTES, 'UTF-8');?></span></td>
								<td>
									<form method="POST" action="fungsi/edit/edit.php?stok=edit" class="dashboard-restock-form">
										<?php echo csrf_field();?>
										<input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id_barang'], ENT_QUOTES, 'UTF-8');?>">
										<input type="hidden" name="return_page" value="dashboard">
										<label class="sr-only" for="restock-<?php echo htmlspecialchars($product['id_barang'], ENT_QUOTES, 'UTF-8');?>">Jumlah restock untuk <?php echo htmlspecialchars($product['nama_barang'], ENT_QUOTES, 'UTF-8');?></label>
										<input id="restock-<?php echo htmlspecialchars($product['id_barang'], ENT_QUOTES, 'UTF-8');?>" type="number" min="1" step="1" required name="restok" class="form-control" placeholder="Jumlah">
										<button type="submit" class="btn btn-success btn-sm" title="Tambah stok"><i class="fa fa-plus" aria-hidden="true"></i> Restock</button>
									</form>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			<?php } ?>
		</section>
	</section>
	<script>
		(function () {
			var canvas = document.getElementById('monthlySalesChart');
			var fallback = document.getElementById('monthlySalesFallback');
			if (!canvas || !fallback || !window.Chart) {
				return;
			}

			var monthly = <?php echo json_encode($monthlySales['months'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);?>;
			var monthNames = <?php echo json_encode($monthNames, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);?>;
			var monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
			var rupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
			var integer = new Intl.NumberFormat('id-ID');

			new Chart(canvas, {
				type: 'bar',
				data: {
					labels: monthLabels,
					datasets: [
						{
							label: 'Total Pendapatan (Rp)',
							data: monthly.map(function (item) { return item.revenue; }),
							backgroundColor: '#0f766e',
							borderRadius: 5,
							maxBarThickness: 30,
							yAxisID: 'revenue'
						},
						{
							label: 'Jumlah Penjualan (Unit)',
							data: monthly.map(function (item) { return item.quantity; }),
							backgroundColor: '#f59e0b',
							borderRadius: 5,
							maxBarThickness: 30,
							yAxisID: 'quantity'
						}
					]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					interaction: { mode: 'index', intersect: false },
					plugins: {
						legend: { position: 'top', align: 'start', labels: { usePointStyle: true, pointStyle: 'rectRounded', boxWidth: 9, padding: 18 } },
						tooltip: {
							callbacks: {
								title: function (items) { return monthNames[items[0].dataIndex]; },
								label: function (context) {
									return context.dataset.label + ': ' + (context.dataset.yAxisID === 'revenue'
										? rupiah.format(context.parsed.y)
										: integer.format(context.parsed.y) + ' unit');
								}
							}
						}
					},
					scales: {
						x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: false } },
						revenue: {
							type: 'linear',
							position: 'left',
							beginAtZero: true,
							title: { display: true, text: 'Pendapatan (Rupiah)' },
							ticks: { callback: function (value) { return 'Rp ' + new Intl.NumberFormat('id-ID', { notation: 'compact', maximumFractionDigits: 1 }).format(value); } },
							grid: { color: '#edf2f2' }
						},
						quantity: {
							type: 'linear',
							position: 'right',
							beginAtZero: true,
							title: { display: true, text: 'Penjualan (Unit)' },
							ticks: { precision: 0 },
							grid: { drawOnChartArea: false }
						}
					}
				}
			});
			canvas.closest('.dashboard-chart-wrap').classList.add('chart-ready');
			fallback.hidden = true;
		}());
	</script>
</section>
