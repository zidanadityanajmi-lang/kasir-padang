<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';

$returnId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if ($returnId === false || $returnId < 1) {
	http_response_code(404);
	exit('Bukti retur tidak ditemukan.');
}
$returnQuery = $config->prepare('SELECT id_pelanggan, bukti_foto FROM retur_pesanan WHERE id_retur = ? LIMIT 1');
$returnQuery->execute(array((int) $returnId));
$return = $returnQuery->fetch(PDO::FETCH_ASSOC);
$customerId = (int) ($_SESSION['customer']['id_pelanggan'] ?? 0);
$isAdmin = !empty($_SESSION['admin']['id_member']) && ($_SESSION['admin']['level'] ?? '') === 'admin';
if ($customerId > 0) {
	$activeCustomer = $config->prepare("SELECT 1 FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1");
	$activeCustomer->execute(array($customerId));
	if (!$activeCustomer->fetchColumn()) {
		$customerId = 0;
	}
}
if (!$return || (!$isAdmin && ($customerId < 1 || $customerId !== (int) $return['id_pelanggan']))) {
	http_response_code(404);
	exit('Bukti retur tidak ditemukan.');
}

$fileName = (string) $return['bukti_foto'];
if (!preg_match('/^[a-f0-9]{40}\.(jpg|png|webp)$/', $fileName)) {
	http_response_code(404);
	exit('Bukti retur tidak ditemukan.');
}
$evidenceRoot = getenv('RETURN_EVIDENCE_DIR');
$directory = $evidenceRoot ? rtrim($evidenceRoot, DIRECTORY_SEPARATOR) : sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'atk-suka-suka-return-evidence';
$path = $directory . DIRECTORY_SEPARATOR . $fileName;
if (!is_file($path) || !is_readable($path) || !function_exists('finfo_open')) {
	http_response_code(404);
	exit('Bukti retur tidak ditemukan.');
}
$fileInfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = $fileInfo ? finfo_file($fileInfo, $path) : false;
if ($fileInfo) finfo_close($fileInfo);
$allowedMimes = array('image/jpeg', 'image/png', 'image/webp');
if (!in_array($mimeType, $allowedMimes, true)) {
	http_response_code(404);
	exit('Bukti retur tidak ditemukan.');
}

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="bukti-retur-' . (int) $returnId . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
readfile($path);
