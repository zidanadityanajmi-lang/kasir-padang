<?php

function refund_workflow_record_status(PDO $db, $refundId, $previous, $next, $note, $memberId)
{
	$query = $db->prepare(
		'INSERT INTO riwayat_pengembalian_dana
			(id_pengembalian_dana, status_sebelum, status_sesudah, catatan, id_member, tanggal_input)
			VALUES (?, ?, ?, ?, ?, ?)'
	);
	$query->execute(array(
		(int) $refundId,
		$previous !== null ? (string) $previous : null,
		(string) $next,
		$note !== '' ? (string) $note : null,
		$memberId ? (int) $memberId : null,
		date('Y-m-d H:i:s')
	));
}

function refund_workflow_create_waiting(PDO $db, $orderId, $returnId, $memberId)
{
	$existingQuery = $db->prepare('SELECT id_pengembalian_dana, id_retur, status FROM pengembalian_dana WHERE id_pesanan = ? FOR UPDATE');
	$existingQuery->execute(array((int) $orderId));
	$existing = $existingQuery->fetch(PDO::FETCH_ASSOC);
	if ($existing) {
		if ($returnId && $existing['status'] === 'rejected') {
			$now = date('Y-m-d H:i:s');
			$update = $db->prepare(
				"UPDATE pengembalian_dana SET id_retur = ?, nominal = 0, tanggal_refund = ?,
					metode_refund = 'Belum dicatat', status = 'waiting', catatan_admin = NULL,
					id_member_pemroses = ?, id_member_verifikator = NULL, tanggal_verifikasi = NULL,
					tanggal_update = ? WHERE id_pengembalian_dana = ? AND status = 'rejected'"
			);
			$update->execute(array((int) $returnId, $now, $memberId ? (int) $memberId : null, $now, (int) $existing['id_pengembalian_dana']));
			refund_workflow_record_status($db, (int) $existing['id_pengembalian_dana'], 'rejected', 'waiting', 'Permintaan retur baru disetujui; refund menunggu pencatatan', $memberId);
			return (int) $existing['id_pengembalian_dana'];
		}
		if ($returnId) {
			throw new DomainException('Pesanan ini sudah memiliki alur pengembalian dana.');
		}
		return (int) $existing['id_pengembalian_dana'];
	}

	$query = $db->prepare(
		"INSERT INTO pengembalian_dana
			(id_pesanan, id_retur, nominal, tanggal_refund, metode_refund, status, id_member_pemroses, tanggal_input)
			VALUES (?, ?, 0, ?, 'Belum dicatat', 'waiting', ?, ?)"
	);
	$now = date('Y-m-d H:i:s');
	$query->execute(array((int) $orderId, $returnId ? (int) $returnId : null, $now, $memberId ? (int) $memberId : null, $now));
	$refundId = (int) $db->lastInsertId();
	refund_workflow_record_status($db, $refundId, null, 'waiting', 'Pengembalian dana menunggu pencatatan manual', $memberId);

	return $refundId;
}
