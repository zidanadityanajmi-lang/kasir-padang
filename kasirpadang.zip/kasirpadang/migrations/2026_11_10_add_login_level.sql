ALTER TABLE `login`
  ADD COLUMN `level` enum('admin','pembeli') NOT NULL DEFAULT 'admin' AFTER `id_member`;

UPDATE `login`
SET `level` = 'admin'
WHERE `level` NOT IN ('admin', 'pembeli');

-- Example: grant catalog and checkout access to an existing account.
-- UPDATE `login` SET `level` = 'pembeli' WHERE `user` = 'username_pembeli';