CREATE TABLE `pelanggan` (
  `id_pelanggan` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_pelanggan` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `no_hp` varchar(30) NOT NULL,
  `alamat` text DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `tanggal_daftar` datetime NOT NULL,
  `tanggal_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pelanggan`),
  UNIQUE KEY `uq_pelanggan_email` (`email`),
  KEY `idx_pelanggan_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `pesanan`
  ADD COLUMN `id_pelanggan` bigint unsigned DEFAULT NULL AFTER `id_pesanan`,
  ADD KEY `idx_pesanan_customer` (`id_pelanggan`),
  ADD CONSTRAINT `fk_pesanan_pelanggan` FOREIGN KEY (`id_pelanggan`)
    REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE SET NULL ON UPDATE CASCADE;
