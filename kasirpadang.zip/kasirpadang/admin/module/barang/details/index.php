<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php require_once __DIR__ . '/../../../../fungsi/product_image.php'; ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
<?php
	$id = isset($_GET['barang']) && is_string($_GET['barang']) ? trim($_GET['barang']) : '';
	$hasil = $id !== '' ? $lihat->barang_edit($id) : false;
	if (!$hasil) {
		http_response_code(404);
		echo '<section id="main-content"><section class="wrapper"><div class="alert alert-warning">Barang tidak ditemukan.</div></section></section>';
		return;
	}
?>
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
					  	<a href="index.php?page=barang"><button class="btn btn-primary"><i class="fa fa-angle-left"></i> Balik </button></a>
						<h3>Details Barang</h3>
						<?php if(isset($_GET['success-stok'])){?>
						<div class="alert alert-success">
							<p>Tambah Stok Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['success'])){?>
						<div class="alert alert-success">
							<p>Tambah Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['remove'])){?>
						<div class="alert alert-danger">
							<p>Hapus Data Berhasil !</p>
						</div>
						<?php }?>
						<table class="table table-striped">
								<tr>
									<td>ID Barang</td>
									<td><?php echo htmlspecialchars($hasil['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Kategori</td>
									<td><?php echo htmlspecialchars($hasil['nama_kategori'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Nama Barang</td>
									<td><?php echo htmlspecialchars($hasil['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Merk Barang</td>
									<td><?php echo htmlspecialchars($hasil['merk'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Deskripsi</td>
									<td><?php echo nl2br(htmlspecialchars($hasil['deskripsi'] ?? 'Belum ada deskripsi produk.', ENT_QUOTES, 'UTF-8'));?></td>
								</tr>
								<tr>
									<td>Foto Produk</td>
									<td>
										<?php
											$productImage = basename((string) ($hasil['gambar'] ?? ''));
											$productImagePath = __DIR__ . '/../../../../assets/img/produk/' . $productImage;
											$productImageHref = $productImage !== '' && is_file($productImagePath)
												? 'assets/img/produk/' . rawurlencode($productImage) . '?v=' . (int) filemtime($productImagePath)
												: product_image_placeholder($hasil['nama_kategori'] ?? '', $hasil['nama_barang'] ?? '', $hasil['merk'] ?? '');
										?>
										<img src="<?php echo htmlspecialchars($productImageHref, ENT_QUOTES, 'UTF-8');?>" alt="Foto <?php echo htmlspecialchars($hasil['nama_barang'], ENT_QUOTES, 'UTF-8');?>" class="inventory-product-thumbnail">
									</td>
								</tr>
								<tr>
									<td>Harga Beli</td>
									<td><?php echo htmlspecialchars($hasil['harga_beli'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Harga Jual</td>
									<td><?php echo htmlspecialchars($hasil['harga_jual'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Satuan Barang</td>
									<td><?php echo htmlspecialchars($hasil['satuan_barang'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Stok</td>
									<td><?php echo htmlspecialchars($hasil['stok'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Tanggal Input</td>
									<td><?php echo htmlspecialchars($hasil['tgl_input'], ENT_QUOTES, 'UTF-8');?></td>
								</tr>
								<tr>
									<td>Tanggal Update</td>
									<td><?php echo htmlspecialchars($hasil['tgl_update'] ?? '', ENT_QUOTES, 'UTF-8');?></td>
								</tr>
						</table>
						<div class="clearfix" style="padding-top:16%;"></div>
				  </div>
              </div>
          </section>
      </section>
	
