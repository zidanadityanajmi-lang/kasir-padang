<?php

function order_net_line_subtotals(array $details, $discount, $productSubtotal)
{
	$discount = (int) $discount;
	$productSubtotal = (int) $productSubtotal;
	if ($discount < 0 || $productSubtotal < 0 || $discount > $productSubtotal) {
		throw new DomainException('Order discount does not match the saved product subtotal.');
	}

	usort($details, function ($left, $right) {
		return strcmp((string) $left['id_barang'], (string) $right['id_barang']);
	});

	$lineSubtotal = 0;
	foreach ($details as $detail) {
		$lineAmount = (int) $detail['subtotal'];
		if ($lineAmount < 0) {
			throw new DomainException('Order contains an invalid detail subtotal.');
		}
		$lineSubtotal += $lineAmount;
	}
	if ($lineSubtotal !== $productSubtotal) {
		throw new DomainException('Order detail subtotals do not match the saved product subtotal.');
	}

	$netSubtotals = array();
	$allocatedDiscount = 0;
	foreach ($details as $index => $detail) {
		$lineAmount = (int) $detail['subtotal'];
		$lineDiscount = $index === count($details) - 1
			? $discount - $allocatedDiscount
			: ($productSubtotal > 0 ? intdiv($discount * $lineAmount, $productSubtotal) : 0);
		$allocatedDiscount += $lineDiscount;
		$netSubtotals[(string) $detail['id_barang']] = $lineAmount - $lineDiscount;
	}

	return $netSubtotals;
}

function order_returnable_line_value(array $detail, $netLineSubtotal, $acceptedQuantity)
{
	$quantity = (int) ($detail['jumlah'] ?? 0);
	$acceptedQuantity = (int) $acceptedQuantity;
	if ($quantity < 1 || $acceptedQuantity < 0 || $acceptedQuantity > $quantity || (int) $netLineSubtotal < 0) {
		throw new DomainException('Return quantity does not match the saved order detail.');
	}

	return intdiv((int) $netLineSubtotal * $acceptedQuantity, $quantity);
}
