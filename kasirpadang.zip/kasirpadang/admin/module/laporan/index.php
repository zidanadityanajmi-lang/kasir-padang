<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
	  <?php 
			$bulan_tes =array(
				'01'=>"Januari",
				'02'=>"Februari",
				'03'=>"Maret",
				'04'=>"April",
				'05'=>"Mei",
				'06'=>"Juni",
				'07'=>"Juli",
				'08'=>"Agustus",
				'09'=>"September",
				'10'=>"Oktober",
				'11'=>"November",
				'12'=>"Desember"
			);
				$reportMode = 'month';
				$reportMonth = date('m');
				$reportYear = date('Y');
				$reportDay = date('Y-m-d');
				$filterError = '';

				if(isset($_GET['cari'])){
					$requestedMonth = (string) ($_GET['bln'] ?? '');
					$requestedYear = filter_var($_GET['thn'] ?? null, FILTER_VALIDATE_INT);
					if(!preg_match('/^(0[1-9]|1[0-2])$/', $requestedMonth) || $requestedYear === false || $requestedYear < 2017 || $requestedYear > (int) date('Y')){
						$filterError = 'Pilih bulan dan tahun laporan yang valid.';
					}else{
						$reportMonth = $requestedMonth;
						$reportYear = (string) $requestedYear;
					}
				}elseif(isset($_GET['hari'])){
					$requestedDay = (string) ($_GET['hari'] ?? '');
					$parsedDay = DateTime::createFromFormat('!Y-m-d', $requestedDay);
					if(!$parsedDay || $parsedDay->format('Y-m-d') !== $requestedDay){
						$filterError = 'Pilih tanggal laporan yang valid.';
					}else{
						$reportMode = 'day';
						$reportDay = $requestedDay;
					}
				}

				if($filterError !== ''){
					$hasil = array();
				}elseif($reportMode === 'day'){
					$hasil = $lihat -> hari_jual($reportDay);
				}else{
					$hasil = $lihat -> periode_jual($reportMonth . '-' . $reportYear);
				}

				if($reportMode === 'day'){
					$dayParts = explode('-', $reportDay);
					$reportTitle = 'Data Laporan Penjualan ' . (int) $dayParts[2] . ' ' . $bulan_tes[$dayParts[1]] . ' ' . $dayParts[0];
					$exportUrl = 'excel.php?hari=cek&tgl=' . rawurlencode($reportDay);
				}else{
					$reportTitle = 'Data Laporan Penjualan ' . $bulan_tes[$reportMonth] . ' ' . $reportYear;
					$exportUrl = 'excel.php?cari=yes&bln=' . rawurlencode($reportMonth) . '&thn=' . rawurlencode($reportYear);
				}
		?>
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
						<div class="page-heading report-page-heading">
							<div>
								<p class="dashboard-eyebrow">Kasir &amp; penjualan</p>
								<h1>
							<!--<a  style="padding-left:2pc;" href="fungsi/hapus/hapus.php?laporan=jual" onclick="javascript:return confirm('Data Laporan akan di Hapus ?');">
								<button class="btn btn-danger">RESET</button>
							</a>-->
							<?php echo htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8');?>
								</h1>
							</div>
						</div>
						<h4 class="report-filter-title">Cari Laporan Per Bulan</h4>
						<form class="report-filters" method="get" action="index.php">
							<input type="hidden" name="page" value="laporan">
							<input type="hidden" name="cari" value="ok">
							<table class="table table-striped">
								<tr>
									<th>
										Pilih Bulan
									</th>
									<th>
										Pilih Tahun
									</th>
									<th>
										Aksi
									</th>
								</tr>
								<tr>
								<td>
								<select name="bln" class="form-control">
									<option value="" disabled>Pilih bulan</option>
									<?php foreach($bulan_tes as $monthValue => $monthName){?>
										<option value="<?php echo $monthValue;?>" <?php echo $reportMonth === $monthValue ? 'selected' : '';?>><?php echo htmlspecialchars($monthName, ENT_QUOTES, 'UTF-8');?></option>
									<?php }?>
									</select>
								</td>
								<td>
								<select name="thn" class="form-control">
									<?php for($yearOption = 2017; $yearOption <= (int) date('Y'); $yearOption++){?>
										<option value="<?php echo $yearOption;?>" <?php echo $reportYear === (string) $yearOption ? 'selected' : '';?>><?php echo $yearOption;?></option>
									<?php }?>
								</select>
								</td>
								<td>
									<input type="hidden" name="periode" value="ya">
									<button class="btn btn-primary">
										<i class="fa fa-search"></i> Cari
									</button>
									<a href="index.php?page=laporan" class="btn btn-success">
										<i class="fa fa-refresh"></i> Refresh</a>
										
									<a href="<?php echo htmlspecialchars($exportUrl, ENT_QUOTES, 'UTF-8');?>" class="btn btn-info"><i class="fa fa-download"></i> Excel</a>
								</td>
								</tr>
							</table>
						</form>
						<form class="report-filters" method="get" action="index.php">
							<input type="hidden" name="page" value="laporan">
							<table class="table table-striped">
								<tr>
									<th>
										Pilih Hari
									</th>
									<th>
										Aksi
									</th>
								</tr>
								<tr>
								<td>
									<input type="date" value="<?php echo htmlspecialchars($reportDay, ENT_QUOTES, 'UTF-8');?>" class="form-control" name="hari" required>
								</td>
								<td>
									<input type="hidden" name="periode" value="ya">
									<button class="btn btn-primary">
										<i class="fa fa-search"></i> Cari
									</button>
									<a href="index.php?page=laporan" class="btn btn-success">
										<i class="fa fa-refresh"></i> Refresh</a>
										
									<a href="<?php echo htmlspecialchars($exportUrl, ENT_QUOTES, 'UTF-8');?>" class="btn btn-info"><i class="fa fa-download"></i> Excel</a>
								</td>
								</tr>
							</table>
						</form>
						<div class="report-actions no-print">
							<button type="button" class="btn btn-default" onclick="window.print();"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Cetak / Simpan PDF</button>
							<a class="btn btn-info" href="<?php echo htmlspecialchars($exportUrl, ENT_QUOTES, 'UTF-8');?>"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Unduh Excel</a>
						</div>
						<?php if($filterError !== ''){?>
							<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo htmlspecialchars($filterError, ENT_QUOTES, 'UTF-8');?></div>
						<?php }?>
						<div class="clearfix" style="border-top:1px solid #ccc;"></div>
						<br/>
						<br/>
						<!-- view barang -->	
						<div class="modal-view table-responsive report-table-wrap">
							<table class="table table-bordered" id="example1">
								<thead>
									<tr style="background:#DFF0D8;color:#333;">
										<th> No</th>
										<th> ID Barang</th>
										<th> Nama Barang</th>
										<th style="width:10%;"> Jumlah</th>
										<th style="width:10%;"> Modal</th>
										<th style="width:10%;"> Total</th>
										<th> Kasir</th>
										<th> Tanggal Input</th>
									</tr>
								</thead>
								<tbody>
									<?php
										$no = 1;
										$omzet = 0;
										$jumlah = 0;
										$modal = 0;
										$hasEstimatedModal = false;
										foreach($hasil as $isi){
											$quantity = (int) $isi['jumlah'];
											$unitCost = isset($isi['harga_modal']) && $isi['harga_modal'] !== null && $isi['harga_modal'] !== '' ? (int) $isi['harga_modal'] : (int) ($isi['harga_beli'] ?? 0);
											if (!isset($isi['harga_modal']) || $isi['harga_modal'] === null || $isi['harga_modal'] === '') {
												$hasEstimatedModal = true;
											}
											$lineModal = $unitCost * $quantity;
											$lineOmzet = (int) $isi['total'];
											$omzet += $lineOmzet;
											$modal += $lineModal;
											$jumlah += $quantity;
									?>
									<tr>
										<td><?php echo $no;?></td>
										<td><?php echo htmlspecialchars($isi['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo htmlspecialchars($isi['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo $quantity;?></td>
										<td>Rp <?php echo number_format($lineModal, 0, ',', '.');?></td>
										<td>Rp <?php echo number_format($lineOmzet, 0, ',', '.');?></td>
										<td><?php echo htmlspecialchars($isi['nm_member'], ENT_QUOTES, 'UTF-8');?></td>
										<td><?php echo htmlspecialchars($isi['tanggal_input'], ENT_QUOTES, 'UTF-8');?></td>
									</tr>
									<?php $no++; }?>
									<?php if(!$hasil){?><tr><td colspan="8" class="text-center">Tidak ada transaksi pada periode ini.</td></tr><?php }?>
								</tbody>
								<tfoot>
									<tr>
										<th colspan="3">Total Terjual</th>
										<th><?php echo number_format($jumlah, 0, ',', '.');?></th>
										<th>Modal: Rp <?php echo number_format($modal, 0, ',', '.');?></th>
										<th>Omzet: Rp <?php echo number_format($omzet, 0, ',', '.');?></th>
										<th colspan="2" class="report-profit">Profit Bersih: Rp <?php echo number_format($omzet - $modal, 0, ',', '.');?></th>
									</tr>
								</tfoot>
							</table>
						</div>
						<?php if($hasEstimatedModal){?>
							<div class="alert alert-warning"><i class="fa fa-info-circle" aria-hidden="true"></i> Sebagian transaksi lama belum menyimpan harga modal saat penjualan; profit untuk baris tersebut diperkirakan dari harga beli saat ini.</div>
						<?php }?>
						<div class="clearfix" style="padding-top:5pc;"></div>
					</div>
				  </div>
              </div>
          </section>
      </section>
	
