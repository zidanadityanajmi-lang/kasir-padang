<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}

$orderQuery = $config->query(
	"SELECT * FROM pesanan
		ORDER BY FIELD(status, 'pending', 'processing', 'completed', 'cancelled'), tanggal_input DESC"
);
$orders = $orderQuery->fetchAll(PDO::FETCH_ASSOC);
$orderDetails = array();
if ($orders) {
	$detailQuery = $config->query(
		"SELECT detail.id_pesanan, detail.id_barang, detail.nama_barang, detail.merk, detail.satuan_barang,
				detail.jumlah, detail.harga_jual, detail.subtotal
			FROM detail_pesanan detail
			INNER JOIN pesanan online_order ON online_order.id_pesanan = detail.id_pesanan
			ORDER BY FIELD(online_order.status, 'pending', 'processing', 'completed', 'cancelled'),
				online_order.tanggal_input DESC, detail.nama_barang"
	);
	foreach ($detailQuery->fetchAll(PDO::FETCH_ASSOC) as $detail) {
		$orderDetails[(int) $detail['id_pesanan']][] = $detail;
	}
}
$orderNotices = array(
	'started' => array('success', 'Pesanan ditandai sedang diproses. Stok tidak dikurangi ulang.'),
	'payment-verified' => array('success', 'Pembayaran transfer telah diverifikasi.'),
	'completed' => array('success', 'Pesanan sudah dicatat ke riwayat penjualan dan nota siap dicetak.'),
	'cancelled' => array('success', 'Pesanan dibatalkan dan stok telah dikembalikan. Jika pembayaran sudah diterima, konfirmasikan pengembalian dana setelah transfer balik dilakukan.'),
	'shipped' => array('success', 'Nomor resi dan status pengiriman telah diperbarui; pelanggan menerima notifikasi.'),
	'delivered' => array('success', 'Pesanan ditandai terkirim. Pelanggan dapat mengonfirmasi penerimaan.'),
	'cancel-rejected' => array('success', 'Permintaan pembatalan ditolak dan pelanggan telah diberi tahu.'),
	'notfound' => array('warning', 'Pesanan tidak ditemukan.'),
	'notpending' => array('warning', 'Pesanan tersebut sudah diproses sebelumnya.'),
	'paymentstate' => array('warning', 'Status pembayaran sudah berubah atau pesanan tidak menggunakan transfer bank.'),
	'paymentrequired' => array('warning', 'Verifikasi pembayaran transfer sebelum menyelesaikan pesanan.'),
	'cancelstate' => array('warning', 'Permintaan pembatalan sudah berubah atau tidak lagi dapat diproses.'),
	'shippingstate' => array('warning', 'Tahap pengiriman tidak sesuai atau sudah berubah.'),
	'shippingrequired' => array('warning', 'Untuk pesanan kirim, tunggu pelanggan mengonfirmasi barang diterima sebelum menyelesaikan transaksi.'),
	'invalid' => array('danger', 'Permintaan pesanan tidak valid.'),
	'processing' => array('danger', 'Pesanan gagal diproses. Periksa log aplikasi atau coba kembali.')
);
?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading">
			<div><p class="dashboard-eyebrow">Kasir &amp; penjualan</p><h1>Pesanan Pelanggan Online</h1></div>
		</div>

		<?php if (isset($_GET['success']) && $_GET['success'] === 'completed' && isset($_SESSION['last_receipt'])) { ?>
			<div class="alert alert-success online-order-success">
				<i class="fa fa-check-circle" aria-hidden="true"></i> Pesanan selesai dan tersimpan sebagai transaksi.
				<a class="btn btn-success btn-sm" href="print.php?receipt=last" target="_blank" rel="noopener"><i class="fa fa-print" aria-hidden="true"></i> Cetak Nota</a>
			</div>
		<?php } elseif (isset($_GET['success']) && $_GET['success'] === 'cancelled') { ?>
			<div class="alert alert-success">Pesanan dibatalkan dan stok dikembalikan ke inventaris.</div>
		<?php } elseif (isset($_GET['error']) && isset($orderNotices[$_GET['error']])) { ?>
			<div class="alert alert-<?php echo htmlspecialchars($orderNotices[$_GET['error']][0], ENT_QUOTES, 'UTF-8');?>" role="alert"><?php echo htmlspecialchars($orderNotices[$_GET['error']][1], ENT_QUOTES, 'UTF-8');?></div>
		<?php } ?>

		<div class="dashboard-card online-orders-card">
			<div class="dashboard-card-heading">
				<div><p class="dashboard-eyebrow">Pesanan pelanggan dan riwayat status</p><h2>Daftar Pesanan</h2></div>
				<span class="online-order-count"><?php echo number_format(count(array_filter($orders, function ($order) { return $order['status'] === 'pending'; })));?> menunggu</span>
			</div>
			<p class="online-orders-note">Pesanan online mengurangi stok saat dibuat. Verifikasi dana transfer yang sudah masuk sebelum menyelesaikan pesanan. Ongkos kirim tidak ditambahkan otomatis; tentukan secara manual di luar sistem sampai aturan toko dikonfigurasi.</p>
			<?php if (!$orders) { ?>
				<p class="dashboard-empty">Belum ada pesanan pelanggan online.</p>
			<?php } else { ?>
				<div class="table-responsive">
					<table class="table online-orders-table">
						<thead><tr><th>Pesanan / Pelanggan</th><th>Pengambilan &amp; Pembayaran</th><th>Rincian</th><th>Total</th><th>Status Pesanan</th><th>Status Pembayaran</th><th>Aksi</th></tr></thead>
						<tbody>
						<?php foreach ($orders as $order) {
							$orderId = (int) $order['id_pesanan'];
							$statusLabels = array('pending' => 'Menunggu', 'processing' => 'Diproses', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan');
							$paymentStatusLabels = array('pending' => 'Belum dikonfirmasi', 'paid' => 'Terverifikasi', 'refund_pending' => 'Pengembalian dana perlu dilakukan', 'partially_refunded' => 'Dana dikembalikan sebagian', 'refunded' => 'Dana dikembalikan');
							$pickupLabels = array('store_pickup' => 'Ambil di toko', 'delivery' => 'Pengiriman');
							$paymentLabels = array('pay_at_store' => 'Bayar di Toko (Tunai / QRIS Kasir)', 'bank_transfer' => 'Transfer bank', 'qris' => 'QRIS');
							$details = $orderDetails[$orderId] ?? array();
						?>
							<tr>
								<td>
									<strong><?php echo htmlspecialchars($order['kode_pesanan'], ENT_QUOTES, 'UTF-8');?></strong>
									<small class="online-order-meta"><?php echo htmlspecialchars($order['tanggal_input'], ENT_QUOTES, 'UTF-8');?></small>
									<span class="online-order-customer"><?php echo htmlspecialchars($order['nama_pelanggan'], ENT_QUOTES, 'UTF-8');?></span>
									<a class="online-order-phone" href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $order['no_hp']), ENT_QUOTES, 'UTF-8');?>"><?php echo htmlspecialchars($order['no_hp'], ENT_QUOTES, 'UTF-8');?></a>
								</td>
								<td>
									<strong><?php echo htmlspecialchars($pickupLabels[$order['metode_pengambilan']] ?? '—', ENT_QUOTES, 'UTF-8');?></strong>
									<small class="online-order-meta"><?php echo htmlspecialchars($paymentLabels[$order['metode_pembayaran']] ?? '—', ENT_QUOTES, 'UTF-8');?></small>
									<?php if (!empty($order['tanggal_pembayaran'])) { ?><small class="online-order-meta">Dikonfirmasi <?php echo htmlspecialchars($order['tanggal_pembayaran'], ENT_QUOTES, 'UTF-8');?></small><?php } ?>
									<?php if ($order['metode_pengambilan'] === 'delivery' && !empty($order['alamat_pengiriman'])) { ?>
										<small class="online-order-address"><?php echo nl2br(htmlspecialchars($order['alamat_pengiriman'], ENT_QUOTES, 'UTF-8'));?></small>
									<?php } ?>
									<?php if (!empty($order['catatan_pesanan'])) { ?>
										<small class="online-order-address"><strong>Catatan:</strong> <?php echo nl2br(htmlspecialchars($order['catatan_pesanan'], ENT_QUOTES, 'UTF-8'));?></small>
									<?php } ?>
									<?php if ($order['metode_pengambilan'] === 'delivery') { ?>
										<small class="online-order-address"><strong>Pengiriman:</strong> <?php echo htmlspecialchars($order['status_pengiriman'], ENT_QUOTES, 'UTF-8');?>
											<?php if (!empty($order['jasa_pengiriman'])) { ?> · <?php echo htmlspecialchars($order['jasa_pengiriman'], ENT_QUOTES, 'UTF-8');?><?php } ?>
											<?php if (!empty($order['nomor_resi'])) { ?> · Resi <?php echo htmlspecialchars($order['nomor_resi'], ENT_QUOTES, 'UTF-8');?><?php } ?>
										</small>
									<?php } ?>
								</td>
								<td>
									<details class="online-order-details">
										<summary><?php echo count($details);?> produk</summary>
										<ul>
										<?php foreach ($details as $detail) { ?>
											<li><span><?php echo htmlspecialchars($detail['nama_barang'], ENT_QUOTES, 'UTF-8');?> × <?php echo (int) $detail['jumlah'];?></span><strong>Rp <?php echo number_format((int) $detail['subtotal'], 0, ',', '.');?></strong></li>
										<?php } ?>
										</ul>
									</details>
								</td>
								<td>
									<small class="online-order-meta">Subtotal produk Rp <?php echo number_format((int) ($order['subtotal_produk'] ?? $order['total']), 0, ',', '.');?></small>
									<?php if ((int) ($order['diskon_voucher'] ?? 0) > 0) { ?><small class="online-order-meta">Voucher <?php echo htmlspecialchars($order['kode_voucher'] ?? '', ENT_QUOTES, 'UTF-8');?> −Rp <?php echo number_format((int) $order['diskon_voucher'], 0, ',', '.');?></small><?php } ?>
									<?php if ((int) ($order['biaya_pengiriman'] ?? 0) > 0) { ?><small class="online-order-meta">Ongkir Rp <?php echo number_format((int) $order['biaya_pengiriman'], 0, ',', '.');?></small><?php } ?>
									<strong>Total Rp <?php echo number_format((int) $order['total'], 0, ',', '.');?></strong>
								</td>
								<td><span class="online-order-status status-<?php echo htmlspecialchars($order['status'], ENT_QUOTES, 'UTF-8');?>"><?php echo htmlspecialchars($statusLabels[$order['status']] ?? $order['status'], ENT_QUOTES, 'UTF-8');?></span></td>
								<td><span class="online-order-status <?php echo in_array(($order['status_pembayaran'] ?? 'pending'), array('paid', 'partially_refunded', 'refunded'), true) ? 'status-completed' : 'status-pending';?>"><?php echo htmlspecialchars($paymentStatusLabels[$order['status_pembayaran'] ?? 'pending'] ?? 'Belum dikonfirmasi', ENT_QUOTES, 'UTF-8');?></span></td>
								<td>
									<?php if ($order['status_pembatalan'] === 'pending') { ?>
										<div class="online-order-cancellation">
											<strong>Permintaan pembatalan</strong>
											<p><?php echo nl2br(htmlspecialchars($order['alasan_pembatalan'] ?? '', ENT_QUOTES, 'UTF-8'));?></p>
											<form method="POST" action="admin/module/pesanan/process.php" onsubmit="return confirm('Setujui pembatalan dan kembalikan stok? Pembayaran yang telah diterima tetap memerlukan pengembalian dana.');">
												<?php echo csrf_field();?><input type="hidden" name="order_id" value="<?php echo $orderId;?>"><input type="hidden" name="action" value="approve_cancel">
												<label>Catatan admin <input type="text" name="admin_note" maxlength="1000"></label>
												<button class="btn btn-warning btn-sm" type="submit">Setujui Pembatalan</button>
											</form>
											<form method="POST" action="admin/module/pesanan/process.php">
												<?php echo csrf_field();?><input type="hidden" name="order_id" value="<?php echo $orderId;?>"><input type="hidden" name="action" value="reject_cancel">
												<label>Alasan penolakan <input type="text" name="admin_note" maxlength="1000"></label>
												<button class="btn btn-default btn-sm" type="submit">Tolak Permintaan</button>
											</form>
										</div>
									<?php } ?>
									<?php if ($order['status'] === 'cancelled' && ($order['status_pembayaran'] ?? '') === 'refund_pending') { ?>
										<a class="btn btn-warning btn-sm" href="index.php?page=retur#refund-<?php echo $orderId;?>">Catat / Verifikasi Refund</a>
									<?php } elseif (in_array($order['status'], array('pending', 'processing'), true) && $order['status_pembatalan'] !== 'pending') { ?>
										<div class="online-order-actions">
											<?php if ($order['metode_pembayaran'] === 'bank_transfer' && ($order['status_pembayaran'] ?? 'pending') === 'pending') { ?>
												<form method="POST" action="admin/module/pesanan/process.php" onsubmit="return confirm('Pastikan dana sudah diterima di rekening toko sebelum memverifikasi pembayaran.');">
													<?php echo csrf_field();?>
													<input type="hidden" name="order_id" value="<?php echo $orderId;?>">
													<input type="hidden" name="action" value="verify_payment">
													<button class="btn btn-warning btn-sm" type="submit"><i class="fa fa-check-circle" aria-hidden="true"></i> Verifikasi Transfer</button>
												</form>
											<?php } ?>
											<?php if ($order['status'] === 'pending') { ?>
												<form method="POST" action="admin/module/pesanan/process.php">
													<?php echo csrf_field();?>
													<input type="hidden" name="order_id" value="<?php echo $orderId;?>">
													<input type="hidden" name="action" value="process">
													<button class="btn btn-primary btn-sm" type="submit"><i class="fa fa-clock-o" aria-hidden="true"></i> Tandai Diproses</button>
												</form>
											<?php } ?>
											<?php if ($order['status'] === 'processing' && $order['metode_pengambilan'] === 'delivery'
												&& in_array($order['status_pengiriman'], array('pending', 'shipped'), true)) { ?>
												<form method="POST" action="admin/module/pesanan/process.php" class="online-shipping-form">
													<?php echo csrf_field();?><input type="hidden" name="order_id" value="<?php echo $orderId;?>"><input type="hidden" name="action" value="save_shipping">
													<label>Jasa kirim <input type="text" name="jasa_pengiriman" maxlength="100" required value="<?php echo htmlspecialchars($order['jasa_pengiriman'] ?? '', ENT_QUOTES, 'UTF-8');?>"></label>
													<label>Nomor resi <input type="text" name="nomor_resi" maxlength="100" required value="<?php echo htmlspecialchars($order['nomor_resi'] ?? '', ENT_QUOTES, 'UTF-8');?>"></label>
													<button class="btn btn-primary btn-sm" type="submit">Simpan &amp; Tandai Dikirim</button>
												</form>
											<?php } ?>
											<?php if ($order['status_pengiriman'] === 'shipped') { ?>
												<form method="POST" action="admin/module/pesanan/process.php">
													<?php echo csrf_field();?><input type="hidden" name="order_id" value="<?php echo $orderId;?>"><input type="hidden" name="action" value="mark_delivered">
													<button class="btn btn-primary btn-sm" type="submit">Tandai Terkirim</button>
												</form>
											<?php } ?>
											<?php if (($order['metode_pengambilan'] !== 'delivery' || $order['status_pengiriman'] === 'received')
												&& ($order['metode_pembayaran'] !== 'bank_transfer' || ($order['status_pembayaran'] ?? 'pending') === 'paid')) { ?>
												<form method="POST" action="admin/module/pesanan/process.php">
													<?php echo csrf_field();?>
													<input type="hidden" name="order_id" value="<?php echo $orderId;?>">
													<input type="hidden" name="action" value="complete">
													<button class="btn btn-success btn-sm" type="submit"><i class="fa fa-check" aria-hidden="true"></i> Selesaikan &amp; Cetak Nota</button>
												</form>
											<?php } else { ?>
												<small class="online-order-meta"><?php if ($order['metode_pembayaran'] === 'bank_transfer' && ($order['status_pembayaran'] ?? 'pending') !== 'paid') { ?>Selesaikan setelah transfer diverifikasi.<?php } elseif ($order['metode_pengambilan'] === 'delivery' && $order['status_pengiriman'] !== 'received') { ?>Selesaikan setelah pelanggan mengonfirmasi penerimaan.<?php } ?></small>
											<?php } ?>
											<?php if ($order['status_pembatalan'] !== 'pending') { ?>
												<form method="POST" action="admin/module/pesanan/process.php" onsubmit="return confirm('Batalkan pesanan ini dan kembalikan stok?');">
													<?php echo csrf_field();?>
													<input type="hidden" name="order_id" value="<?php echo $orderId;?>">
													<input type="hidden" name="action" value="cancel">
													<button class="btn btn-default btn-sm" type="submit">Batalkan</button>
												</form>
											<?php } ?>
										</div>
									<?php } elseif ($order['status'] === 'completed') { ?>
										<span class="online-order-meta">Nota transaksi tercatat</span>
									<?php } ?>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			<?php } ?>
		</div>
	</section>
</section>
