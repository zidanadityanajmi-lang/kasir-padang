<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
   <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              <?php echo date('Y');?> - Sistem Kasir &amp; Inventaris <?php echo htmlspecialchars($toko['nama_toko'] ?? 'ATK Suka Suka', ENT_QUOTES, 'UTF-8');?>
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery-2.2.3.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/jquery.sparkline.js"></script>
	<script src="assets/js/product-image-preview.js" defer></script>

	<script src="assets/datatables/jquery.dataTables.min.js"></script>
	<script src="assets/datatables/dataTables.bootstrap.min.js"></script>

    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>
	<script src="assets/js/zabuto_calendar.js"></script>	
	<script>
		(function () {
			function initializeSidebarMenus() {
				document.querySelectorAll('#nav-accordion .sidebar-menu-toggle').forEach(function (toggle) {
					toggle.addEventListener('click', function (event) {
						event.preventDefault();
						var submenu = document.querySelector(toggle.getAttribute('href'));
						if (!submenu) {
							return;
						}
						var isExpanded = toggle.getAttribute('aria-expanded') === 'true';
						submenu.classList.toggle('show', !isExpanded);
						toggle.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
						toggle.closest('.sub-menu').classList.toggle('active', !isExpanded);
					});
				});
			}

			if (document.readyState === 'loading') {
				document.addEventListener('DOMContentLoaded', initializeSidebarMenus);
			} else {
				initializeSidebarMenus();
			}
		}());
	</script>
	<?php if ($role === 'admin') {?>
	<script>
		(function () {
			var notifications = document.querySelectorAll('.online-order-notification, .sidebar-online-orders');

			function updateNotifications(count) {
				notifications.forEach(function (notification) {
					var badge = notification.querySelector('[data-order-badge]');
					var oldCount = Number(notification.getAttribute('data-order-count')) || 0;
					notification.setAttribute('data-order-count', String(count));
					notification.classList.toggle('has-pending', count > 0);
					if (notification.classList.contains('online-order-notification')) {
						notification.setAttribute('aria-label', count + ' pesanan online menunggu diproses');
					}
					if (badge) {
						badge.textContent = String(count);
						badge.hidden = count < 1;
					}
					if (count > oldCount) {
						notification.classList.remove('order-pulse');
						window.requestAnimationFrame(function () {
							notification.classList.add('order-pulse');
						});
					}
				});
			}

			function refreshOnlineOrderCount() {
				fetch('index.php?page=dashboard&ajax=online-order-count', {
					credentials: 'same-origin',
					cache: 'no-store',
					headers: {'Accept': 'application/json'}
				}).then(function (response) {
					if (!response.ok) {
						throw new Error('HTTP ' + response.status);
					}
					return response.json();
				}).then(function (data) {
					var count = Number(data.count);
					if (!Number.isInteger(count) || count < 0) {
						throw new Error('Jumlah pesanan online tidak valid.');
					}
					updateNotifications(count);
				}).catch(function (error) {
					console.error('Gagal memperbarui notifikasi pesanan online:', error);
				});
			}

			window.setInterval(refreshOnlineOrderCount, 15000);
		}());
	</script>
	<?php }?>
	
	<script type="text/javascript">
		$(function () {
            if ($('#example1').length) {
                $('#example1').DataTable({
                    pageLength: 25,
                    lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
                    deferRender: true,
                    searchDelay: 300,
                    autoWidth: false
                });
            }
		});
	</script>	
	<script type="application/javascript">
        $(document).ready(function () {
            $("#date-popover").popover({html: true, trigger: "manual"});
            $("#date-popover").hide();
            $("#date-popover").click(function (e) {
                $(this).hide();
            });
        
            $("#my-calendar").zabuto_calendar({
                action: function () {
                    return myDateFunction(this.id, false);
                },
                action_nav: function () {
                    return myNavFunction(this.id);
                },
                ajax: {
                    url: "",
                    modal: true
                },
                legend: [  ]
            });
        });
        
        
        function myNavFunction(id) {
            $("#date-popover").hide();
            var nav = $("#" + id).data("navigation");
            var to = $("#" + id).data("to");
            console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
        }
        
        
        //angka 500 dibawah ini artinya pesan akan muncul dalam 0,5 detik setelah document ready
		$(document).ready(function(){setTimeout(function(){$(".alert-danger").fadeIn('slow');}, 500);});
		//angka 3000 dibawah ini artinya pesan akan hilang dalam 3 detik setelah muncul
		setTimeout(function(){$(".alert-danger").fadeOut('slow');}, 5000);

		$(document).ready(function(){setTimeout(function(){$(".alert-success").fadeIn('slow');}, 500);});
		setTimeout(function(){$(".alert-success").fadeOut('slow');}, 5000);

		$(document).ready(function(){setTimeout(function(){$(".alert-warning").fadeIn('slow');}, 500);});
		setTimeout(function(){$(".alert-success").fadeOut('slow');}, 5000);
		
    </script>
		<script>
			$(".modal-create").hide();
			$(".bg-shadow").hide();
			$(".bg-shadow").hide();
			function clickModals(){
				$(".bg-shadow").fadeIn();
				$(".modal-create").fadeIn();
			}
			function cancelModals(){
				$('.modal-view').fadeIn();
				$(".modal-create").hide();
				$(".bg-shadow").hide();
			}
		</script>

  </body>
</html>
