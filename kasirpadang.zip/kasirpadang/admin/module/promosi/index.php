<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}

$editId = filter_var($_GET['edit'] ?? null, FILTER_VALIDATE_INT);
$editVoucher = null;
if ($editId !== false && $editId > 0) {
	$editQuery = $config->prepare('SELECT * FROM voucher WHERE id_voucher = ? LIMIT 1');
	$editQuery->execute(array((int) $editId));
	$editVoucher = $editQuery->fetch(PDO::FETCH_ASSOC) ?: null;
}
$voucherQuery = $config->query(
	'SELECT voucher.*,
			(SELECT COUNT(*) FROM voucher_pemakaian voucher_usage WHERE voucher_usage.id_voucher = voucher.id_voucher) AS jumlah_pemakaian
		FROM voucher ORDER BY voucher.tanggal_input DESC, voucher.id_voucher DESC LIMIT 200'
);
$vouchers = $voucherQuery->fetchAll(PDO::FETCH_ASSOC);
$voucherNotices = array(
	'saved' => array('success', 'Voucher berhasil disimpan.'),
	'deactivated' => array('success', 'Voucher dinonaktifkan.'),
	'invalid' => array('warning', 'Data voucher belum valid. Periksa kembali nilai dan periode berlakunya.'),
	'duplicate' => array('warning', 'Kode voucher sudah digunakan. Pilih kode lain.'),
	'error' => array('danger', 'Voucher tidak dapat disimpan.')
);
$noticeKey = isset($_GET['result']) && is_string($_GET['result']) ? $_GET['result'] : '';
?>
<section id="main-content"><section class="wrapper">
	<div class="page-heading"><div><p class="dashboard-eyebrow">Katalog pelanggan</p><h1>Voucher Promosi</h1></div></div>
	<?php if (isset($voucherNotices[$noticeKey])) { ?><div class="alert alert-<?php echo htmlspecialchars($voucherNotices[$noticeKey][0], ENT_QUOTES, 'UTF-8');?>" role="status"><?php echo htmlspecialchars($voucherNotices[$noticeKey][1], ENT_QUOTES, 'UTF-8');?></div><?php } ?>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Satu kode per pesanan · diskon produk sebelum ongkir</p><h2><?php echo $editVoucher ? 'Ubah Voucher' : 'Buat Voucher';?></h2></div></div>
		<form class="order-lookup-form promotion-form" method="POST" action="admin/module/promosi/process.php">
			<?php echo csrf_field();?>
			<input type="hidden" name="action" value="save">
			<input type="hidden" name="voucher_id" value="<?php echo (int) ($editVoucher['id_voucher'] ?? 0);?>">
			<label for="voucherCodeAdmin">Kode voucher</label>
			<input id="voucherCodeAdmin" name="kode" maxlength="40" pattern="[A-Za-z0-9_-]{3,40}" required value="<?php echo htmlspecialchars($editVoucher['kode'] ?? '', ENT_QUOTES, 'UTF-8');?>" placeholder="CONTOH: HEMAT10">
			<label for="voucherType">Jenis diskon</label>
			<select id="voucherType" name="jenis_diskon" required>
				<option value="fixed" <?php echo ($editVoucher['jenis_diskon'] ?? '') === 'fixed' ? 'selected' : '';?>>Nominal tetap (Rupiah)</option>
				<option value="percentage" <?php echo ($editVoucher['jenis_diskon'] ?? '') === 'percentage' ? 'selected' : '';?>>Persentase (%)</option>
			</select>
			<label for="voucherValue">Nilai diskon</label>
			<input id="voucherValue" type="number" name="nilai_diskon" min="1" step="1" required value="<?php echo htmlspecialchars((string) ($editVoucher['nilai_diskon'] ?? ''), ENT_QUOTES, 'UTF-8');?>">
			<label for="voucherMinimum">Minimal subtotal produk (Rp)</label>
			<input id="voucherMinimum" type="number" name="minimal_pembelian" min="0" step="1" required value="<?php echo htmlspecialchars((string) ($editVoucher['minimal_pembelian'] ?? '0'), ENT_QUOTES, 'UTF-8');?>">
			<label for="voucherMaximum">Maksimal potongan persentase (Rp, opsional)</label>
			<input id="voucherMaximum" type="number" name="maksimal_potongan" min="1" step="1" value="<?php echo htmlspecialchars((string) ($editVoucher['maksimal_potongan'] ?? ''), ENT_QUOTES, 'UTF-8');?>">
			<label for="voucherStart">Mulai berlaku</label>
			<input id="voucherStart" type="datetime-local" name="tanggal_mulai" required value="<?php echo $editVoucher ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($editVoucher['tanggal_mulai'])), ENT_QUOTES, 'UTF-8') : date('Y-m-d\TH:i');?>">
			<label for="voucherEnd">Berakhir</label>
			<input id="voucherEnd" type="datetime-local" name="tanggal_berakhir" required value="<?php echo $editVoucher ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($editVoucher['tanggal_berakhir'])), ENT_QUOTES, 'UTF-8') : date('Y-m-d\TH:i', strtotime('+7 days'));?>">
			<label for="voucherQuota">Kuota total (kosong = tanpa batas)</label>
			<input id="voucherQuota" type="number" name="kuota_total" min="1" step="1" value="<?php echo htmlspecialchars((string) ($editVoucher['kuota_total'] ?? ''), ENT_QUOTES, 'UTF-8');?>">
			<label for="voucherPerCustomer">Batas per pelanggan</label>
			<input id="voucherPerCustomer" type="number" name="batas_per_pelanggan" min="1" step="1" required value="<?php echo htmlspecialchars((string) ($editVoucher['batas_per_pelanggan'] ?? '1'), ENT_QUOTES, 'UTF-8');?>">
			<label><input type="checkbox" name="is_active" value="1" <?php echo !isset($editVoucher['is_active']) || (int) $editVoucher['is_active'] === 1 ? 'checked' : '';?>> Aktif</label>
			<button class="store-button" type="submit"><?php echo $editVoucher ? 'Simpan Perubahan' : 'Buat Voucher';?></button>
			<?php if ($editVoucher) { ?><a class="store-button store-button-outline" href="index.php?page=promosi">Batal mengubah</a><?php } ?>
		</form>
	</div>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Status pemakaian dan periode berlaku</p><h2>Daftar Voucher</h2></div></div>
		<?php if (!$vouchers) { ?><p class="dashboard-empty">Belum ada voucher.</p><?php } else { ?>
			<div class="table-responsive"><table class="table">
				<thead><tr><th>Kode &amp; Jenis</th><th>Syarat Diskon</th><th>Periode</th><th>Kuota</th><th>Pemakaian</th><th>Status</th><th>Aksi</th></tr></thead>
				<tbody><?php foreach ($vouchers as $voucher) { ?>
					<tr>
						<td><strong><?php echo htmlspecialchars($voucher['kode'], ENT_QUOTES, 'UTF-8');?></strong><br><?php echo $voucher['jenis_diskon'] === 'percentage' ? (int) $voucher['nilai_diskon'] . '%' : 'Rp ' . number_format((int) $voucher['nilai_diskon'], 0, ',', '.');?></td>
						<td>Min. Rp <?php echo number_format((int) $voucher['minimal_pembelian'], 0, ',', '.');?><?php if ($voucher['jenis_diskon'] === 'percentage' && $voucher['maksimal_potongan'] !== null) { ?><br>Maks. Rp <?php echo number_format((int) $voucher['maksimal_potongan'], 0, ',', '.');?><?php } ?><br><small><?php echo (int) $voucher['batas_per_pelanggan'];?> kali/pelanggan</small></td>
						<td><?php echo htmlspecialchars($voucher['tanggal_mulai'], ENT_QUOTES, 'UTF-8');?><br>—<br><?php echo htmlspecialchars($voucher['tanggal_berakhir'], ENT_QUOTES, 'UTF-8');?></td>
						<td><?php echo $voucher['kuota_total'] === null ? 'Tanpa batas' : (int) $voucher['kuota_total'];?></td>
						<td><?php echo (int) $voucher['jumlah_pemakaian'];?></td>
						<td><?php echo (int) $voucher['is_active'] ? 'Aktif' : 'Nonaktif';?></td>
						<td><a class="btn btn-primary btn-sm" href="index.php?page=promosi&amp;edit=<?php echo (int) $voucher['id_voucher'];?>">Ubah</a>
							<?php if ((int) $voucher['is_active']) { ?><form method="POST" action="admin/module/promosi/process.php" onsubmit="return confirm('Nonaktifkan voucher ini?');"><?php echo csrf_field();?><input type="hidden" name="action" value="deactivate"><input type="hidden" name="voucher_id" value="<?php echo (int) $voucher['id_voucher'];?>"><button class="btn btn-default btn-sm" type="submit">Nonaktifkan</button></form><?php } ?>
						</td>
					</tr>
				<?php } ?></tbody>
			</table></div>
		<?php } ?>
	</div>
</section></section>
