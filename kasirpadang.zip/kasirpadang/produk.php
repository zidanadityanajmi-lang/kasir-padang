<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/product_image.php';
require_once __DIR__ . '/fungsi/customer_account.php';
require_once __DIR__ . '/fungsi/customer_workflows.php';
$customerSession = customer_account_session();
if ($customerSession) {
	$activeSessionQuery = $config->prepare("SELECT id_pelanggan FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1");
	$activeSessionQuery->execute(array((int) $customerSession['id_pelanggan']));
	if (!$activeSessionQuery->fetchColumn()) {
		unset($_SESSION['customer']);
		$customerSession = null;
	}
}

function product_page_escape($value)
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$productId = trim((string) ($_GET['id'] ?? ''));
if ($productId === '' || strlen($productId) > 255) {
	http_response_code(404);
	exit('Produk tidak ditemukan.');
}

$productQuery = $config->prepare(
	'SELECT barang.id_barang, barang.nama_barang, barang.merk, barang.deskripsi, barang.gambar,
			barang.harga_jual, barang.satuan_barang, barang.stok, kategori.nama_kategori, barang.id_kategori
		FROM barang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori
		WHERE barang.id_barang = ? LIMIT 1'
);
$productQuery->execute(array($productId));
$product = $productQuery->fetch(PDO::FETCH_ASSOC);
if (!$product) {
	http_response_code(404);
	exit('Produk tidak ditemukan.');
}

$wishlistNotice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'wishlist') {
	if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
		http_response_code(403);
		exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
	}
	if (!$customerSession) {
		header('Location: masuk_pelanggan.php');
		exit;
	}
	$activeCustomer = $config->prepare("SELECT id_pelanggan FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1");
	$activeCustomer->execute(array((int) $customerSession['id_pelanggan']));
	if (!$activeCustomer->fetchColumn()) {
		unset($_SESSION['customer']);
		header('Location: masuk_pelanggan.php?error=inactive');
		exit;
	}
	$wishlistAction = (string) ($_POST['wishlist_action'] ?? 'add');
	if ($wishlistAction === 'remove') {
		$config->prepare('DELETE FROM daftar_wishlist WHERE id_pelanggan = ? AND id_barang = ?')
			->execute(array((int) $customerSession['id_pelanggan'], $productId));
		customer_workflow_audit($config, null, 'Remove wishlist product', 'daftar_wishlist', $productId);
		$wishlistNotice = 'Produk dihapus dari wishlist.';
	} else {
		$config->prepare(
			'INSERT INTO daftar_wishlist (id_pelanggan, id_barang, tanggal_input) VALUES (?, ?, ?)
				ON DUPLICATE KEY UPDATE tanggal_input = VALUES(tanggal_input)'
		)->execute(array((int) $customerSession['id_pelanggan'], $productId, date('Y-m-d H:i:s')));
		customer_workflow_audit($config, null, 'Add wishlist product', 'daftar_wishlist', $productId);
		$wishlistNotice = 'Produk ditambahkan ke wishlist.';
	}
}

$isWishlisted = false;
if ($customerSession) {
	$wishlistCheck = $config->prepare('SELECT 1 FROM daftar_wishlist WHERE id_pelanggan = ? AND id_barang = ?');
	$wishlistCheck->execute(array((int) $customerSession['id_pelanggan'], $productId));
	$isWishlisted = (bool) $wishlistCheck->fetchColumn();
}
$reviewSummaryQuery = $config->prepare(
	"SELECT COUNT(*) AS review_count, AVG(rating) AS average_rating
		FROM ulasan_produk WHERE id_barang = ? AND status = 'approved'"
);
$reviewSummaryQuery->execute(array($productId));
$reviewSummary = $reviewSummaryQuery->fetch(PDO::FETCH_ASSOC);
$productReviewQuery = $config->prepare(
	"SELECT r.rating, r.ulasan, r.tanggal_input, p.nama_pelanggan
		FROM ulasan_produk r INNER JOIN pelanggan p ON p.id_pelanggan = r.id_pelanggan
		WHERE r.id_barang = ? AND r.status = 'approved'
		ORDER BY r.tanggal_input DESC LIMIT 10"
);
$productReviewQuery->execute(array($productId));
$productReviews = $productReviewQuery->fetchAll(PDO::FETCH_ASSOC);

$imageName = basename((string) ($product['gambar'] ?? ''));
$imagePath = __DIR__ . '/assets/img/produk/' . $imageName;
$hasImage = $imageName !== '' && is_file($imagePath);
$imageUrl = $hasImage
	? 'assets/img/produk/' . rawurlencode($imageName) . '?v=' . (int) filemtime($imagePath)
	: product_image_placeholder($product['nama_kategori'] ?? '', $product['nama_barang'] ?? '', $product['merk'] ?? '');
$stock = max(0, (int) $product['stok']);
$csrf = csrf_token();
$storeQuery = $config->query('SELECT nama_toko FROM toko WHERE id_toko = 1 LIMIT 1');
$storeName = trim((string) $storeQuery->fetchColumn()) ?: 'ATK Suka Suka';

$relatedQuery = $config->prepare(
	'SELECT id_barang, nama_barang, merk, gambar, harga_jual, satuan_barang, stok
		FROM barang WHERE id_kategori = ? AND id_barang <> ?
		ORDER BY CAST(stok AS UNSIGNED) > 0 DESC, nama_barang ASC LIMIT 4'
);
$relatedQuery->execute(array((int) $product['id_kategori'], $productId));
$relatedProducts = $relatedQuery->fetchAll(PDO::FETCH_ASSOC);
$addedToCart = isset($_GET['added']) && $_GET['added'] === '1';
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo product_page_escape($product['nama_barang']);?> | <?php echo product_page_escape($storeName);?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css?v=<?php echo (int) filemtime(__DIR__ . '/assets/css/storefront.css');?>" rel="stylesheet">
</head>
<body>
	<div class="shop-promo">
		<div class="shop-container shop-promo-inner"><span><?php echo product_page_escape($storeName);?></span><a href="riwayat_pesanan.php">Cek Pesanan</a></div>
	</div>
	<header class="shop-header">
		<div class="shop-container shop-header-inner">
			<a class="shop-brand" href="katalog_pelanggan.php"><span class="shop-brand-mark"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span><span><strong><?php echo product_page_escape($storeName);?></strong><small>Lengkap, Murah, dan Berkualitas</small></span></a>
			<nav class="shop-navigation" aria-label="Navigasi utama">
				<a href="katalog_pelanggan.php">Beranda</a><a href="katalog_pelanggan.php#tentang">Tentang Kami</a><a href="katalog_pelanggan.php#produk">Produk</a><a href="katalog_pelanggan.php#transaksi">Transaksi</a><a href="riwayat_pesanan.php">Cek Pesanan</a><a href="katalog_pelanggan.php#kontak">Kontak</a>
				<a class="customer-account-nav" href="<?php echo $customerSession ? 'profil_pelanggan.php' : 'masuk_pelanggan.php';?>"><?php echo $customerSession ? 'Profil &amp; Pesanan' : 'Masuk';?></a>
				<?php if (!$customerSession) { ?><a class="customer-account-nav" href="daftar_pelanggan.php">Daftar</a><?php } ?>
			</nav>
			<a class="cart-open" href="katalog_pelanggan.php#produk"><i class="fa fa-arrow-left" aria-hidden="true"></i><span>Kembali ke katalog</span></a>
		</div>
	</header>
	<main class="shop-container product-detail-page">
		<?php if ($addedToCart) { ?><div class="shop-notice" role="status">Produk berhasil dimasukkan ke keranjang.</div><?php } ?>
		<p class="product-breadcrumb"><a href="katalog_pelanggan.php">Beranda</a> / <a href="katalog_pelanggan.php#produk">Produk</a> / <?php echo product_page_escape($product['nama_barang']);?></p>
		<section class="product-detail-card">
			<div class="product-detail-image-wrap">
				<img class="product-detail-image" src="<?php echo product_page_escape($imageUrl);?>" alt="<?php echo product_page_escape($product['nama_barang'] . ' ' . $product['merk']);?>" loading="eager">
			</div>
			<div class="product-detail-copy">
				<span class="section-kicker"><?php echo product_page_escape($product['nama_kategori'] ?? 'Perlengkapan ATK');?></span>
				<p class="product-brand"><?php echo product_page_escape($product['merk']);?></p>
				<h1><?php echo product_page_escape($product['nama_barang']);?></h1>
				<p class="product-detail-price">Rp <?php echo number_format((int) $product['harga_jual'], 0, ',', '.');?> <small>/ <?php echo product_page_escape($product['satuan_barang']);?></small></p>
				<p class="product-rating-summary"><?php echo (int) $reviewSummary['review_count'] > 0 ? number_format((float) $reviewSummary['average_rating'], 1) . ' / 5 · ' . (int) $reviewSummary['review_count'] . ' ulasan' : 'Belum ada ulasan yang dipublikasikan';?></p>
				<p class="product-detail-stock <?php echo $stock > 0 ? 'stock-in' : 'stock-out';?>"><?php echo $stock > 0 ? 'Stok tersedia: ' . number_format($stock) . ' ' . product_page_escape($product['satuan_barang']) : 'Stok habis';?></p>
				<h2>Deskripsi produk</h2>
				<p class="product-description"><?php echo nl2br(product_page_escape(trim((string) ($product['deskripsi'] ?? '')) ?: ($product['nama_barang'] . ' merek ' . $product['merk'] . '. Hubungi toko untuk informasi varian dan ketersediaan terbaru.')));?></p>
				<?php if ($stock > 0) { ?>
					<form class="product-detail-add" method="POST" action="katalog_pelanggan.php?ajax=cart">
						<input type="hidden" name="_csrf" value="<?php echo product_page_escape($csrf);?>">
						<input type="hidden" name="action" value="add">
						<input type="hidden" name="product_id" value="<?php echo product_page_escape($productId);?>">
						<input type="hidden" name="return_to" value="produk.php?id=<?php echo rawurlencode($productId);?>">
						<label for="detailQuantity">Jumlah</label>
						<input id="detailQuantity" type="number" name="quantity" min="1" max="<?php echo min(999, $stock);?>" value="1" required>
						<button class="store-button" type="submit"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Tambah ke Keranjang</button>
					</form>
				<?php } else { ?>
					<button class="store-button" type="button" disabled>Stok habis</button>
				<?php } ?>
				<?php if ($wishlistNotice !== '') { ?><p class="shop-notice" role="status"><?php echo product_page_escape($wishlistNotice);?></p><?php } ?>
				<form class="wishlist-action-form" method="POST" action="produk.php?id=<?php echo rawurlencode($productId);?>">
					<input type="hidden" name="_csrf" value="<?php echo product_page_escape($csrf);?>">
					<input type="hidden" name="action" value="wishlist">
					<input type="hidden" name="wishlist_action" value="<?php echo $isWishlisted ? 'remove' : 'add';?>">
					<button class="store-button store-button-outline" type="submit"><i class="fa <?php echo $isWishlisted ? 'fa-heart' : 'fa-heart-o';?>" aria-hidden="true"></i> <?php echo $isWishlisted ? 'Hapus dari Wishlist' : 'Simpan ke Wishlist';?></button>
				</form>
			</div>
		</section>

		<section class="related-products customer-product-reviews" id="ulasan">
			<div class="section-heading"><div><span class="section-kicker">Pengalaman pelanggan</span><h2>Ulasan Produk</h2></div></div>
			<?php if (!$productReviews) { ?><p>Belum ada ulasan untuk produk ini.</p><?php } ?>
			<?php foreach ($productReviews as $review) { ?>
				<article class="customer-address-card">
					<strong><?php echo product_page_escape($review['nama_pelanggan']);?> · <?php echo (int) $review['rating'];?> / 5</strong>
					<p><?php echo nl2br(product_page_escape($review['ulasan']));?></p>
					<small><?php echo product_page_escape($review['tanggal_input']);?></small>
				</article>
			<?php } ?>
		</section>

		<?php if ($relatedProducts) { ?>
			<section class="related-products">
				<div class="section-heading"><div><span class="section-kicker">Kategori yang sama</span><h2>Produk terkait</h2></div></div>
				<div class="product-grid">
					<?php foreach ($relatedProducts as $related) {
						$relatedImageName = basename((string) ($related['gambar'] ?? ''));
						$relatedImagePath = __DIR__ . '/assets/img/produk/' . $relatedImageName;
						$relatedImage = $relatedImageName !== '' && is_file($relatedImagePath)
							? 'assets/img/produk/' . rawurlencode($relatedImageName)
							: product_image_placeholder($product['nama_kategori'] ?? '', $related['nama_barang'] ?? '', $related['merk'] ?? '');
					?>
						<a class="product-card related-product-card" href="produk.php?id=<?php echo rawurlencode((string) $related['id_barang']);?>">
							<div class="product-art"><img class="product-image" src="<?php echo product_page_escape($relatedImage);?>" alt="" loading="lazy"></div>
							<div class="product-info"><p class="product-brand"><?php echo product_page_escape($related['merk']);?></p><h3><?php echo product_page_escape($related['nama_barang']);?></h3><span class="product-price">Rp <?php echo number_format((int) $related['harga_jual'], 0, ',', '.');?></span></div>
						</a>
					<?php } ?>
				</div>
			</section>
		<?php } ?>
	</main>
	<footer class="shop-footer"><div class="shop-container footer-bottom"><span>&copy; <?php echo date('Y');?> <?php echo product_page_escape($storeName);?></span><a href="katalog_pelanggan.php#kontak">Kontak toko</a></div></footer>
</body>
</html>
