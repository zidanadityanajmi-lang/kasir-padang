## Deskripsi Aplikasi 
Source Code Aplikasi Penjualan Barang sederhana berbasis Website dengan PHP & MYSQL.
<br>
<br>
Source Blog : <a href="https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html" target="_blank">
https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html</a>
<br>
<br>
<span style="color:red"><b> * Untuk Reuploader Source Code tolong cantumin sumber juga ya, terima kasih :)</b></span>

## Setting Koneksi PHP
setting koneksi di config.php dan ganti username, password dan dbname nya

## Penggunaan Login
Username : admin
<br/>
Password : 123
<br>
Password bawaan dari dump lama hanya untuk instalasi lokal; segera ganti melalui menu User. Login pertama akan mengubah hash MD5 lama menjadi `password_hash()` setelah migrasi password dijalankan.

## Setup dan pembaruan

1. Import `db_toko.sql` ke MariaDB/MySQL dan atur `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, serta `DB_NAME` pada environment PHP. Tanpa environment tersebut, konfigurasi lokal XAMPP tetap memakai `localhost:3306`, `root`, password kosong, dan `db_toko`.
2. Jika perlu detail error di layar untuk developer, set `APP_DEBUG=true` hanya di localhost. Rincian koneksi tetap dicatat di error log; jangan aktifkan debug di server publik.
3. Jalankan migrasi SQL yang belum diterapkan (jangan jalankan ulang migrasi yang sudah diterapkan). Pastikan `2026_11_12_add_login_password_hash.sql`, `2026_11_12_add_nota_transaction_snapshots.sql`, `2026_11_13_create_customer_orders.sql`, `2026_11_13_add_barang_gambar.sql`, `2026_11_13_add_customer_order_details.sql`, `2026_11_16_add_payment_and_stock_history.sql`, `2026_11_16_create_customer_accounts.sql`, `2026_11_16_add_customer_and_order_workflows.sql`, dan `2026_11_17_create_vouchers_returns_and_refunds.sql` sudah diterapkan. Migrasi workflow membuat alamat tersimpan, wishlist, ulasan, notifikasi, riwayat status, dan audit; migrasi terbaru menambahkan voucher, snapshot diskon, retur parsial, dan pencatatan/verifikasi refund. File ALTER bersifat sekali jalan; periksa skema sebelum menjalankannya pada database yang sudah pernah diperbarui.
4. Setelah migrasi snapshot nota diterapkan, jalankan `migrations/2026_11_12_finalize_atk_catalog.sql` pada database `db_toko`. Migrasi ini menormalkan kategori menjadi enam kategori resmi, membersihkan produk non-ATK, dan menambahkan hingga 60 produk ATK dengan harga awal estimasi Rupiah. Sesuaikan harga dengan pemasok setempat.
5. Migrasi menyimpan snapshot nama dan modal barang non-ATK pada nota sebelum menghapusnya, serta membersihkan keranjang aktif yang merujuk ke barang tersebut. Produk berkode `ATK0001` sampai `ATK0060` yang sudah ada tidak ditimpa, sehingga stok dan harga yang pernah disunting tetap dipertahankan.
6. Bootstrap 5.3.3 CSS dimuat dari jsDelivr. Bootstrap 3 JavaScript tetap dipakai hanya untuk modal/accordion legacy; komponen baru memakai markup dan utility Bootstrap 5.
7. Katalog publik pelanggan tersedia di `katalog_pelanggan.php`. Halaman memuat bagian Tentang Kami, Produk, Transaksi/Keranjang, dan Kontak; produk, kategori, harga, stok, dan kontak toko dibaca dari database yang sama. Keranjang guest tetap didukung; pelanggan dapat membuat akun di `daftar_pelanggan.php`, masuk di `masuk_pelanggan.php`, dan mengelola profil, password, alamat, wishlist, notifikasi, serta riwayat pesanan di `profil_pelanggan.php`. Checkout akun tetap menghitung harga dari database, menyimpan snapshot ke `pesanan` dan `detail_pesanan`, serta mencadangkan stok secara atomik. Pesanan akun yang belum dikirim dapat diajukan pembatalannya; stok hanya dikembalikan setelah admin menyetujui pembatalan. Admin dapat melihat/nonaktifkan akun pelanggan, mencatat pergerakan stok, memverifikasi transfer, menyetujui/menolak permintaan pembatalan, memperbarui jasa kirim dan nomor resi secara manual, menandai pesanan terkirim, menyelesaikan pesanan, dan mengonfirmasi pengembalian dana setelah tindakan nyata dilakukan. Pelanggan dapat mengonfirmasi penerimaan kiriman; penyelesaian ke nota tetap dilakukan admin agar transaksi lama tetap konsisten. Ongkos kirim tidak dihitung atau ditambahkan otomatis karena kebijakan/rate toko belum dikonfigurasi. Status pesanan, pembayaran, dan pengiriman tampil pada riwayat pelanggan; status diperbarui berkala dan notifikasi tersimpan di database. Ulasan hanya dapat dikirim untuk barang pada pesanan selesai dan baru tampil setelah admin menyetujuinya melalui menu Moderasi Ulasan. Menu Audit Aktivitas menampilkan perubahan operasional penting. Pesanan yang selesai tercatat ke `nota` satu kali dan dapat dicetak. Foto katalog dikelola melalui form tambah/edit barang admin, disimpan pada `assets/img/produk/`, dan menggunakan kolom `barang.gambar`. Unggahan dibatasi ke JPG/JPEG, PNG, atau WebP maksimal 2 MB; gambar diganti tanpa menghapus gambar lama jika masih digunakan produk lain. Produk yang belum memiliki foto memakai ilustrasi SVG berdasarkan nama produk dan kategori; ilustrasi ini bukan foto asli. Unggah foto produk berlisensi/milik toko melalui form admin untuk menampilkan foto sebenarnya. Transfer bank hanya menampilkan rekening apabila environment `STORE_BANK_ACCOUNT` telah diatur; tanpa konfigurasi, pelanggan diminta mengonfirmasi rekening ke toko sebelum transfer.

Voucher nominal/persentase divalidasi kembali saat checkout, dengan periode, minimum belanja, kuota, batas pemakaian pelanggan, dan satu voucher per pesanan. Diskon produk disimpan pada pesanan dan dialokasikan konsisten pada nota. Pengajuan retur hanya tersedia untuk pesanan pelanggan yang selesai dalam 7 hari; pelanggan memilih produk/jumlah dan mengunggah bukti. Admin meninjau permintaan, mencatat jumlah yang diterima serta jumlah layak dijual kembali, lalu stok hanya bertambah untuk jumlah layak. Nilai refund dibatasi pada nilai bersih setelah diskon untuk barang yang diterima. Refund harus dicatat setelah transfer/tunai dilakukan dan diverifikasi admin sebelum ditandai berhasil; status dan auditnya tampil di halaman admin serta riwayat pelanggan (`riwayat_pesanan.php`). Atur environment `RETURN_EVIDENCE_DIR` ke direktori privat di luar webroot agar bukti retur tersimpan permanen; tanpa konfigurasi, aplikasi menggunakan direktori temporary sistem.

Laporan dapat diunduh sebagai Excel atau dicetak ke printer / disimpan sebagai PDF melalui dialog cetak browser. Transaksi lama tanpa snapshot harga modal menggunakan harga beli produk saat ini sebagai estimasi profit.

## Contoh Program 
- Login
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/login.png">

- Dashboard 
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/1.png">

- Tabel Barang
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/2.png">

- Keranjang / Transaksi
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/4.png">

- Laporan 
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/5.png">

- Nama Toko 
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/6.png">

- Atur User 
<img src="https://raw.githubusercontent.com/fauzan1892/pos-kasir-php/master/assets/img/pic/7.png">

## Changelog
31 Januari 2021<br>
- Tambah Sortir khusus stok kurang dari >= 3
- Cari Per Tanggal Laporan 
- Cari Per bulan Laporan
- Fix Perhitungan Laporan

06 Oktober 2020<br>
- revisi session error pada hosting dengan error : 
Warning: session_start(): Cannot send session cookie - headers already sent by (output started at [duplicate] -> fixed
- Ganti background login, header
- Ganti Header table barang, table keranjang, table laporan
- Fix transaksi -> transaksi stok < keranjang tidak bisa diproses
- penghapusan trigger sql
- penambahan fungsi transaksi untuk pengurangan stok barang setelah transaksi bayar 

23 Agustus 2020<br>
- revisi print
- menambahkan alert telah di bayar di bagian bayar transaksi penjualan

18 Juli 2020<br>
- fix edit kategori
- fix modal tambah barang
- rapihin form laporan

29 Agustus 2019 <br>
- laporan tampilan error  -> fixed
- klik button bayar transaksi  tidak masuk ke laporan -> fixed
- pencarian barang pada menu transaksi sudah otomatis dengan tambahan jquery ajax
- data laporan dapat dicari berdasarkan periode bulan dan tahun

<br>
** Jika ada issues atau revisi atau menambahkan fitur silahkan pull request di repository ini

## Contributors
<a href="https://fauzan.codekop.com/"> Fauzan Falah</a>

My Blog : <a href="https://www.codekop.com/"> Codekop.com</a>

Gunakan Aplikasi dengan bijak, dan Selamat Belajar
