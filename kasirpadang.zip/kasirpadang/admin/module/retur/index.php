<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; }
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}
require_once __DIR__ . '/../../../fungsi/order_pricing.php';

$returnQuery = $config->query(
	'SELECT r.*, p.kode_pesanan, p.total, p.subtotal_produk, p.diskon_voucher, p.id_pelanggan, p.status_pembayaran,
			customer.nama_pelanggan
		FROM retur_pesanan r
		INNER JOIN pesanan p ON p.id_pesanan = r.id_pesanan
		LEFT JOIN pelanggan customer ON customer.id_pelanggan = r.id_pelanggan
		ORDER BY FIELD(r.status, "pending", "approved", "received", "inspected", "rejected", "refunded"),
			r.tanggal_input DESC LIMIT 100'
);
$returns = $returnQuery->fetchAll(PDO::FETCH_ASSOC);
$returnDetails = array();
$returnAcceptedValues = array();
if ($returns) {
	$returnIds = array_map('intval', array_column($returns, 'id_retur'));
	$placeholders = implode(',', array_fill(0, count($returnIds), '?'));
	$detailQuery = $config->prepare(
		'SELECT rd.*, detail.harga_jual
			FROM detail_retur rd
			LEFT JOIN retur_pesanan r ON r.id_retur = rd.id_retur
			LEFT JOIN detail_pesanan detail ON detail.id_pesanan = r.id_pesanan AND detail.id_barang = rd.id_barang
			WHERE rd.id_retur IN (' . $placeholders . ') ORDER BY rd.id_retur, rd.nama_barang'
	);
	$detailQuery->execute($returnIds);
	foreach ($detailQuery->fetchAll(PDO::FETCH_ASSOC) as $detail) {
		$returnDetails[(int) $detail['id_retur']][] = $detail;
	}
	$orderIds = array_values(array_unique(array_map('intval', array_column($returns, 'id_pesanan'))));
	$orderPlaceholders = implode(',', array_fill(0, count($orderIds), '?'));
	$orderDetailQuery = $config->prepare(
		'SELECT detail.*, order_row.diskon_voucher, order_row.subtotal_produk
			FROM detail_pesanan detail
			INNER JOIN pesanan order_row ON order_row.id_pesanan = detail.id_pesanan
			WHERE detail.id_pesanan IN (' . $orderPlaceholders . ')
			ORDER BY detail.id_pesanan, detail.id_barang'
	);
	$orderDetailQuery->execute($orderIds);
	$detailsByOrder = array();
	$orderDetailByProduct = array();
	foreach ($orderDetailQuery->fetchAll(PDO::FETCH_ASSOC) as $orderDetail) {
		$orderId = (int) $orderDetail['id_pesanan'];
		$productId = (string) $orderDetail['id_barang'];
		$detailsByOrder[$orderId][] = $orderDetail;
		$orderDetailByProduct[$orderId][$productId] = $orderDetail;
	}
	$orderSnapshots = array();
	foreach ($returns as $returnRow) {
		$orderSnapshots[(int) $returnRow['id_pesanan']] = array(
			'discount' => (int) $returnRow['diskon_voucher'],
			'subtotal' => (int) $returnRow['subtotal_produk']
		);
	}
	$netLineSubtotalsByOrder = array();
	foreach ($detailsByOrder as $orderId => $orderDetails) {
		$netLineSubtotalsByOrder[$orderId] = order_net_line_subtotals(
			$orderDetails,
			$orderSnapshots[$orderId]['discount'],
			$orderSnapshots[$orderId]['subtotal']
		);
	}
	foreach ($returns as $returnRow) {
		$returnId = (int) $returnRow['id_retur'];
		$orderId = (int) $returnRow['id_pesanan'];
		foreach ($returnDetails[$returnId] ?? array() as $detail) {
			$productId = (string) $detail['id_barang'];
			if (isset($orderDetailByProduct[$orderId][$productId], $netLineSubtotalsByOrder[$orderId][$productId])) {
				$returnAcceptedValues[$returnId] = ($returnAcceptedValues[$returnId] ?? 0)
					+ order_returnable_line_value(
						$orderDetailByProduct[$orderId][$productId],
						$netLineSubtotalsByOrder[$orderId][$productId],
						(int) $detail['jumlah_diterima']
					);
			}
		}
	}
}
$refundQuery = $config->query(
	'SELECT refund.*, order_row.kode_pesanan, order_row.total AS total_pesanan,
			order_row.status_pembayaran, customer.nama_pelanggan, return_row.status AS status_retur
		FROM pengembalian_dana refund
		INNER JOIN pesanan order_row ON order_row.id_pesanan = refund.id_pesanan
		LEFT JOIN pelanggan customer ON customer.id_pelanggan = order_row.id_pelanggan
		LEFT JOIN retur_pesanan return_row ON return_row.id_retur = refund.id_retur
		ORDER BY FIELD(refund.status, "waiting", "processing", "rejected", "success"),
			refund.tanggal_update DESC, refund.id_pengembalian_dana DESC LIMIT 100'
);
$refunds = $refundQuery->fetchAll(PDO::FETCH_ASSOC);
$refundHistory = array();
if ($refunds) {
	$refundIds = array_map('intval', array_column($refunds, 'id_pengembalian_dana'));
	$refundPlaceholders = implode(',', array_fill(0, count($refundIds), '?'));
	$refundHistoryQuery = $config->prepare(
		'SELECT * FROM riwayat_pengembalian_dana
			WHERE id_pengembalian_dana IN (' . $refundPlaceholders . ')
			ORDER BY id_pengembalian_dana, tanggal_input'
	);
	$refundHistoryQuery->execute($refundIds);
	foreach ($refundHistoryQuery->fetchAll(PDO::FETCH_ASSOC) as $history) {
		$refundHistory[(int) $history['id_pengembalian_dana']][] = $history;
	}
}
$returnLabels = array('pending' => 'Menunggu persetujuan', 'approved' => 'Disetujui · menunggu barang', 'received' => 'Barang diterima · menunggu pemeriksaan', 'inspected' => 'Barang diperiksa', 'rejected' => 'Ditolak', 'refunded' => 'Refund berhasil');
$refundLabels = array('waiting' => 'Menunggu', 'processing' => 'Diproses', 'success' => 'Berhasil', 'rejected' => 'Ditolak');
$noticeMap = array(
	'return-updated' => array('success', 'Permintaan retur diperbarui.'),
	'refund-updated' => array('success', 'Status pengembalian dana diperbarui.'),
	'invalid' => array('warning', 'Permintaan tidak valid atau statusnya sudah berubah.'),
	'error' => array('danger', 'Perubahan belum dapat disimpan.')
);
$noticeKey = isset($_GET['result']) && is_string($_GET['result']) ? $_GET['result'] : '';
?>
<section id="main-content"><section class="wrapper">
	<div class="page-heading"><div><p class="dashboard-eyebrow">Layanan pelanggan</p><h1>Retur &amp; Refund</h1></div></div>
	<?php if (isset($noticeMap[$noticeKey])) { ?><div class="alert alert-<?php echo htmlspecialchars($noticeMap[$noticeKey][0], ENT_QUOTES, 'UTF-8');?>" role="status"><?php echo htmlspecialchars($noticeMap[$noticeKey][1], ENT_QUOTES, 'UTF-8');?></div><?php } ?>
	<div class="online-orders-note">Terima/inspeksi barang sebelum stok dikembalikan. Refund berstatus berhasil hanya setelah admin mengonfirmasi pengembalian dana yang benar-benar dilakukan. Batas retur pelanggan: 7 hari.</div>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Permintaan pelanggan</p><h2>Daftar Retur</h2></div></div>
		<?php if (!$returns) { ?><p class="dashboard-empty">Belum ada permintaan retur.</p><?php } ?>
		<?php foreach ($returns as $return) {
			$returnId = (int) $return['id_retur'];
			$lines = $returnDetails[$returnId] ?? array();
		?>
			<article class="online-order-cancellation return-request-card">
				<div><strong><?php echo htmlspecialchars($return['kode_pesanan'], ENT_QUOTES, 'UTF-8');?> · <?php echo htmlspecialchars($return['nama_pelanggan'] ?: 'Pelanggan', ENT_QUOTES, 'UTF-8');?></strong><span class="online-order-meta"><?php echo htmlspecialchars($return['tanggal_input'], ENT_QUOTES, 'UTF-8');?> · <?php echo htmlspecialchars($returnLabels[$return['status']] ?? $return['status'], ENT_QUOTES, 'UTF-8');?></span></div>
				<p><?php echo nl2br(htmlspecialchars($return['alasan'], ENT_QUOTES, 'UTF-8'));?> · <a href="bukti_retur.php?id=<?php echo $returnId;?>" target="_blank" rel="noopener">Lihat foto bukti</a></p>
				<ul><?php foreach ($lines as $line) { ?><li><?php echo htmlspecialchars($line['nama_barang'], ENT_QUOTES, 'UTF-8');?> — diminta <?php echo (int) $line['jumlah_diminta'];?>, diterima <?php echo (int) $line['jumlah_diterima'];?>, stok dikembalikan <?php echo (int) $line['jumlah_stok_dikembalikan'];?></li><?php } ?></ul>
				<?php if (!empty($return['catatan_admin'])) { ?><p>Catatan admin: <?php echo htmlspecialchars($return['catatan_admin'], ENT_QUOTES, 'UTF-8');?></p><?php } ?>
				<?php if ($return['status'] === 'pending') { ?>
					<form method="POST" action="admin/module/retur/process.php" class="return-action-form"><?php echo csrf_field();?><input type="hidden" name="action" value="review_return"><input type="hidden" name="return_id" value="<?php echo $returnId;?>">
						<label>Catatan admin <input type="text" name="note" maxlength="1000"></label>
						<button class="btn btn-success btn-sm" name="decision" value="approve" type="submit">Setujui Retur</button>
						<button class="btn btn-default btn-sm" name="decision" value="reject" type="submit" required>Tolak Retur</button>
					</form>
				<?php } elseif ($return['status'] === 'approved') { ?>
					<form method="POST" action="admin/module/retur/process.php" onsubmit="return confirm('Konfirmasi barang retur telah diterima secara fisik.');"><?php echo csrf_field();?><input type="hidden" name="action" value="mark_received"><input type="hidden" name="return_id" value="<?php echo $returnId;?>"><button class="btn btn-primary btn-sm" type="submit">Tandai Barang Diterima</button></form>
				<?php } elseif ($return['status'] === 'received') { ?>
					<form method="POST" action="admin/module/retur/process.php" class="return-action-form" onsubmit="return confirm('Stok akan bertambah hanya untuk jumlah yang dinyatakan layak.');">
						<?php echo csrf_field();?><input type="hidden" name="action" value="inspect_return"><input type="hidden" name="return_id" value="<?php echo $returnId;?>">
						<strong>Hasil inspeksi</strong>
						<?php foreach ($lines as $line) { ?><label><?php echo htmlspecialchars($line['nama_barang'], ENT_QUOTES, 'UTF-8');?> · diminta <?php echo (int) $line['jumlah_diminta'];?>
							<span>Jumlah diterima</span><input type="number" name="received[<?php echo htmlspecialchars($line['id_barang'], ENT_QUOTES, 'UTF-8');?>]" min="0" max="<?php echo (int) $line['jumlah_diminta'];?>" value="0" required>
							<span>Layak dikembalikan ke stok</span><input type="number" name="restock[<?php echo htmlspecialchars($line['id_barang'], ENT_QUOTES, 'UTF-8');?>]" min="0" max="<?php echo (int) $line['jumlah_diminta'];?>" value="0" required>
							</label><?php } ?>
						<label>Catatan pemeriksaan <input type="text" name="inspection_note" maxlength="500"></label>
						<button class="btn btn-primary btn-sm" type="submit">Simpan Pemeriksaan &amp; Kembalikan Stok Layak</button>
					</form>
				<?php } ?>
			</article>
		<?php } ?>
	</div>
	<div class="dashboard-card">
		<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Transaksi refund tunggal per pesanan</p><h2>Pengembalian Dana</h2></div></div>
		<?php if (!$refunds) { ?><p class="dashboard-empty">Belum ada refund yang menunggu.</p><?php } ?>
		<?php foreach ($refunds as $refund) {
			$refundId = (int) $refund['id_pengembalian_dana'];
			$orderId = (int) $refund['id_pesanan'];
			$isReturn = !empty($refund['id_retur']);
			$acceptedTotal = $isReturn ? (int) ($returnAcceptedValues[(int) $refund['id_retur']] ?? 0) : (int) $refund['total_pesanan'];
		?>
			<article class="online-order-cancellation return-request-card" id="refund-<?php echo $orderId;?>">
				<strong><?php echo htmlspecialchars($refund['kode_pesanan'], ENT_QUOTES, 'UTF-8');?> · <?php echo htmlspecialchars($refund['nama_pelanggan'] ?: 'Pelanggan', ENT_QUOTES, 'UTF-8');?></strong>
				<p>Status refund: <strong><?php echo htmlspecialchars($refundLabels[$refund['status']] ?? $refund['status'], ENT_QUOTES, 'UTF-8');?></strong> · Batas maksimum berdasarkan <?php echo $isReturn ? 'barang retur yang diterima' : 'total transaksi';?>: Rp <?php echo number_format($acceptedTotal, 0, ',', '.');?></p>
				<?php if ((int) $refund['nominal'] > 0) { ?><p>Nominal Rp <?php echo number_format((int) $refund['nominal'], 0, ',', '.');?> · <?php echo htmlspecialchars($refund['metode_refund'], ENT_QUOTES, 'UTF-8');?> · <?php echo htmlspecialchars($refund['tanggal_refund'], ENT_QUOTES, 'UTF-8');?><?php if (!empty($refund['referensi_transaksi'])) { ?> · Ref <?php echo htmlspecialchars($refund['referensi_transaksi'], ENT_QUOTES, 'UTF-8');?><?php } ?></p><?php } ?>
				<?php if (!empty($refundHistory[$refundId])) { ?><details class="order-status-timeline"><summary>Riwayat status refund</summary><ol><?php foreach ($refundHistory[$refundId] as $history) { ?><li><strong><?php echo htmlspecialchars($refundLabels[$history['status_sesudah']] ?? $history['status_sesudah'], ENT_QUOTES, 'UTF-8');?></strong> · <?php echo htmlspecialchars($history['tanggal_input'], ENT_QUOTES, 'UTF-8');?><?php if (!empty($history['catatan'])) { ?><br><span><?php echo htmlspecialchars($history['catatan'], ENT_QUOTES, 'UTF-8');?></span><?php } ?></li><?php } ?></ol></details><?php } ?>
				<?php if (in_array($refund['status'], array('waiting', 'rejected'), true) && $acceptedTotal > 0) { ?>
					<form method="POST" action="admin/module/retur/process.php" class="return-action-form">
						<?php echo csrf_field();?><input type="hidden" name="action" value="record_refund"><input type="hidden" name="refund_id" value="<?php echo $refundId;?>">
						<label>Nominal refund (Rp)<input type="number" name="nominal" min="1" max="<?php echo $acceptedTotal;?>" step="1" required></label>
						<label>Tanggal refund nyata<input type="datetime-local" name="tanggal_refund" value="<?php echo date('Y-m-d\TH:i');?>" required></label>
						<label>Metode pengembalian<input type="text" name="metode_refund" maxlength="60" placeholder="Transfer bank, tunai, dll." required></label>
						<label>Nomor referensi transaksi (opsional)<input type="text" name="referensi_transaksi" maxlength="120"></label>
						<label>Catatan admin<input type="text" name="note" maxlength="1000"></label>
						<button class="btn btn-primary btn-sm" type="submit">Catat Refund · Menunggu Verifikasi</button>
					</form>
				<?php } elseif ($refund['status'] === 'processing') { ?>
					<form method="POST" action="admin/module/retur/process.php" onsubmit="return confirm('Konfirmasi hanya setelah dana benar-benar dikembalikan kepada pelanggan.');"><?php echo csrf_field();?><input type="hidden" name="action" value="verify_refund"><input type="hidden" name="refund_id" value="<?php echo $refundId;?>"><button class="btn btn-success btn-sm" type="submit">Verifikasi Refund Berhasil</button></form>
					<form method="POST" action="admin/module/retur/process.php" class="return-action-form"><?php echo csrf_field();?><input type="hidden" name="action" value="reject_refund"><input type="hidden" name="refund_id" value="<?php echo $refundId;?>"><label>Alasan penolakan<input type="text" name="note" maxlength="1000" required></label><button class="btn btn-default btn-sm" type="submit">Tolak Refund</button></form>
				<?php } ?>
			</article>
		<?php } ?>
	</div>
</section></section>
