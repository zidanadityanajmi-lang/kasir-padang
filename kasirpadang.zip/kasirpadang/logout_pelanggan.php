<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
unset($_SESSION['customer']);
session_regenerate_id(true);
header('Location: katalog_pelanggan.php');
exit;
