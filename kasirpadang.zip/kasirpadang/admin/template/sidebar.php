<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
   
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
<?php 
  $id = $_SESSION['admin']['id_member'];
  $role = $_SESSION['admin']['level'];
  $currentPage = isset($page) ? $page : 'dashboard';
  $isInventoryPage = in_array($currentPage, array('barang', 'barang/tambah', 'barang/details', 'barang/edit', 'stok/riwayat'), true);
  $isInventoryMenuOpen = $isInventoryPage || in_array($currentPage, array('kategori', 'kategori/tambah'), true);
  $isSalesMenuOpen = in_array($currentPage, array('katalog', 'jual', 'pesanan', 'laporan', 'riwayat'), true);
  $isSettingsMenuOpen = in_array($currentPage, array('pengaturan', 'user', 'pelanggan', 'ulasan', 'audit', 'promosi', 'retur'), true);
  $hasil_profil = $lihat -> member_edit($id);
?>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <a class="sidebar-brand" href="index.php">
                  <span class="sidebar-brand-mark" aria-hidden="true"><i class="fa fa-pencil"></i></span>
                  <span><strong>ATK Suka Suka</strong><small>Penjualan &amp; Inventaris</small></span>
              </a>
              <div class="sidebar-profile">
                  <img src="assets/img/user/<?php echo htmlspecialchars($hasil_profil['gambar'], ENT_QUOTES, 'UTF-8');?>" alt="Foto profil <?php echo htmlspecialchars($hasil_profil['nm_member'], ENT_QUOTES, 'UTF-8');?>" class="sidebar-avatar">
                  <div class="sidebar-profile-copy">
                      <strong><?php echo htmlspecialchars($hasil_profil['nm_member'], ENT_QUOTES, 'UTF-8');?></strong>
                      <span>NIK <?php echo htmlspecialchars($hasil_profil['NIK'], ENT_QUOTES, 'UTF-8');?></span>
                      <span class="sidebar-role"><?php echo $role === 'admin' ? 'Administrator' : 'Pembeli / Kasir';?></span>
                  </div>
              </div>
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
                  <?php if($role === 'admin'){?>
                  <li class="mt">
                      <a class="<?php echo $currentPage === 'dashboard' ? 'active' : '';?>" href="index.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu <?php echo $isInventoryMenuOpen ? 'active' : '';?>">
                      <a class="sidebar-menu-toggle <?php echo $isInventoryMenuOpen ? 'active' : '';?>" href="#inventory-submenu" role="button"
                         aria-expanded="<?php echo $isInventoryMenuOpen ? 'true' : 'false';?>" aria-controls="inventory-submenu">
                          <i class="fa fa-desktop" aria-hidden="true"></i>
                          <span>Inventaris &amp; Katalog <i class="fa fa-angle-down sidebar-menu-chevron" aria-hidden="true"></i></span>
                      </a>
                      <ul class="sub collapse <?php echo $isInventoryMenuOpen ? 'show' : '';?>" id="inventory-submenu">
                          <li class="<?php echo $isInventoryPage && !(isset($_GET['stok']) && $_GET['stok'] === 'yes') ? 'active' : '';?>"><a href="index.php?page=barang">Data Produk ATK</a></li>
                          <li class="<?php echo in_array($currentPage, array('kategori', 'kategori/tambah'), true) ? 'active' : '';?>"><a href="index.php?page=kategori">Kategori Barang</a></li>
                          <li class="<?php echo isset($_GET['stok']) && $_GET['stok'] === 'yes' && $currentPage === 'barang' ? 'active' : '';?>"><a href="index.php?page=barang&amp;stok=yes">Stok Menipis</a></li>
                          <li class="<?php echo $currentPage === 'stok/riwayat' ? 'active' : '';?>"><a href="index.php?page=stok/riwayat">Riwayat Perubahan Stok</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $isSalesMenuOpen ? 'active' : '';?>">
                      <a class="sidebar-menu-toggle <?php echo $isSalesMenuOpen ? 'active' : '';?>" href="#sales-submenu" role="button"
                         aria-expanded="<?php echo $isSalesMenuOpen ? 'true' : 'false';?>" aria-controls="sales-submenu">
                          <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                          <span>Kasir &amp; Penjualan <i class="fa fa-angle-down sidebar-menu-chevron" aria-hidden="true"></i></span>
                      </a>
                      <ul class="sub collapse <?php echo $isSalesMenuOpen ? 'show' : '';?>" id="sales-submenu">
                          <li class="<?php echo $currentPage === 'jual' ? 'active' : '';?>"><a href="index.php?page=jual">Kasir (POS)</a></li>
                          <li class="<?php echo $currentPage === 'pesanan' ? 'active' : '';?>"><a class="sidebar-online-orders<?php echo $pendingOnlineOrders > 0 ? ' has-pending' : '';?>" href="index.php?page=pesanan" data-order-count="<?php echo (int) $pendingOnlineOrders;?>"><span>Pesanan Pelanggan Online</span><span class="sidebar-order-count" data-order-badge aria-live="polite" aria-atomic="true"<?php echo $pendingOnlineOrders > 0 ? '' : ' hidden';?>><?php echo (int) $pendingOnlineOrders;?></span></a></li>
                          <li class="<?php echo $currentPage === 'riwayat' ? 'active' : '';?>"><a href="index.php?page=riwayat">Riwayat Transaksi</a></li>
                          <li class="<?php echo $currentPage === 'laporan' ? 'active' : '';?>"><a href="index.php?page=laporan">Laporan Keuangan</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu <?php echo $isSettingsMenuOpen ? 'active' : '';?>">
                      <a class="sidebar-menu-toggle <?php echo $isSettingsMenuOpen ? 'active' : '';?>" href="#settings-submenu" role="button"
                         aria-expanded="<?php echo $isSettingsMenuOpen ? 'true' : 'false';?>" aria-controls="settings-submenu">
                          <i class="fa fa-cog" aria-hidden="true"></i>
                          <span>Pengaturan Toko <i class="fa fa-angle-down sidebar-menu-chevron" aria-hidden="true"></i></span>
                      </a>
                      <ul class="sub collapse <?php echo $isSettingsMenuOpen ? 'show' : '';?>" id="settings-submenu">
                          <li class="<?php echo $currentPage === 'pengaturan' ? 'active' : '';?>"><a href="index.php?page=pengaturan">Profil Toko</a></li>
                          <li class="<?php echo $currentPage === 'user' ? 'active' : '';?>"><a href="index.php?page=user">Manajemen Kasir/User</a></li>
                          <li class="<?php echo $currentPage === 'pelanggan' ? 'active' : '';?>"><a href="index.php?page=pelanggan">Manajemen Pelanggan</a></li>
                          <li class="<?php echo $currentPage === 'ulasan' ? 'active' : '';?>"><a href="index.php?page=ulasan">Moderasi Ulasan</a></li>
                          <li class="<?php echo $currentPage === 'audit' ? 'active' : '';?>"><a href="index.php?page=audit">Audit Aktivitas</a></li>
                          <li class="<?php echo $currentPage === 'promosi' ? 'active' : '';?>"><a href="index.php?page=promosi">Voucher Promosi</a></li>
                          <li class="<?php echo $currentPage === 'retur' ? 'active' : '';?>"><a href="index.php?page=retur">Retur &amp; Refund</a></li>
                      </ul>
                  </li>
                  <?php }else{?>
                  <li class="mt">
                      <a class="<?php echo $currentPage === 'katalog' ? 'active' : '';?>" href="index.php?page=katalog">
                          <i class="fa fa-th-large"></i>
                          <span>Katalog Produk ATK</span>
                      </a>
                  </li>
                  <li>
                      <a class="<?php echo $currentPage === 'jual' ? 'active' : '';?>" href="index.php?page=jual">
                          <i class="fa fa-shopping-cart"></i>
                          <span>Keranjang Belanja</span>
                      </a>
                  </li>
                  <?php }?>
                  <?php if($role === 'admin'){?>
                  <li class="sidebar-catalog-link"><a href="katalog_pelanggan.php"><i class="fa fa-external-link" aria-hidden="true"></i><span>Lihat Katalog Pelanggan</span></a></li>
                  <?php }?>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
