<?php
	/*
	 * PROSES TAMPIL  
	 */ 
	 class view {
		protected $db;
		function __construct($db){
			$this->db = $db;
		}
			
			function member(){
				$sql = "select member.*, login.*
						from member inner join login on member.id_member = login.id_member";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function member_edit($id){
				$sql = "select member.*, login.*
						from member inner join login on member.id_member = login.id_member
						where member.id_member= ?";
				$row = $this-> db -> prepare($sql);
				$row -> execute(array($id));
				$hasil = $row -> fetch();
				return $hasil;
			}
			
			function toko(){
				$sql = "select*from toko where id_toko='1'";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}

			function kategori(){
				$sql = "select*from kategori";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function barang(){
				$sql = "select barang.*, kategori.id_kategori, kategori.nama_kategori
						from barang inner join kategori on barang.id_kategori = kategori.id_kategori 
						ORDER BY id DESC";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetchAll();
				return $hasil;
			}
			
			function barang_stok(){
				$sql = "select barang.*, kategori.id_kategori, kategori.nama_kategori
						from barang inner join kategori on barang.id_kategori = kategori.id_kategori 
						where CAST(stok AS UNSIGNED) <= 5
						ORDER BY id DESC";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function barang_page($page, $pageSize, $lowStockOnly = false, $searchTerm = ''){
				$conditions = array();
				$parameters = array();
				if ($lowStockOnly) {
					$conditions[] = 'CAST(barang.stok AS UNSIGNED) <= 5';
				}
				if ($searchTerm !== '') {
					$conditions[] = '(barang.id_barang LIKE ? OR barang.nama_barang LIKE ? OR barang.merk LIKE ?)';
					$pattern = '%' . $searchTerm . '%';
					$parameters = array($pattern, $pattern, $pattern);
				}
				$where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
				$sql = 'SELECT barang.*, kategori.id_kategori, kategori.nama_kategori
						FROM barang INNER JOIN kategori ON barang.id_kategori = kategori.id_kategori
						' . $where . ' ORDER BY barang.id DESC LIMIT ? OFFSET ?';
				$row = $this->db->prepare($sql);
				$parameterIndex = 1;
				foreach ($parameters as $parameter) {
					$row->bindValue($parameterIndex++, $parameter, PDO::PARAM_STR);
				}
				$row->bindValue($parameterIndex++, max(1, (int) $pageSize), PDO::PARAM_INT);
				$row->bindValue($parameterIndex, max(0, ((int) $page - 1) * (int) $pageSize), PDO::PARAM_INT);
				$row->execute();
				return $row->fetchAll(PDO::FETCH_ASSOC);
			}

			function barang_count($lowStockOnly = false, $searchTerm = ''){
				$conditions = array();
				$parameters = array();
				if ($lowStockOnly) {
					$conditions[] = 'CAST(stok AS UNSIGNED) <= 5';
				}
				if ($searchTerm !== '') {
					$conditions[] = '(id_barang LIKE ? OR nama_barang LIKE ? OR merk LIKE ?)';
					$pattern = '%' . $searchTerm . '%';
					$parameters = array($pattern, $pattern, $pattern);
				}
				$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
				$row = $this->db->prepare('SELECT COUNT(*) FROM barang' . $where);
				$row->execute($parameters);
				return (int) $row->fetchColumn();
			}

			function barang_summary($lowStockOnly = false, $searchTerm = ''){
				$conditions = array();
				$parameters = array();
				if ($lowStockOnly) {
					$conditions[] = 'CAST(stok AS UNSIGNED) <= 5';
				}
				if ($searchTerm !== '') {
					$conditions[] = '(id_barang LIKE ? OR nama_barang LIKE ? OR merk LIKE ?)';
					$pattern = '%' . $searchTerm . '%';
					$parameters = array($pattern, $pattern, $pattern);
				}
				$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
				$sql = 'SELECT COALESCE(SUM(CAST(stok AS UNSIGNED)), 0) AS total_stok,
						COALESCE(SUM(CAST(harga_beli AS UNSIGNED) * CAST(stok AS UNSIGNED)), 0) AS total_modal,
						COALESCE(SUM(CAST(harga_jual AS UNSIGNED) * CAST(stok AS UNSIGNED)), 0) AS total_jual
						FROM barang' . $where;
				$row = $this->db->prepare($sql);
				$row->execute($parameters);
				return $row->fetch(PDO::FETCH_ASSOC);
			}

			function barang_edit($id){
				$sql = "select barang.*, kategori.id_kategori, kategori.nama_kategori
						from barang inner join kategori on barang.id_kategori = kategori.id_kategori
						where id_barang=?";
				$row = $this-> db -> prepare($sql);
				$row -> execute(array($id));
				$hasil = $row -> fetch();
				return $hasil;
			}

			function barang_cari($cari){
				$sql = "select barang.*, kategori.id_kategori, kategori.nama_kategori
						from barang inner join kategori on barang.id_kategori = kategori.id_kategori
						where id_barang like ? or nama_barang like ? or merk like ?";
				$row = $this-> db -> prepare($sql);
				$pattern = '%' . $cari . '%';
				$row -> execute(array($pattern, $pattern, $pattern));
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function barang_id(){
				$row = $this->db->query("SELECT id_barang FROM barang WHERE id_barang REGEXP '^BR[0-9]+$'");
				$next = 1;
				foreach ($row->fetchAll(PDO::FETCH_COLUMN) as $productId) {
					$number = (int) substr($productId, 2);
					$next = max($next, $number + 1);
				}
				return 'BR' . str_pad((string) $next, 3, '0', STR_PAD_LEFT);
			}

			function kategori_edit($id){
				$sql = "select*from kategori where id_kategori=?";
				$row = $this-> db -> prepare($sql);
				$row -> execute(array($id));
				$hasil = $row -> fetch();
				return $hasil;
			}

			function kategori_row(){
				$sql = "select*from kategori";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> rowCount();
				return $hasil;
			}

			function barang_row(){
				$sql = "select*from barang";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> rowCount();
				return $hasil;
			}

			function barang_stok_row(){
				$sql ="SELECT SUM(stok) as jml FROM barang";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}

			function barang_beli_row(){
				$sql ="SELECT SUM(harga_beli) as beli FROM barang";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}

			function jual_row(){
				$sql ="SELECT SUM(jumlah) as stok FROM nota";
				$row = $this-> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}

			function dashboard_date_prefixes($date){
				$monthNames = array(
					1 => array('Januari', 'January'), 2 => array('Februari', 'February'),
					3 => array('Maret', 'March'), 4 => array('April'),
					5 => array('Mei', 'May'), 6 => array('Juni', 'June'),
					7 => array('Juli', 'July'), 8 => array('Agustus', 'August'),
					9 => array('September'), 10 => array('Oktober', 'October'),
					11 => array('November'), 12 => array('Desember', 'December')
				);
				$date = $date instanceof DateTimeInterface ? $date : new DateTimeImmutable((string) $date);
				$prefixes = array();
				foreach ($monthNames[(int) $date->format('n')] as $monthName) {
					$prefixes[] = $date->format('j') . ' ' . $monthName . ' ' . $date->format('Y') . ',%';
				}
				return $prefixes;
			}

			function dashboard_has_transaction_codes(){
				$column = $this->db->query("SHOW COLUMNS FROM nota LIKE 'kode_transaksi'");
				return $column->fetch(PDO::FETCH_ASSOC) !== false;
			}

			function dashboard_sales_on($date, $hasTransactionCode = null){
				if ($hasTransactionCode === null) {
					$hasTransactionCode = $this->dashboard_has_transaction_codes();
				}
				$prefixes = $this->dashboard_date_prefixes($date);
				$conditions = implode(' OR ', array_fill(0, count($prefixes), 'tanggal_input LIKE ?'));
				$transactionKey = $hasTransactionCode
					? "CASE WHEN NULLIF(kode_transaksi, '') IS NOT NULL THEN kode_transaksi ELSE CONCAT('legacy:', id_member, ':', tanggal_input) END"
					: "CONCAT('legacy:', id_member, ':', tanggal_input)";
				$sql = "SELECT COALESCE(SUM(CAST(total AS UNSIGNED)), 0) AS revenue,
						COUNT(DISTINCT $transactionKey) AS transaction_count
						FROM nota WHERE ($conditions)";
				$row = $this->db->prepare($sql);
				$row->execute($prefixes);
				return $row->fetch(PDO::FETCH_ASSOC);
			}

			function dashboard_data(){
				$hasTransactionCode = $this->dashboard_has_transaction_codes();
				$today = new DateTimeImmutable('today');
				$todaySales = $this->dashboard_sales_on($today, $hasTransactionCode);
				$allTimeTransactionKey = $hasTransactionCode
					? "COALESCE(NULLIF(kode_transaksi, ''), CONCAT('legacy:', id_member, ':', tanggal_input))"
					: "CONCAT('legacy:', id_member, ':', tanggal_input)";
				$allTimeSalesQuery = $this->db->query(
					"SELECT COALESCE(SUM(CAST(total AS UNSIGNED)), 0) AS revenue,
						COUNT(DISTINCT $allTimeTransactionKey) AS transaction_count FROM nota"
				);
				$allTimeSales = $allTimeSalesQuery->fetch(PDO::FETCH_ASSOC);
				$trend = array();
				$weekPrefixes = array();
				for ($offset = 6; $offset >= 0; $offset--) {
					$date = $today->modify('-' . $offset . ' days');
					$dailySales = $this->dashboard_sales_on($date, $hasTransactionCode);
					$trend[] = array(
						'label' => $date->format('d/m'),
						'revenue' => (int) $dailySales['revenue']
					);
					$weekPrefixes = array_merge($weekPrefixes, $this->dashboard_date_prefixes($date));
				}

				$weekConditions = implode(' OR ', array_fill(0, count($weekPrefixes), 'nota.tanggal_input LIKE ?'));
				$productName = $hasTransactionCode
					? 'COALESCE(MAX(nota.nama_barang_snapshot), MAX(barang.nama_barang), nota.id_barang)'
					: 'COALESCE(MAX(barang.nama_barang), nota.id_barang)';
				$bestSellersQuery = $this->db->prepare(
					"SELECT nota.id_barang, $productName AS nama_barang,
						COALESCE(SUM(CAST(nota.jumlah AS UNSIGNED)), 0) AS quantity,
						COALESCE(SUM(CAST(nota.total AS UNSIGNED)), 0) AS revenue
						FROM nota LEFT JOIN barang ON barang.id_barang = nota.id_barang
						WHERE ($weekConditions)
						GROUP BY nota.id_barang ORDER BY quantity DESC, revenue DESC LIMIT 5"
				);
				$bestSellersQuery->execute($weekPrefixes);

				$lowStockQuery = $this->db->prepare(
					"SELECT id_barang, nama_barang, merk, stok, satuan_barang
						FROM barang WHERE CAST(stok AS UNSIGNED) <= 5
						ORDER BY CAST(stok AS UNSIGNED) ASC, nama_barang ASC LIMIT 8"
				);
				$lowStockQuery->execute();

				$productCountQuery = $this->db->query('SELECT COUNT(*) FROM barang');
				$categoryCountQuery = $this->db->query('SELECT COUNT(*) FROM kategori');
				$customerCountQuery = $this->db->query('SELECT COUNT(*) FROM pelanggan');
				$pendingOrderCountQuery = $this->db->query("SELECT COUNT(*) FROM pesanan WHERE status = 'pending'");
				$processingOrderCountQuery = $this->db->query("SELECT COUNT(*) FROM pesanan WHERE status = 'processing'");
				$lowStockCountQuery = $this->db->query('SELECT COUNT(*) FROM barang WHERE CAST(stok AS UNSIGNED) <= 5');

				return array(
					'today_revenue' => (int) $todaySales['revenue'],
					'today_transactions' => (int) $todaySales['transaction_count'],
					'all_time_revenue' => (int) $allTimeSales['revenue'],
					'all_time_transactions' => (int) $allTimeSales['transaction_count'],
					'product_count' => (int) $productCountQuery->fetchColumn(),
					'category_count' => (int) $categoryCountQuery->fetchColumn(),
					'customer_count' => (int) $customerCountQuery->fetchColumn(),
					'pending_order_count' => (int) $pendingOrderCountQuery->fetchColumn(),
					'processing_order_count' => (int) $processingOrderCountQuery->fetchColumn(),
					'low_stock_count' => (int) $lowStockCountQuery->fetchColumn(),
					'trend' => $trend,
					'best_sellers' => $bestSellersQuery->fetchAll(PDO::FETCH_ASSOC),
					'low_stock' => $lowStockQuery->fetchAll(PDO::FETCH_ASSOC)
				);
			}

			function dashboard_monthly_sales($year){
				$year = filter_var($year, FILTER_VALIDATE_INT);
				if ($year === false || $year < 2000 || $year > 2100) {
					throw new InvalidArgumentException('Tahun laporan dashboard tidak valid.');
				}

				$monthly = array();
				for ($month = 1; $month <= 12; $month++) {
					$period = sprintf('%02d-%04d', $month, $year);
					$monthly[$period] = array(
						'label' => $month,
						'revenue' => 0,
						'quantity' => 0
					);
				}

				$periods = array_keys($monthly);
				$placeholders = implode(',', array_fill(0, count($periods), '?'));
				$query = $this->db->prepare(
					"SELECT periode,
						COALESCE(SUM(CAST(total AS UNSIGNED)), 0) AS revenue,
						COALESCE(SUM(CAST(jumlah AS UNSIGNED)), 0) AS quantity
						FROM nota WHERE periode IN ($placeholders) GROUP BY periode"
				);
				$query->execute($periods);
				foreach ($query->fetchAll(PDO::FETCH_ASSOC) as $row) {
					if (isset($monthly[$row['periode']])) {
						$monthly[$row['periode']]['revenue'] = (int) $row['revenue'];
						$monthly[$row['periode']]['quantity'] = (int) $row['quantity'];
					}
				}

				$yearsQuery = $this->db->query(
					"SELECT DISTINCT RIGHT(periode, 4) AS year FROM nota
						WHERE periode REGEXP '^(0[1-9]|1[0-2])-[0-9]{4}$'
						ORDER BY year DESC"
				);
				$years = array_map('intval', $yearsQuery->fetchAll(PDO::FETCH_COLUMN));
				$years[] = (int) date('Y');
				$years = array_values(array_unique($years));
				rsort($years, SORT_NUMERIC);

				return array(
					'year' => (int) $year,
					'months' => array_values($monthly),
					'years' => $years
				);
			}

			function transaksi_terbaru($limit = 50){
				$limit = min(100, max(1, (int) $limit));
				$transactionKey = $this->dashboard_has_transaction_codes()
					? "COALESCE(NULLIF(nota.kode_transaksi, ''), CONCAT('legacy:', nota.id_member, ':', nota.tanggal_input))"
					: "CONCAT('legacy:', nota.id_member, ':', nota.tanggal_input)";
				$sql = "SELECT MAX(nota.id_nota) AS receipt_number,
						$transactionKey AS transaction_key,
						MAX(nota.tanggal_input) AS tanggal_input, MAX(member.nm_member) AS nm_member,
						COUNT(*) AS jenis_barang, SUM(CAST(nota.jumlah AS UNSIGNED)) AS jumlah,
						SUM(CAST(nota.total AS UNSIGNED)) AS total
						FROM nota LEFT JOIN member ON member.id_member = nota.id_member
						GROUP BY transaction_key ORDER BY MAX(nota.id_nota) DESC LIMIT ?";
				$row = $this->db->prepare($sql);
				$row->bindValue(1, $limit, PDO::PARAM_INT);
				$row->execute();
				return $row->fetchAll(PDO::FETCH_ASSOC);
			}
			
			function jual(){
				return $this->periode_jual(date('m-Y'));
			}

			function periode_jual($periode){
				$parts = explode('-', $periode);
				if (count($parts) !== 2 || !preg_match('/^(0[1-9]|1[0-2])$/', $parts[0]) || !preg_match('/^\d{4}$/', $parts[1])) {
					return array();
				}
				$monthNames = array(
					1 => array('Januari', 'January'), 2 => array('Februari', 'February'),
					3 => array('Maret', 'March'), 4 => array('April'),
					5 => array('Mei', 'May'), 6 => array('Juni', 'June'),
					7 => array('Juli', 'July'), 8 => array('Agustus', 'August'),
					9 => array('September'), 10 => array('Oktober', 'October'),
					11 => array('November'), 12 => array('Desember', 'December')
				);
				$monthNumber = (int) $parts[0];
				$year = (int) $parts[1];
				$daysInMonth = (int) date('t', strtotime(sprintf('%04d-%02d-01', $year, $monthNumber)));
				$datePrefixes = array();
				for ($day = 1; $day <= $daysInMonth; $day++) {
					foreach ($monthNames[$monthNumber] as $monthName) {
						$datePrefixes[] = $day . ' ' . $monthName . ' ' . $year . ',%';
					}
				}
				$conditions = implode(' OR ', array_fill(0, count($datePrefixes), 'nota.tanggal_input LIKE ?'));
				$sql ="				SELECT nota.* , barang.id_barang, COALESCE(nota.nama_barang_snapshot, barang.nama_barang, nota.id_barang) AS nama_barang, barang.harga_beli, member.id_member,
						member.nm_member from nota 
					   left join barang on barang.id_barang=nota.id_barang 
					   left join member on member.id_member=nota.id_member WHERE ($conditions)
					   ORDER BY id_nota ASC";
				$row = $this-> db -> prepare($sql);
				$row -> execute($datePrefixes);
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function hari_jual($hari){
				$date = DateTime::createFromFormat('!Y-m-d', $hari);
				if (!$date || $date->format('Y-m-d') !== $hari) {
					return array();
				}
				$monthNames = array(
					1 => array('Januari', 'January'), 2 => array('Februari', 'February'),
					3 => array('Maret', 'March'), 4 => array('April'),
					5 => array('Mei', 'May'), 6 => array('Juni', 'June'),
					7 => array('Juli', 'July'), 8 => array('Agustus', 'August'),
					9 => array('September'), 10 => array('Oktober', 'October'),
					11 => array('November'), 12 => array('Desember', 'December')
				);
				$datePrefixes = array();
				foreach ($monthNames[(int) $date->format('n')] as $monthName) {
					$datePrefixes[] = $date->format('j') . ' ' . $monthName . ' ' . $date->format('Y') . ',%';
				}
				$conditions = implode(' OR ', array_fill(0, count($datePrefixes), 'nota.tanggal_input LIKE ?'));
				$sql ="				SELECT nota.* , barang.id_barang, COALESCE(nota.nama_barang_snapshot, barang.nama_barang, nota.id_barang) AS nama_barang, barang.harga_beli, member.id_member,
						member.nm_member from nota 
					   left join barang on barang.id_barang=nota.id_barang 
					   left join member on member.id_member=nota.id_member WHERE ($conditions)
					   ORDER BY id_nota ASC";
				$row = $this-> db -> prepare($sql);
				$row -> execute($datePrefixes);
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function penjualan($memberId){
				$sql ="SELECT penjualan.* , barang.id_barang, barang.nama_barang, barang.stok, member.id_member,
						member.nm_member from penjualan 
					   left join barang on barang.id_barang=penjualan.id_barang 
					   left join member on member.id_member=penjualan.id_member
					   WHERE penjualan.id_member = ?
					   ORDER BY id_penjualan";
				$row = $this-> db -> prepare($sql);
				$row -> execute(array((int) $memberId));
				$hasil = $row -> fetchAll();
				return $hasil;
			}

			function jumlah($memberId){
				$sql ="SELECT SUM(total) as bayar FROM penjualan WHERE id_member = ?";
				$row = $this -> db -> prepare($sql);
				$row -> execute(array((int) $memberId));
				$hasil = $row -> fetch();
				return $hasil;
			}

			function jumlah_nota(){
				$sql ="SELECT SUM(total) as bayar FROM nota";
				$row = $this -> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}

			function jml(){
				$sql ="SELECT SUM(harga_beli*stok) as byr FROM barang";
				$row = $this -> db -> prepare($sql);
				$row -> execute();
				$hasil = $row -> fetch();
				return $hasil;
			}
	 }
