<?php

function record_stock_movement(PDO $db, $productId, $movementType, $quantity, $stockBefore, $stockAfter, $description, $reference, $memberId)
{
	$movementType = (string) $movementType;
	$quantity = (int) $quantity;
	$stockBefore = (int) $stockBefore;
	$stockAfter = (int) $stockAfter;
	if (!in_array($movementType, array('masuk', 'keluar', 'penyesuaian'), true)
		|| $quantity < 1
		|| $stockBefore < 0
		|| $stockAfter < 0
		|| strlen((string) $productId) > 255
		|| trim((string) $description) === '') {
		throw new InvalidArgumentException('Data perubahan stok tidak valid.');
	}

	$productNameQuery = $db->prepare('SELECT nama_barang FROM barang WHERE id_barang = ? LIMIT 1');
	$productNameQuery->execute(array((string) $productId));
	$productName = $productNameQuery->fetchColumn();
	if ($productName === false) {
		throw new RuntimeException('Produk perubahan stok tidak ditemukan.');
	}

	$insert = $db->prepare(
		'INSERT INTO riwayat_stok
			(id_barang, nama_barang_snapshot, jenis_perubahan, jumlah, stok_sebelum, stok_sesudah, keterangan, referensi, id_member, tanggal_input)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
	);
	$insert->execute(array(
		(string) $productId,
		(string) $productName,
		$movementType,
		$quantity,
		$stockBefore,
		$stockAfter,
		substr(trim((string) $description), 0, 255),
		$reference !== null && $reference !== '' ? substr((string) $reference, 0, 64) : null,
		$memberId !== null ? (int) $memberId : null,
		date('Y-m-d H:i:s')
	));
}
