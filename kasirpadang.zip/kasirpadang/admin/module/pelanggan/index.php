<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php
if (($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	return;
}

$search = trim((string) ($_GET['q'] ?? ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 100, 'UTF-8') : substr($search, 0, 100);
$pageSize = 25;
$pageNumber = filter_var($_GET['hal'] ?? 1, FILTER_VALIDATE_INT);
$pageNumber = $pageNumber === false ? 1 : max(1, $pageNumber);
$where = '';
$parameters = array();
if ($search !== '') {
	$where = ' WHERE nama_pelanggan LIKE ? OR email LIKE ? OR no_hp LIKE ?';
	$searchPattern = '%' . $search . '%';
	$parameters = array($searchPattern, $searchPattern, $searchPattern);
}
$countQuery = $config->prepare('SELECT COUNT(*) FROM pelanggan' . $where);
$countQuery->execute($parameters);
$totalCustomers = (int) $countQuery->fetchColumn();
$totalPages = max(1, (int) ceil($totalCustomers / $pageSize));
$pageNumber = min($pageNumber, $totalPages);
$customersQuery = $config->prepare(
	'SELECT pelanggan.id_pelanggan, pelanggan.nama_pelanggan, pelanggan.email, pelanggan.no_hp,
			pelanggan.alamat, pelanggan.status, pelanggan.tanggal_daftar,
			COUNT(pesanan.id_pesanan) AS total_pesanan,
			COALESCE(SUM(CASE WHEN pesanan.status = \'completed\' THEN pesanan.total ELSE 0 END), 0) AS total_belanja
		FROM pelanggan LEFT JOIN pesanan ON pesanan.id_pelanggan = pelanggan.id_pelanggan'
		. $where . ' GROUP BY pelanggan.id_pelanggan ORDER BY pelanggan.tanggal_daftar DESC LIMIT ? OFFSET ?'
);
$parameterIndex = 1;
foreach ($parameters as $parameter) {
	$customersQuery->bindValue($parameterIndex++, $parameter, PDO::PARAM_STR);
}
$customersQuery->bindValue($parameterIndex++, $pageSize, PDO::PARAM_INT);
$customersQuery->bindValue($parameterIndex, ($pageNumber - 1) * $pageSize, PDO::PARAM_INT);
$customersQuery->execute();
$customers = $customersQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading"><div><p class="dashboard-eyebrow">Pelanggan &amp; akun</p><h1>Manajemen Pelanggan</h1></div></div>
		<?php if (isset($_GET['success']) && $_GET['success'] === 'status') { ?><div class="alert alert-success" role="status">Status akun pelanggan berhasil diperbarui.</div><?php } ?>
		<?php if (isset($_GET['error']) && $_GET['error'] === 'invalid') { ?><div class="alert alert-danger" role="alert">Permintaan perubahan status tidak valid.</div><?php } ?>
		<div class="dashboard-card history-card">
			<div class="dashboard-card-heading"><div><p class="dashboard-eyebrow">Akun yang terdaftar</p><h2><?php echo number_format($totalCustomers);?> pelanggan</h2></div></div>
			<form method="GET" action="index.php" class="inventory-list-tools">
				<input type="hidden" name="page" value="pelanggan">
				<label class="sr-only" for="customerSearch">Cari nama, email, atau nomor telepon</label>
				<input id="customerSearch" type="search" name="q" class="form-control" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8');?>" placeholder="Cari nama, email, atau nomor telepon">
				<button type="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i> Cari</button>
			</form>
			<?php if (!$customers) { ?><p class="dashboard-empty"><?php echo $search !== '' ? 'Tidak ada pelanggan yang cocok.' : 'Belum ada akun pelanggan terdaftar.';?></p><?php } else { ?>
				<div class="table-responsive">
					<table class="table table-hover">
						<thead><tr><th>Pelanggan</th><th>Kontak</th><th>Alamat</th><th>Bergabung</th><th>Pesanan</th><th>Total belanja selesai</th><th>Status akun</th><th>Aksi</th></tr></thead>
						<tbody>
						<?php foreach ($customers as $customer) { ?>
							<tr>
								<td><strong><?php echo htmlspecialchars($customer['nama_pelanggan'], ENT_QUOTES, 'UTF-8');?></strong><small class="online-order-meta"><?php echo htmlspecialchars($customer['email'], ENT_QUOTES, 'UTF-8');?></small></td>
								<td><a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $customer['no_hp']), ENT_QUOTES, 'UTF-8');?>"><?php echo htmlspecialchars($customer['no_hp'], ENT_QUOTES, 'UTF-8');?></a></td>
								<td><?php echo htmlspecialchars($customer['alamat'] ?? '—', ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo htmlspecialchars($customer['tanggal_daftar'], ENT_QUOTES, 'UTF-8');?></td>
								<td><?php echo number_format((int) $customer['total_pesanan']);?></td>
								<td>Rp <?php echo number_format((int) $customer['total_belanja'], 0, ',', '.');?></td>
								<td><span class="online-order-status <?php echo $customer['status'] === 'active' ? 'status-completed' : 'status-cancelled';?>"><?php echo $customer['status'] === 'active' ? 'Aktif' : 'Dinonaktifkan';?></span></td>
								<td>
									<form method="POST" action="admin/module/pelanggan/process.php" onsubmit="return confirm('Ubah status akun pelanggan ini?');">
										<?php echo csrf_field();?>
										<input type="hidden" name="customer_id" value="<?php echo (int) $customer['id_pelanggan'];?>">
										<input type="hidden" name="action" value="<?php echo $customer['status'] === 'active' ? 'deactivate' : 'activate';?>">
										<button type="submit" class="btn btn-<?php echo $customer['status'] === 'active' ? 'default' : 'success';?> btn-sm"><?php echo $customer['status'] === 'active' ? 'Nonaktifkan' : 'Aktifkan';?></button>
									</form>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
				<?php if ($totalPages > 1) { ?>
					<nav class="inventory-pagination" aria-label="Navigasi daftar pelanggan"><span>Halaman <?php echo $pageNumber;?> dari <?php echo $totalPages;?></span><div>
						<?php if ($pageNumber > 1) { ?><a class="btn btn-default" href="index.php?<?php echo htmlspecialchars(http_build_query(array('page' => 'pelanggan', 'q' => $search, 'hal' => $pageNumber - 1)), ENT_QUOTES, 'UTF-8');?>">Sebelumnya</a><?php } ?>
						<?php if ($pageNumber < $totalPages) { ?><a class="btn btn-default" href="index.php?<?php echo htmlspecialchars(http_build_query(array('page' => 'pelanggan', 'q' => $search, 'hal' => $pageNumber + 1)), ENT_QUOTES, 'UTF-8');?>">Berikutnya</a><?php } ?>
					</div></nav>
				<?php } ?>
			<?php } ?>
		</div>
	</section>
</section>
