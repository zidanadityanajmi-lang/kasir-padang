<?php

function customer_account_escape($value)
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function customer_account_phone_is_valid($phone)
{
	$digits = preg_replace('/\D+/', '', (string) $phone);
	return strlen($digits) >= 8 && strlen($digits) <= 15;
}

function customer_account_session()
{
	return isset($_SESSION['customer']) && is_array($_SESSION['customer'])
		&& !empty($_SESSION['customer']['id_pelanggan'])
		? $_SESSION['customer']
		: null;
}
