ALTER TABLE `pesanan`
  ADD COLUMN `status_pembayaran` varchar(20) NOT NULL DEFAULT 'pending' AFTER `metode_pembayaran`,
  ADD COLUMN `tanggal_pembayaran` datetime DEFAULT NULL AFTER `status_pembayaran`,
  ADD KEY `idx_pesanan_payment_status` (`status_pembayaran`, `tanggal_input`);

UPDATE `pesanan`
  SET `status_pembayaran` = 'paid',
      `tanggal_pembayaran` = COALESCE(`tanggal_selesai`, `tanggal_input`)
  WHERE `status` = 'completed' AND `status_pembayaran` = 'pending';

CREATE TABLE `riwayat_stok` (
  `id_riwayat_stok` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_barang` varchar(255) NOT NULL,
  `nama_barang_snapshot` text NOT NULL,
  `jenis_perubahan` varchar(20) NOT NULL,
  `jumlah` int unsigned NOT NULL,
  `stok_sebelum` int unsigned NOT NULL,
  `stok_sesudah` int unsigned NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `referensi` varchar(64) DEFAULT NULL,
  `id_member` int(11) DEFAULT NULL,
  `tanggal_input` datetime NOT NULL,
  PRIMARY KEY (`id_riwayat_stok`),
  KEY `idx_riwayat_stok_barang_tanggal` (`id_barang`, `tanggal_input`),
  KEY `idx_riwayat_stok_tanggal` (`tanggal_input`),
  KEY `idx_riwayat_stok_member` (`id_member`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
