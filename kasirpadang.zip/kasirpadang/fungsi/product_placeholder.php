<?php
$name = trim((string) ($_GET['name'] ?? 'Perlengkapan ATK'));
$brand = trim((string) ($_GET['brand'] ?? ''));
$category = trim((string) ($_GET['category'] ?? ''));
$name = function_exists('mb_substr') ? mb_substr($name, 0, 80, 'UTF-8') : substr($name, 0, 80);
$brand = function_exists('mb_substr') ? mb_substr($brand, 0, 48, 'UTF-8') : substr($brand, 0, 48);
$category = function_exists('mb_substr') ? mb_substr($category, 0, 60, 'UTF-8') : substr($category, 0, 60);
$searchText = strtolower($name . ' ' . $category);
$type = 'stationery';

if (preg_match('/penghapus/', $searchText)) {
	$type = 'eraser';
} elseif (preg_match('/rautan|serutan|sharpener/', $searchText)) {
	$type = 'sharpener';
} elseif (preg_match('/penggaris|ruler/', $searchText)) {
	$type = 'ruler';
} elseif (preg_match('/tipe.?x|correction.?tape|corrector/', $searchText)) {
	$type = 'correction';
} elseif (preg_match('/gunting|scissors/', $searchText)) {
	$type = 'scissors';
} elseif (preg_match('/cutter|pemotong/', $searchText)) {
	$type = 'cutter';
} elseif (preg_match('/lakban|isolasi|tape|perekat/', $searchText)) {
	$type = 'tape';
} elseif (preg_match('/buku|notebook|memo|kwitansi|gambar|sketchbook/', $searchText)) {
	$type = 'book';
} elseif (preg_match('/hvs|kertas|paper|folio/', $searchText)) {
	$type = 'paper';
} elseif (preg_match('/pulpen|pena|pen\b|pensil|spidol|marker|highlighter/', $searchText)) {
	$type = 'writing';
} elseif (preg_match('/map|odner|arsip|binder|clip/', $searchText)) {
	$type = 'folder';
} elseif (preg_match('/stapler|staples/', $searchText)) {
	$type = 'stapler';
}

$art = array(
	'eraser' => '<g transform="rotate(-18 320 210)"><rect x="197" y="156" width="246" height="112" rx="26" fill="#f3a5a1"/><path d="M321 157v110" stroke="#fff" stroke-width="8"/><path d="M330 158h87a26 26 0 0 1 26 26v60a26 26 0 0 1-26 26h-87z" fill="#fff" opacity=".8"/></g>',
	'sharpener' => '<path d="m221 267 24-105a24 24 0 0 1 23-19h103a24 24 0 0 1 23 19l25 105a24 24 0 0 1-23 29H244a24 24 0 0 1-23-29z" fill="#18a285"/><ellipse cx="319" cy="177" rx="35" ry="15" fill="#173f3b"/><path d="m297 172 22 7 22-7" fill="none" stroke="#a9c8bd" stroke-width="8" stroke-linecap="round"/>',
	'ruler' => '<g transform="rotate(-8 320 210)"><rect x="137" y="174" width="366" height="76" rx="12" fill="#e9c66f" fill-opacity=".72" stroke="#bd9b49" stroke-width="5"/><path d="M165 176v28m34-28v18m34-18v28m34-28v18m34-18v28m34-28v18m34-18v28m34-28v18m34-18v28m34-28v18" stroke="#53655c" stroke-width="4"/></g>',
	'correction' => '<path d="M217 182a32 32 0 0 1 32-32h120a32 32 0 0 1 32 32v93a32 32 0 0 1-32 32H249a32 32 0 0 1-32-32z" fill="#f8f8f3" stroke="#c7d4ce" stroke-width="6"/><path d="M255 191h73a25 25 0 0 1 25 25v38h-98z" fill="#e9a1a1"/><circle cx="353" cy="232" r="25" fill="#fff" stroke="#a8b8b0" stroke-width="6"/><path d="M378 216l41-22v72l-41-22z" fill="#dce8e2"/>',
	'scissors' => '<g fill="none" stroke="#477f70" stroke-width="15" stroke-linecap="round"><path d="m286 208 145-88-85 112"/><path d="m303 203 132 102-94-91"/></g><circle cx="229" cy="148" r="44" fill="none" stroke="#e78b78" stroke-width="17"/><circle cx="229" cy="268" r="44" fill="none" stroke="#e78b78" stroke-width="17"/><circle cx="302" cy="207" r="12" fill="#53645c"/>',
	'cutter' => '<g transform="rotate(-18 320 210)"><rect x="184" y="174" width="274" height="80" rx="17" fill="#e98a72"/><rect x="224" y="189" width="190" height="48" rx="10" fill="#f7f8f5"/><path d="m414 189 67-25-26 65-41 8z" fill="#b9c9c1"/><path d="M252 214h115" stroke="#a8bbb2" stroke-width="7" stroke-linecap="round"/></g>',
	'tape' => '<circle cx="320" cy="214" r="113" fill="#e8c66d"/><circle cx="320" cy="214" r="53" fill="#f4f7f4"/><circle cx="320" cy="214" r="35" fill="#dfe8e3"/><path d="M400 133q67 5 70 60v32h-41v-26q0-24-29-28z" fill="#dfb54f"/>',
	'book' => '<g transform="rotate(-5 320 205)"><rect x="196" y="112" width="250" height="196" rx="18" fill="#fff" stroke="#d4dfd9" stroke-width="6"/><path d="M235 113v193" stroke="#0a725e" stroke-width="28"/><path d="M282 159h124m-124 30h124m-124 30h124m-124 30h92" stroke="#d6e1db" stroke-width="8" stroke-linecap="round"/><path d="M224 136v146" stroke="#f0a38d" stroke-width="5" stroke-dasharray="4 10"/></g>',
	'paper' => '<g><path d="m196 147 214-34 51 142-212 43z" fill="#fff" stroke="#d3dfd8" stroke-width="6"/><path d="m196 147 214-34 12 33-212 39z" fill="#77aa96"/><path d="m209 185 212-39 9 22-212 39zm9 25 212-39 9 22-212 39z" fill="#e9eeeb"/><rect x="263" y="205" width="126" height="45" rx="6" fill="#fff"/><path d="M279 220h92m-92 14h68" stroke="#b3c9be" stroke-width="6" stroke-linecap="round"/></g>',
	'folder' => '<path d="M181 164a21 21 0 0 1 21-21h82l27 30h128a21 21 0 0 1 21 21v100a21 21 0 0 1-21 21H202a21 21 0 0 1-21-21z" fill="#d8a85f"/><path d="M204 188h229l-25 104H184z" fill="#f1ca7e"/><path d="M249 215h110" stroke="#fff0d4" stroke-width="9" stroke-linecap="round"/>',
	'stapler' => '<path d="M194 229a24 24 0 0 1 24-24h208a24 24 0 0 1 24 24v39H194z" fill="#dd816b"/><path d="M226 205q21-80 95-80h112q22 0 22 22v31H285q-24 0-35 27z" fill="#edaa92"/><path d="M242 246h179" stroke="#fff" stroke-width="9" stroke-linecap="round"/>',
	'writing' => '<g transform="rotate(-27 320 210)"><rect x="274" y="105" width="73" height="216" rx="25" fill="#167b69"/><rect x="274" y="105" width="73" height="40" rx="20" fill="#f4f5ef"/><path d="M274 273h73l-36 59z" fill="#d8ad71"/><path d="M300 313h21l-10 19z" fill="#53645c"/><path d="M291 177h38" stroke="#e9c86e" stroke-width="8" stroke-linecap="round"/></g>',
	'stationery' => '<rect x="202" y="252" width="236" height="35" rx="14" fill="#d5aa67"/><g transform="rotate(10 270 200)"><rect x="230" y="103" width="36" height="158" rx="15" fill="#e78270"/><path d="m230 261 18 38 18-38z" fill="#d0a574"/></g><g transform="rotate(-12 355 195)"><rect x="344" y="94" width="40" height="168" rx="18" fill="#438b78"/><rect x="344" y="94" width="40" height="25" rx="12" fill="#f4f7f4"/></g>'
);

$escapeXml = static function ($value) {
	return htmlspecialchars((string) $value, ENT_QUOTES | ENT_XML1, 'UTF-8');
};
$title = $brand !== '' ? $name . ' - ' . $brand : $name;
$safeTitle = $escapeXml($title);
$safeName = $escapeXml($name);
$safeBrand = $escapeXml($brand);

header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: public, max-age=86400');
header('X-Content-Type-Options: nosniff');
?>
<svg xmlns="http://www.w3.org/2000/svg" width="640" height="420" viewBox="0 0 640 420" role="img" aria-labelledby="title description">
	<title id="title"><?php echo $safeTitle;?></title>
	<desc id="description">Ilustrasi kategori produk ATK, bukan foto produk asli.</desc>
	<defs>
		<linearGradient id="background" x1="0" y1="0" x2="1" y2="1">
			<stop offset="0" stop-color="#f4f8f5"/>
			<stop offset="1" stop-color="#e6f0eb"/>
		</linearGradient>
		<filter id="shadow" x="-30%" y="-30%" width="160%" height="170%">
			<feDropShadow dx="0" dy="10" stdDeviation="10" flood-color="#17483b" flood-opacity=".12"/>
		</filter>
	</defs>
	<rect width="640" height="420" fill="url(#background)"/>
	<circle cx="320" cy="202" r="137" fill="#fff" opacity=".68"/>
	<g filter="url(#shadow)"><?php echo $art[$type];?></g>
	<path d="M160 324h320" stroke="#c7d8cf" stroke-width="3" stroke-linecap="round"/>
	<text x="320" y="363" fill="#17483b" font-family="Arial, sans-serif" font-size="19" font-weight="700" text-anchor="middle"><?php echo $safeName;?></text>
	<?php if ($safeBrand !== '') { ?><text x="320" y="389" fill="#6c8177" font-family="Arial, sans-serif" font-size="14" text-anchor="middle"><?php echo $safeBrand;?></text><?php } ?>
</svg>
