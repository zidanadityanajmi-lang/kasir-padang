<?php 
require __DIR__ . '/../session.php';
start_secure_session();
require_once __DIR__ . '/../stock_movement.php';
$isAjaxRequest = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
$sendJsonResponse = static function ($ok, $message, $statusCode = 200) {
	http_response_code($statusCode);
	header('Content-Type: application/json; charset=utf-8');
	echo json_encode(array('ok' => $ok, 'message' => $message));
	exit;
};
	if (empty($_SESSION['admin']['id_member']) || !isset($_SESSION['admin']['level']) || !in_array($_SESSION['admin']['level'], array('admin', 'pembeli'), true)) {
		http_response_code(401);
	if ($isAjaxRequest) {
		$sendJsonResponse(false, 'Silakan login kembali.', 401);
	}
	exit('Silakan login kembali.');
}
	$role = $_SESSION['admin']['level'];
	if ($role !== 'admin' && (isset($_GET['kategori']) || isset($_GET['barang']))) {
		http_response_code(403);
	exit('Akses ditolak.');
}
	$mutatingActions = array('kategori', 'barang', 'nota', 'jual');
	foreach ($mutatingActions as $action) {
		if (isset($_GET[$action])) {
			if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
				http_response_code(405);
				exit('Metode permintaan tidak diizinkan.');
			}
			if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
				http_response_code(403);
				if ($isAjaxRequest) {
					$sendJsonResponse(false, 'Sesi formulir tidak valid. Muat ulang halaman.', 403);
				}
				exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
			}
		}
	}
	{
	require '../../config.php';
	require_once __DIR__ . '/../product_image.php';
	if(!empty($_GET['kategori'])){
		$nama = trim((string) ($_POST['kategori'] ?? ''));
		if ($nama === '' || strlen($nama) > 255) {
			header('Location: ../../index.php?page=kategori&error=validation');
			exit;
		}
		$duplicateCategory = $config->prepare('SELECT 1 FROM kategori WHERE nama_kategori = ? LIMIT 1');
		$duplicateCategory->execute(array($nama));
		if ($duplicateCategory->fetchColumn()) {
			header('Location: ../../index.php?page=kategori&error=duplicate');
			exit;
		}
		$tgl= date("j F Y, G:i");
		$data[] = $nama;
		$data[] = $tgl;
		$sql = 'INSERT INTO kategori (nama_kategori,tgl_input) VALUES(?,?)';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		header('Location: ../../index.php?page=kategori&success=created');
		exit;
	}
	if(!empty($_GET['barang']) && $_SERVER['REQUEST_METHOD'] === 'POST'){
		$id = trim((string) ($_POST['id'] ?? ''));
		$kategori = filter_var($_POST['kategori'] ?? null, FILTER_VALIDATE_INT);
		$nama = trim((string) ($_POST['nama'] ?? ''));
		$merk = trim((string) ($_POST['merk'] ?? ''));
		$deskripsi = trim((string) ($_POST['deskripsi'] ?? ''));
		$beli = filter_var($_POST['beli'] ?? null, FILTER_VALIDATE_INT);
		$jual = filter_var($_POST['jual'] ?? null, FILTER_VALIDATE_INT);
		$satuan = strtoupper(trim((string) ($_POST['satuan'] ?? '')));
		$stok = filter_var($_POST['stok'] ?? null, FILTER_VALIDATE_INT);
		$units = array('PCS', 'RIM', 'KOTAK', 'PAK', 'LUSIN', 'BATANG', 'BOTOL', 'SET', 'BOX', 'ROLL');

		if ($id === '' || strlen($id) > 255 || $kategori === false || $nama === '' || strlen($nama) > 255
			|| $merk === '' || strlen($merk) > 255 || strlen($deskripsi) > 4000
			|| $beli === false || $beli < 0 || $jual === false || $jual < 0
			|| $stok === false || $stok < 0 || !in_array($satuan, $units, true)) {
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}

		$categoryQuery = $config->prepare('SELECT id_kategori FROM kategori WHERE id_kategori = ?');
		$categoryQuery->execute(array($kategori));
		if (!$categoryQuery->fetchColumn()) {
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}

		$duplicateQuery = $config->prepare('SELECT 1 FROM barang WHERE id_barang = ? LIMIT 1');
		$duplicateQuery->execute(array($id));
		if ($duplicateQuery->fetchColumn()) {
			header('Location: ../../index.php?page=barang&error=duplicate');
			exit;
		}

		try {
			$imageName = save_product_image_upload('gambar');
		} catch (RuntimeException $exception) {
			header('Location: ../../index.php?page=barang&error=image');
			exit;
		}
		$sql = 'INSERT INTO barang (id_barang,id_kategori,nama_barang,merk,deskripsi,harga_beli,harga_jual,satuan_barang,stok,tgl_input,gambar) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
		$row = $config->prepare($sql);
		try {
			$config->beginTransaction();
			$row->execute(array($id, $kategori, $nama, $merk, $deskripsi !== '' ? $deskripsi : null, $beli, $jual, $satuan, $stok, date('j F Y, G:i'), $imageName));
			if ($stok > 0) {
				record_stock_movement($config, $id, 'masuk', $stok, 0, $stok, 'Stok awal produk', null, (int) $_SESSION['admin']['id_member']);
			}
			$config->commit();
		} catch (PDOException $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			if ($imageName !== null) {
				delete_product_image($imageName, $config);
			}
			if ($exception->getCode() === '23000') {
				header('Location: ../../index.php?page=barang&error=duplicate');
				exit;
			}
			throw $exception;
		} catch (Throwable $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			if ($imageName !== null) {
				delete_product_image($imageName, $config);
			}
			throw $exception;
		}
		header('Location: ../../index.php?page=barang&success=tambah-data');
		exit;
	}
	if(isset($_GET['nota']) && $_GET['nota'] === 'jual' && $_SERVER['REQUEST_METHOD'] === 'POST'){
		$memberId = (int) $_SESSION['admin']['id_member'];
		$paid = filter_var($_POST['bayar'] ?? null, FILTER_VALIDATE_INT);
		$cartRows = array();
		$items = array();
		$products = array();
		$total = 0;

		try {
			$config->beginTransaction();
			$memberLock = $config->prepare('SELECT id_member FROM member WHERE id_member = ? FOR UPDATE');
			$memberLock->execute(array($memberId));

			$cartQuery = $config->prepare('SELECT id_penjualan, id_barang, jumlah FROM penjualan WHERE id_member = ? ORDER BY id_barang, id_penjualan');
			$cartQuery->execute(array($memberId));
			$cartRows = $cartQuery->fetchAll(PDO::FETCH_ASSOC);
			if (!$cartRows) {
				$config->rollBack();
				header('Location: ../../index.php?page=jual&error=empty#keranjang');
				exit;
			}

			foreach ($cartRows as $cartRow) {
				$quantity = filter_var($cartRow['jumlah'], FILTER_VALIDATE_INT);
				if ($quantity === false || $quantity < 1) {
					throw new RuntimeException('Invalid cart quantity');
				}
				$productId = $cartRow['id_barang'];
				if (!isset($items[$productId])) {
					$items[$productId] = array('quantity' => 0, 'cart_ids' => array());
				}
				$items[$productId]['quantity'] += $quantity;
				$items[$productId]['cart_ids'][] = (int) $cartRow['id_penjualan'];
			}

			ksort($items);
			$productQuery = $config->prepare('SELECT id_barang, nama_barang, stok, harga_jual, harga_beli FROM barang WHERE id_barang = ? FOR UPDATE');
			foreach ($items as $productId => $item) {
				$productQuery->execute(array($productId));
				$product = $productQuery->fetch(PDO::FETCH_ASSOC);
				if (!$product) {
					throw new RuntimeException('Product not found');
				}
				if ((int) $item['quantity'] > (int) $product['stok']) {
					$config->rollBack();
					header('Location: ../../index.php?page=jual&error=stock&barang=' . rawurlencode($product['nama_barang']) . '#keranjang');
					exit;
				}
				$product['quantity'] = (int) $item['quantity'];
				$product['line_total'] = (int) $product['harga_jual'] * (int) $item['quantity'];
				$product['unit_cost'] = (int) $product['harga_beli'];
				$products[$productId] = $product;
				$total += $product['line_total'];
			}

			if ($paid === false || $paid < $total) {
				$config->rollBack();
				header('Location: ../../index.php?page=jual&error=payment#kasirnya');
				exit;
			}

			$receiptDate = date('j F Y, G:i');
			$period = date('m-Y');
			$transactionCode = date('YmdHis') . '-' . bin2hex(random_bytes(6));
			$insertNota = $config->prepare('INSERT INTO nota (kode_transaksi, id_barang, nama_barang_snapshot, id_member, jumlah, total, harga_modal, tanggal_input, periode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
			$updateStock = $config->prepare('UPDATE barang SET stok = ? WHERE id_barang = ? AND stok = ?');
			$receiptRows = array();
			$receiptNumber = null;
			require_once __DIR__ . '/../stock_movement.php';

			foreach ($products as $productId => $product) {
				$insertNota->execute(array($transactionCode, $productId, $product['nama_barang'], $memberId, $product['quantity'], $product['line_total'], $product['unit_cost'], $receiptDate, $period));
				if ($receiptNumber === null) {
					$receiptNumber = (int) $config->lastInsertId();
				}

				$newStock = (int) $product['stok'] - $product['quantity'];
				$updateStock->execute(array($newStock, $productId, $product['stok']));
				if ($updateStock->rowCount() !== 1) {
					throw new RuntimeException('Stock changed during checkout');
				}
				record_stock_movement(
					$config,
					$productId,
					'keluar',
					$product['quantity'],
					(int) $product['stok'],
					$newStock,
					'Penjualan kasir',
					$transactionCode,
					$memberId
				);

				$receiptRows[] = array(
					'nama_barang' => $product['nama_barang'],
					'jumlah' => $product['quantity'],
					'total' => $product['line_total']
				);
			}

			$deleteCart = $config->prepare('DELETE FROM penjualan WHERE id_member = ?');
			$deleteCart->execute(array($memberId));
			$config->commit();

			$_SESSION['last_receipt'] = array(
				'number' => $receiptNumber,
				'rows' => $receiptRows,
				'cashier' => $_SESSION['admin']['nm_member'],
				'total' => $total,
				'paid' => $paid,
				'change' => $paid - $total,
				'date' => $receiptDate
			);
			header('Location: ../../index.php?page=jual&success=paid#kasirnya');
			exit;
		} catch (Exception $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			error_log('POS checkout failed: ' . $exception->getMessage());
			header('Location: ../../index.php?page=jual&error=checkout#keranjang');
			exit;
		}
	}

	if(!empty($_GET['jual']) && $_SERVER['REQUEST_METHOD'] === 'POST'){
		$id = trim((string) ($_POST['id_barang'] ?? $_POST['id'] ?? ''));
		$memberId = (int) $_SESSION['admin']['id_member'];
		if ($id === '') {
			if ($isAjaxRequest) {
				$sendJsonResponse(false, 'Barang tidak ditemukan.', 400);
			}
			header('Location: ../../index.php?page=jual&error=notfound#hasil-pencarian');
			exit;
		}

		try {
			$config->beginTransaction();
			$memberLock = $config->prepare('SELECT id_member FROM member WHERE id_member = ? FOR UPDATE');
			$memberLock->execute(array($memberId));
			$productQuery = $config->prepare('SELECT id_barang, nama_barang, stok, harga_jual FROM barang WHERE id_barang = ? FOR UPDATE');
			$productQuery->execute(array($id));
			$product = $productQuery->fetch(PDO::FETCH_ASSOC);
			if (!$product) {
				$config->rollBack();
				if ($isAjaxRequest) {
					$sendJsonResponse(false, 'Barang tidak ditemukan atau sudah dihapus.', 404);
				}
				header('Location: ../../index.php?page=jual&error=notfound#hasil-pencarian');
				exit;
			}

			$cartQuery = $config->prepare('SELECT id_penjualan, jumlah FROM penjualan WHERE id_barang = ? AND id_member = ? ORDER BY id_penjualan FOR UPDATE');
			$cartQuery->execute(array($id, $memberId));
			$existingRows = $cartQuery->fetchAll(PDO::FETCH_ASSOC);
			$quantity = 1;
			foreach ($existingRows as $existingRow) {
				$quantity += max(0, (int) $existingRow['jumlah']);
			}
			if ($quantity > (int) $product['stok']) {
				$config->rollBack();
				if ($isAjaxRequest) {
					$sendJsonResponse(false, 'Stok ' . $product['nama_barang'] . ' tidak mencukupi.', 409);
				}
				header('Location: ../../index.php?page=jual&error=stock&barang=' . rawurlencode($product['nama_barang']) . '#hasil-pencarian');
				exit;
			}

			$lineTotal = (int) $product['harga_jual'] * $quantity;
			if ($existingRows) {
				$updateCart = $config->prepare('UPDATE penjualan SET jumlah = ?, total = ? WHERE id_penjualan = ? AND id_member = ?');
				$updateCart->execute(array($quantity, $lineTotal, $existingRows[0]['id_penjualan'], $memberId));
				if (count($existingRows) > 1) {
					$duplicateIds = array_map('intval', array_column(array_slice($existingRows, 1), 'id_penjualan'));
					$placeholders = implode(',', array_fill(0, count($duplicateIds), '?'));
					$deleteDuplicates = $config->prepare('DELETE FROM penjualan WHERE id_member = ? AND id_penjualan IN (' . $placeholders . ')');
					$deleteDuplicates->execute(array_merge(array($memberId), $duplicateIds));
				}
			}else{
				$insertCart = $config->prepare('INSERT INTO penjualan (id_barang, id_member, jumlah, total, tanggal_input) VALUES (?, ?, ?, ?, ?)');
				$insertCart->execute(array($id, $memberId, $quantity, $lineTotal, date('j F Y, G:i')));
			}
			$config->commit();
			if ($isAjaxRequest) {
				$sendJsonResponse(true, $product['nama_barang'] . ' ditambahkan ke keranjang.');
			}
			header('Location: ../../index.php?page=jual&success=added#keranjang');
			exit;
		} catch (Exception $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			error_log('POS cart add failed: ' . $exception->getMessage());
			if ($isAjaxRequest) {
				$sendJsonResponse(false, 'Barang gagal ditambahkan. Silakan coba kembali.', 500);
			}
			header('Location: ../../index.php?page=jual&error=checkout#keranjang');
			exit;
		}
	}
}