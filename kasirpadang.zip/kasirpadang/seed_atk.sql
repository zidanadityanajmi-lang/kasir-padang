-- Jalankan pada database db_toko setelah migrasi 2026_11_12_add_nota_transaction_snapshots.sql diterapkan.
-- Harga merupakan estimasi awal; sesuaikan dengan harga pemasok setempat.
START TRANSACTION;

INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT 'Alat Tulis (Pulpen, Pensil, Spidol)', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
WHERE NOT EXISTS (SELECT 1 FROM `kategori` WHERE `nama_kategori` = 'Alat Tulis (Pulpen, Pensil, Spidol)');
INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT 'Buku & Kertas (HVS, Buku Tulis, Nota)', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
WHERE NOT EXISTS (SELECT 1 FROM `kategori` WHERE `nama_kategori` = 'Buku & Kertas (HVS, Buku Tulis, Nota)');
INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT 'Peralatan Arsip & Filing (Map, Odner, Klip)', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
WHERE NOT EXISTS (SELECT 1 FROM `kategori` WHERE `nama_kategori` = 'Peralatan Arsip & Filing (Map, Odner, Klip)');
INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT 'Peralatan Meja & Perekat (Staples, Lem, Lakban)', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
WHERE NOT EXISTS (SELECT 1 FROM `kategori` WHERE `nama_kategori` = 'Peralatan Meja & Perekat (Staples, Lem, Lakban)');
INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT 'Perlengkapan Menggambar & Presentasi', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
WHERE NOT EXISTS (SELECT 1 FROM `kategori` WHERE `nama_kategori` = 'Perlengkapan Menggambar & Presentasi');

SET @cat_writing := (SELECT `id_kategori` FROM `kategori` WHERE `nama_kategori` = 'Alat Tulis (Pulpen, Pensil, Spidol)' ORDER BY `id_kategori` LIMIT 1);
SET @cat_paper := (SELECT `id_kategori` FROM `kategori` WHERE `nama_kategori` = 'Buku & Kertas (HVS, Buku Tulis, Nota)' ORDER BY `id_kategori` LIMIT 1);
SET @cat_filing := (SELECT `id_kategori` FROM `kategori` WHERE `nama_kategori` = 'Peralatan Arsip & Filing (Map, Odner, Klip)' ORDER BY `id_kategori` LIMIT 1);
SET @cat_desk := (SELECT `id_kategori` FROM `kategori` WHERE `nama_kategori` = 'Peralatan Meja & Perekat (Staples, Lem, Lakban)' ORDER BY `id_kategori` LIMIT 1);
SET @cat_art := (SELECT `id_kategori` FROM `kategori` WHERE `nama_kategori` = 'Perlengkapan Menggambar & Presentasi' ORDER BY `id_kategori` LIMIT 1);

-- Arahkan kategori ATK terdahulu ke kategori baru yang paling sesuai.
UPDATE `barang` product
JOIN `kategori` old_category ON old_category.`id_kategori` = product.`id_kategori`
SET product.`id_kategori` = CASE
  WHEN LOWER(old_category.`nama_kategori`) IN ('atk', 'alat tulis', 'alat tulis & menulis') THEN @cat_writing
  WHEN LOWER(old_category.`nama_kategori`) IN ('buku & kertas', 'kertas & buku') THEN @cat_paper
  WHEN LOWER(old_category.`nama_kategori`) IN ('peralatan arsip & filing', 'arsip & filing') THEN @cat_filing
  WHEN LOWER(old_category.`nama_kategori`) IN ('peralatan meja & kantor', 'peralatan meja & perekat') THEN @cat_desk
  WHEN LOWER(old_category.`nama_kategori`) IN ('peralatan menggambar & seni', 'menggambar & presentasi') THEN @cat_art
  ELSE product.`id_kategori`
END
WHERE LOWER(old_category.`nama_kategori`) IN (
  'atk', 'alat tulis', 'alat tulis & menulis', 'buku & kertas', 'kertas & buku',
  'peralatan arsip & filing', 'arsip & filing', 'peralatan meja & kantor',
  'peralatan meja & perekat', 'peralatan menggambar & seni', 'menggambar & presentasi'
);

-- Arsipkan nama dan modal historis sebelum menghapus produk/kategori non-ATK yang tersisa.
UPDATE `nota` receipt
JOIN `barang` product ON product.`id_barang` = receipt.`id_barang`
SET receipt.`nama_barang_snapshot` = COALESCE(NULLIF(receipt.`nama_barang_snapshot`, ''), product.`nama_barang`),
    receipt.`harga_modal` = CASE
      WHEN receipt.`harga_modal` IS NULL OR receipt.`harga_modal` = '' THEN product.`harga_beli`
      ELSE receipt.`harga_modal`
    END
WHERE product.`id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_filing, @cat_desk, @cat_art);

DELETE cart
FROM `penjualan` cart
JOIN `barang` product ON product.`id_barang` = cart.`id_barang`
WHERE product.`id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_filing, @cat_desk, @cat_art);

DELETE FROM `barang`
WHERE `id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_filing, @cat_desk, @cat_art);

DELETE old_category
FROM `kategori` old_category
LEFT JOIN `barang` product ON product.`id_kategori` = old_category.`id_kategori`
WHERE product.`id_barang` IS NULL
  AND old_category.`id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_filing, @cat_desk, @cat_art);

INSERT INTO `barang`
  (`id_barang`, `id_kategori`, `nama_barang`, `merk`, `harga_beli`, `harga_jual`, `satuan_barang`, `stok`, `tgl_input`)
VALUES
  ('ATK0001', @cat_writing, 'Pulpen Standard AE7 Hitam', 'Standard', '2000', '3000', 'PCS', '100', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0002', @cat_writing, 'Pulpen Pilot G2 0.5mm', 'Pilot', '9000', '12000', 'PCS', '24', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0003', @cat_writing, 'Pensil Faber-Castell 2B', 'Faber-Castell', '2200', '3000', 'PCS', '80', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0004', @cat_writing, 'Spidol Whiteboard Snowman Hitam', 'Snowman', '4500', '6000', 'PCS', '36', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0005', @cat_writing, 'Highlighter Stabilo Boss Kuning', 'Stabilo', '8500', '11000', 'PCS', '20', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0006', @cat_writing, 'Tipe-X Kertas Joyko Correction Tape', 'Joyko', '4000', '5500', 'PCS', '30', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0007', @cat_paper, 'Kertas HVS PaperOne A4 70gr', 'PaperOne', '50000', '58000', 'RIM', '18', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0008', @cat_paper, 'Kertas HVS Sidu F4 70gr', 'Sidu', '45000', '53000', 'RIM', '16', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0009', @cat_paper, 'Buku Tulis Sinar Dunia 58 Lembar', 'Sinar Dunia', '36000', '42000', 'PAK', '20', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0010', @cat_paper, 'Buku Kas Folio Hardcover 100 Lembar', 'Kiky', '29000', '36000', 'PCS', '12', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0011', @cat_paper, 'Sticky Notes Post-it 3M Kuning', '3M Post-it', '14000', '18000', 'PAK', '20', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0012', @cat_paper, 'Amplop Putih Polos Paperline No. 90', 'Paperline', '20000', '27000', 'BOX', '10', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0013', @cat_filing, 'Map Odner Bantex Folio Hitam', 'Bantex', '22000', '28000', 'PCS', '12', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0014', @cat_filing, 'Map Plastik Kancing Joyko', 'Joyko', '2000', '3000', 'PCS', '45', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0015', @cat_filing, 'Binder Clip Joyko No. 107', 'Joyko', '4000', '6000', 'BOX', '18', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0016', @cat_filing, 'Paper Clip Kenko No. 3', 'Kenko', '3000', '5000', 'BOX', '16', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0017', @cat_filing, 'Clear Holder / Display Book Isi 40', 'Bantex', '25000', '32000', 'PCS', '10', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0018', @cat_desk, 'Stapler / Hekter Kenko HD-10', 'Kenko', '14000', '19000', 'PCS', '14', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0019', @cat_desk, 'Isi Staples Kenko No. 10', 'Kenko', '1500', '2500', 'BOX', '40', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0020', @cat_desk, 'Lakban Bening Daimaru 2 Inch', 'Daimaru', '8000', '11000', 'ROLL', '18', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0021', @cat_desk, 'Lem Kertas Glue Stick Kenko 25gr', 'Kenko', '4000', '6000', 'PCS', '24', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0022', @cat_art, 'Gunting Kertas Joyko Sedang', 'Joyko', '7000', '10000', 'PCS', '14', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')),
  ('ATK0023', @cat_art, 'Cutter Kenko L-500', 'Kenko', '7000', '10000', 'PCS', '12', DATE_FORMAT(NOW(), '%e %M %Y, %H:%i'))
ON DUPLICATE KEY UPDATE
  `id_kategori` = VALUES(`id_kategori`),
  `nama_barang` = VALUES(`nama_barang`),
  `merk` = VALUES(`merk`),
  `harga_beli` = VALUES(`harga_beli`),
  `harga_jual` = VALUES(`harga_jual`),
  `satuan_barang` = VALUES(`satuan_barang`);

UPDATE `toko` SET `nama_toko` = 'ATK Suka Suka' WHERE `id_toko` = 1;

COMMIT;
