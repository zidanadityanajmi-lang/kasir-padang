<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/customer_account.php';
$customerSession = customer_account_session();

function order_history_escape($value)
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$order = false;
$details = array();
$refund = false;
$refundHistory = array();
$returns = array();
$lookupSubmitted = $_SERVER['REQUEST_METHOD'] === 'POST';
$lookupError = '';
$orderCode = strtoupper(trim((string) ($_POST['kode_pesanan'] ?? $_GET['kode'] ?? '')));
$phone = trim((string) ($_POST['no_hp'] ?? ''));
if ($lookupSubmitted) {
	$phoneDigits = preg_replace('/\D+/', '', $phone);
	if (!preg_match('/^ORD[0-9]{14}[A-F0-9]{8}$/', $orderCode)
		|| strlen($phoneDigits) < 8
		|| strlen($phoneDigits) > 15) {
		$lookupError = 'Masukkan kode pesanan yang valid dan nomor WhatsApp yang digunakan saat checkout.';
	} else {
		$orderQuery = $config->prepare('SELECT * FROM pesanan WHERE kode_pesanan = ? LIMIT 1');
		$orderQuery->execute(array($orderCode));
		$candidate = $orderQuery->fetch(PDO::FETCH_ASSOC);
		if ($candidate && preg_replace('/\D+/', '', (string) $candidate['no_hp']) === $phoneDigits) {
			$order = $candidate;
			$detailQuery = $config->prepare(
				'SELECT nama_barang, merk, satuan_barang, jumlah, harga_jual, subtotal
					FROM detail_pesanan WHERE id_pesanan = ? ORDER BY nama_barang'
			);
			$detailQuery->execute(array((int) $order['id_pesanan']));
			$details = $detailQuery->fetchAll(PDO::FETCH_ASSOC);
			$refundQuery = $config->prepare(
				'SELECT id_pengembalian_dana, nominal, tanggal_refund, metode_refund, referensi_transaksi, status, catatan_admin
					FROM pengembalian_dana WHERE id_pesanan = ? LIMIT 1'
			);
			$refundQuery->execute(array((int) $order['id_pesanan']));
			$refund = $refundQuery->fetch(PDO::FETCH_ASSOC);
			if ($refund) {
				$refundHistoryQuery = $config->prepare(
					'SELECT status_sesudah, catatan, tanggal_input FROM riwayat_pengembalian_dana
						WHERE id_pengembalian_dana = ? ORDER BY tanggal_input'
				);
				$refundHistoryQuery->execute(array((int) $refund['id_pengembalian_dana']));
				$refundHistory = $refundHistoryQuery->fetchAll(PDO::FETCH_ASSOC);
			}
			$returnQuery = $config->prepare(
				'SELECT id_retur, status, alasan, bukti_foto, catatan_admin
					FROM retur_pesanan WHERE id_pesanan = ? ORDER BY tanggal_input DESC'
			);
			$returnQuery->execute(array((int) $order['id_pesanan']));
			$returns = $returnQuery->fetchAll(PDO::FETCH_ASSOC);
		} else {
			$lookupError = 'Pesanan tidak ditemukan. Periksa kembali kode pesanan dan nomor WhatsApp Anda.';
		}
	}
}

$storeQuery = $config->query('SELECT nama_toko FROM toko WHERE id_toko = 1 LIMIT 1');
$storeName = trim((string) $storeQuery->fetchColumn()) ?: 'ATK Suka Suka';
$statusLabels = array('pending' => 'Menunggu konfirmasi', 'processing' => 'Sedang diproses', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan');
$pickupLabels = array('store_pickup' => 'Ambil di toko', 'delivery' => 'Pengiriman');
$paymentLabels = array('pay_at_store' => 'Bayar di toko', 'bank_transfer' => 'Transfer bank');
$paymentStatusLabels = array('pending' => 'Menunggu konfirmasi pembayaran', 'paid' => 'Pembayaran terverifikasi', 'refund_pending' => 'Pengembalian dana sedang diproses', 'partially_refunded' => 'Pengembalian dana sebagian', 'refunded' => 'Dana telah dikembalikan');
$refundStatusLabels = array('waiting' => 'Menunggu', 'processing' => 'Diproses', 'success' => 'Berhasil', 'rejected' => 'Ditolak');
$shipmentStatusLabels = array('pending' => 'Menunggu diproses', 'shipped' => 'Dalam pengiriman', 'delivered' => 'Terkirim', 'received' => 'Diterima', 'not_applicable' => 'Ambil di toko');
$returnStatusLabels = array('pending' => 'Menunggu persetujuan', 'approved' => 'Disetujui · menunggu barang', 'received' => 'Barang diterima · menunggu pemeriksaan', 'inspected' => 'Barang diperiksa', 'rejected' => 'Ditolak', 'refunded' => 'Retur selesai');
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cek Pesanan | <?php echo order_history_escape($storeName);?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css?v=<?php echo (int) filemtime(__DIR__ . '/assets/css/storefront.css');?>" rel="stylesheet">
</head>
<body>
	<div class="shop-promo"><div class="shop-container shop-promo-inner"><span>Periksa status pesanan Anda dengan aman.</span><a href="katalog_pelanggan.php">Kembali ke katalog</a></div></div>
	<header class="shop-header"><div class="shop-container shop-header-inner">
		<a class="shop-brand" href="katalog_pelanggan.php"><span class="shop-brand-mark"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span><span><strong><?php echo order_history_escape($storeName);?></strong><small>Lengkap, Murah, dan Berkualitas</small></span></a>
		<nav class="shop-navigation" aria-label="Navigasi utama"><a href="katalog_pelanggan.php">Beranda</a><a href="katalog_pelanggan.php#tentang">Tentang Kami</a><a href="katalog_pelanggan.php#produk">Produk</a><a href="katalog_pelanggan.php#transaksi">Transaksi</a><a href="riwayat_pesanan.php" aria-current="page">Cek Pesanan</a><a href="katalog_pelanggan.php#kontak">Kontak</a><a class="customer-account-nav" href="<?php echo $customerSession ? 'profil_pelanggan.php' : 'masuk_pelanggan.php';?>"><?php echo $customerSession ? 'Profil' : 'Masuk';?></a><?php if (!$customerSession) { ?><a class="customer-account-nav" href="daftar_pelanggan.php">Daftar</a><?php } ?></nav>
	</div></header>
	<main class="shop-container order-history-page">
		<div class="section-heading"><div><span class="section-kicker">Informasi transaksi</span><h1>Cek Status Pesanan</h1><p>Masukkan kode pesanan dan nomor WhatsApp yang digunakan saat checkout.</p></div></div>
		<form class="order-lookup-form" method="POST" action="riwayat_pesanan.php">
			<label for="orderCode">Kode pesanan</label>
			<input id="orderCode" name="kode_pesanan" type="text" maxlength="40" value="<?php echo order_history_escape($orderCode);?>" placeholder="Contoh: ORD20261113123456A1B2C3D4" required autocomplete="off">
			<label for="orderPhone">Nomor HP / WhatsApp</label>
			<input id="orderPhone" name="no_hp" type="tel" maxlength="30" value="<?php echo order_history_escape($phone);?>" placeholder="Nomor saat checkout" required autocomplete="tel">
			<button class="store-button" type="submit"><i class="fa fa-search" aria-hidden="true"></i> Cari Pesanan</button>
		</form>
		<?php if ($lookupError !== '') { ?><div class="shop-notice shop-notice-danger" role="alert"><?php echo order_history_escape($lookupError);?></div><?php } ?>
		<?php if ($order) { ?>
			<section class="order-history-result">
				<div class="order-history-heading">
					<div><span class="section-kicker">Pesanan <?php echo order_history_escape($order['kode_pesanan']);?></span><h2><?php echo order_history_escape($order['nama_pelanggan']);?></h2><p><?php echo order_history_escape($order['tanggal_input']);?></p></div>
					<span class="online-order-status status-<?php echo order_history_escape($order['status']);?>"><?php echo order_history_escape($statusLabels[$order['status']] ?? $order['status']);?></span>
				</div>
				<div class="order-history-meta">
					<span><?php echo order_history_escape($pickupLabels[$order['metode_pengambilan']] ?? '—');?></span>
					<span><?php echo order_history_escape($paymentLabels[$order['metode_pembayaran']] ?? '—');?></span>
					<span><?php echo order_history_escape($paymentStatusLabels[$order['status_pembayaran'] ?? 'pending'] ?? 'Menunggu konfirmasi pembayaran');?></span>
					<?php if ($order['metode_pengambilan'] === 'delivery') { ?><span>Pengiriman: <?php echo order_history_escape($shipmentStatusLabels[$order['status_pengiriman']] ?? $order['status_pengiriman']);?><?php if (!empty($order['nomor_resi'])) { ?> · Resi <?php echo order_history_escape($order['nomor_resi']);?><?php } ?></span><?php } ?>
				</div>
				<div class="table-responsive"><table class="order-history-table">
					<thead><tr><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th></tr></thead>
					<tbody><?php foreach ($details as $detail) { ?>
						<tr><td><strong><?php echo order_history_escape($detail['nama_barang']);?></strong><small><?php echo order_history_escape($detail['merk']);?></small></td><td>Rp <?php echo number_format((int) $detail['harga_jual'], 0, ',', '.');?> / <?php echo order_history_escape($detail['satuan_barang']);?></td><td><?php echo number_format((int) $detail['jumlah']);?></td><td>Rp <?php echo number_format((int) $detail['subtotal'], 0, ',', '.');?></td></tr>
					<?php } ?></tbody>
				</table></div>
				<?php if (!empty($order['catatan_pesanan'])) { ?><p class="order-history-note"><strong>Catatan:</strong> <?php echo nl2br(order_history_escape($order['catatan_pesanan']));?></p><?php } ?>
				<?php if ((int) ($order['diskon_voucher'] ?? 0) > 0) { ?><p>Subtotal produk Rp <?php echo number_format((int) $order['subtotal_produk'], 0, ',', '.');?> · Voucher <?php echo order_history_escape($order['kode_voucher']);?> −Rp <?php echo number_format((int) $order['diskon_voucher'], 0, ',', '.');?></p><?php } ?>
				<div class="order-history-total"><span>Total pesanan</span><strong>Rp <?php echo number_format((int) $order['total'], 0, ',', '.');?></strong></div>
				<?php if ($refund) { ?><div class="customer-address-card"><strong>Status refund: <?php echo order_history_escape($refundStatusLabels[$refund['status']] ?? $refund['status']);?></strong><?php if ((int) $refund['nominal'] > 0) { ?><p>Rp <?php echo number_format((int) $refund['nominal'], 0, ',', '.');?> · <?php echo order_history_escape($refund['metode_refund']);?> · <?php echo order_history_escape($refund['tanggal_refund']);?><?php if (!empty($refund['referensi_transaksi'])) { ?> · Referensi <?php echo order_history_escape($refund['referensi_transaksi']);?><?php } ?></p><?php } ?><?php if (!empty($refund['catatan_admin'])) { ?><p><?php echo order_history_escape($refund['catatan_admin']);?></p><?php } ?><?php if ($refundHistory) { ?><details class="order-status-timeline"><summary>Riwayat status refund</summary><ol><?php foreach ($refundHistory as $history) { ?><li><strong><?php echo order_history_escape($refundStatusLabels[$history['status_sesudah']] ?? $history['status_sesudah']);?></strong> · <?php echo order_history_escape($history['tanggal_input']);?><?php if (!empty($history['catatan'])) { ?><br><span><?php echo order_history_escape($history['catatan']);?></span><?php } ?></li><?php } ?></ol></details><?php } ?></div><?php } ?>
				<?php foreach ($returns as $returnRow) { ?><div class="customer-address-card"><strong>Retur #<?php echo (int) $returnRow['id_retur'];?> · <?php echo order_history_escape($returnStatusLabels[$returnRow['status']] ?? $returnRow['status']);?></strong><p><?php echo order_history_escape($returnRow['alasan']);?> · <a href="bukti_retur.php?id=<?php echo (int) $returnRow['id_retur'];?>" target="_blank" rel="noopener">Lihat foto bukti</a></p><?php if (!empty($returnRow['catatan_admin'])) { ?><small>Catatan toko: <?php echo order_history_escape($returnRow['catatan_admin']);?></small><?php } ?></div><?php } ?>
			</section>
		<?php } ?>
	</main>
	<footer class="shop-footer"><div class="shop-container footer-bottom"><span>&copy; <?php echo date('Y');?> <?php echo order_history_escape($storeName);?></span><a href="katalog_pelanggan.php#kontak">Kontak toko</a></div></footer>
</body>
</html>
