<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/product_image.php';
require_once __DIR__ . '/fungsi/stock_movement.php';
require_once __DIR__ . '/fungsi/customer_account.php';
require_once __DIR__ . '/fungsi/customer_workflows.php';
require_once __DIR__ . '/fungsi/voucher.php';

function storefront_escape($value)
{
	return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function storefront_cart_count($cart)
{
	return array_sum(array_map('intval', $cart));
}

if (!isset($_SESSION['customer_cart']) || !is_array($_SESSION['customer_cart'])) {
	$_SESSION['customer_cart'] = array();
}

$customerSession = customer_account_session();
$customerAddresses = array();
if ($customerSession) {
	$customerAccountQuery = $config->prepare(
		"SELECT id_pelanggan, nama_pelanggan, email, no_hp, alamat
			FROM pelanggan WHERE id_pelanggan = ? AND status = 'active' LIMIT 1"
	);
	$customerAccountQuery->execute(array((int) $customerSession['id_pelanggan']));
	$customerSession = $customerAccountQuery->fetch(PDO::FETCH_ASSOC) ?: null;
	if ($customerSession) {
		$_SESSION['customer'] = $customerSession;
	} else {
		unset($_SESSION['customer']);
	}
	if ($customerSession) {
		$addressQuery = $config->prepare(
			'SELECT id_alamat, label, nama_penerima, no_hp, alamat_lengkap
				FROM pelanggan_alamat WHERE id_pelanggan = ? ORDER BY is_default DESC, id_alamat DESC'
		);
		$addressQuery->execute(array((int) $customerSession['id_pelanggan']));
		$customerAddresses = $addressQuery->fetchAll(PDO::FETCH_ASSOC);
	}
}

$cart =& $_SESSION['customer_cart'];
$notice = '';
$noticeType = 'success';
$orderCode = '';
$orderError = '';
$createdOrder = $_SESSION['customer_order_created'] ?? null;
unset($_SESSION['customer_order_created']);
if (empty($_SESSION['customer_order_token'])) {
	$_SESSION['customer_order_token'] = bin2hex(random_bytes(32));
}
$orderSubmissionToken = $_SESSION['customer_order_token'];
$isAjax = isset($_GET['ajax'])
	&& $_GET['ajax'] === 'cart'
	&& strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
$isVoucherAjax = isset($_GET['ajax'])
	&& $_GET['ajax'] === 'voucher'
	&& strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
		http_response_code(403);
		$response = array('ok' => false, 'message' => 'Sesi formulir tidak valid. Muat ulang halaman.');
		if ($isAjax || $isVoucherAjax) {
			header('Content-Type: application/json; charset=utf-8');
			echo json_encode($response);
			exit;
		}
		$notice = $response['message'];
		$noticeType = 'danger';
		if (($_POST['action'] ?? '') === 'create_order') {
			$orderError = $response['message'];
		}
	} else {
		$action = (string) ($_POST['action'] ?? '');
		$productId = trim((string) ($_POST['product_id'] ?? ''));
		$quantity = filter_var($_POST['quantity'] ?? 1, FILTER_VALIDATE_INT);
		$message = '';
		$ok = true;

		if ($action === 'validate_voucher' && $isVoucherAjax) {
			header('Content-Type: application/json; charset=utf-8');
			header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
			try {
				if (!$cart) {
					throw new DomainException('Keranjang masih kosong.');
				}
				$subtotal = 0;
				$voucherProductQuery = $config->prepare(
					'SELECT harga_jual, stok FROM barang WHERE id_barang = ? LIMIT 1'
				);
				foreach ($cart as $cartId => $cartQuantity) {
					$cartQuantity = filter_var($cartQuantity, FILTER_VALIDATE_INT);
					if ($cartQuantity === false || $cartQuantity < 1 || $cartQuantity > 999) {
						throw new DomainException('Jumlah produk di keranjang tidak valid.');
					}
					$voucherProductQuery->execute(array((string) $cartId));
					$voucherProduct = $voucherProductQuery->fetch(PDO::FETCH_ASSOC);
					if (!$voucherProduct || (int) $voucherProduct['stok'] < $cartQuantity) {
						throw new DomainException('Stok produk berubah. Periksa kembali keranjang.');
					}
					$subtotal += (int) $voucherProduct['harga_jual'] * $cartQuantity;
				}
				$voucherPhone = $customerSession ? $customerSession['no_hp'] : trim((string) ($_POST['customer_phone'] ?? ''));
				$customerKey = voucher_customer_key($customerSession ? (int) $customerSession['id_pelanggan'] : 0, $voucherPhone);
				$quote = voucher_quote($config, $_POST['voucher_code'] ?? '', $subtotal, $customerKey);
				echo json_encode(array(
					'ok' => true,
					'message' => 'Voucher berlaku.',
					'subtotal' => $quote['subtotal'],
					'discount' => $quote['discount'],
					'total' => $quote['total']
				));
			} catch (DomainException $exception) {
				echo json_encode(array('ok' => false, 'message' => $exception->getMessage()));
			} catch (Throwable $exception) {
				error_log('Voucher validation preview failed: ' . $exception->getMessage());
				http_response_code(500);
				echo json_encode(array('ok' => false, 'message' => 'Voucher belum dapat divalidasi. Silakan coba kembali.'));
			}
			exit;
		} elseif ($action === 'create_order') {
			$submittedOrderToken = $_POST['order_submission_token'] ?? null;
			if (!is_string($submittedOrderToken) || !hash_equals($orderSubmissionToken, $submittedOrderToken)) {
				$ok = false;
				$message = 'Pesanan ini sudah dikirim atau formulir kedaluwarsa. Muat ulang halaman sebelum mencoba lagi.';
			}
			$customerName = trim((string) ($_POST['customer_name'] ?? ''));
			$customerPhone = trim((string) ($_POST['customer_phone'] ?? ''));
			if ($customerSession) {
				$customerName = (string) $customerSession['nama_pelanggan'];
				$customerPhone = (string) $customerSession['no_hp'];
			}
			$deliveryAddress = trim((string) ($_POST['delivery_address'] ?? ''));
			$deliveryAddressId = filter_var($_POST['delivery_address_id'] ?? 0, FILTER_VALIDATE_INT);
			$deliveryAddressId = $deliveryAddressId === false ? -1 : (int) $deliveryAddressId;
			$orderNote = trim((string) ($_POST['order_note'] ?? ''));
			$pickupMethod = (string) ($_POST['pickup_method'] ?? '');
			$paymentMethod = (string) ($_POST['payment_method'] ?? '');
			$voucherCode = strtoupper(trim((string) ($_POST['voucher_code'] ?? '')));
			$phoneDigits = preg_replace('/\D+/', '', $customerPhone);
			$validPickupMethods = array('store_pickup', 'delivery');
			$validPaymentMethods = array('pay_at_store', 'bank_transfer');

			if ($ok && ($customerName === '' || strlen($customerName) > 120 || strlen($customerPhone) > 30
				|| strlen($deliveryAddress) > 1000
				|| strlen($orderNote) > 1000
				|| strlen($phoneDigits) < 8 || strlen($phoneDigits) > 15
				|| !in_array($pickupMethod, $validPickupMethods, true)
				|| !in_array($paymentMethod, $validPaymentMethods, true)
				|| ($pickupMethod === 'delivery'
					&& ((!$customerSession || $deliveryAddressId < 1) && $deliveryAddress === '')))) {
				$ok = false;
				$message = 'Lengkapi nama, nomor WhatsApp yang valid, metode pengambilan dan pembayaran, serta alamat untuk pengiriman.';
			} elseif ($ok && !$cart) {
				$ok = false;
				$message = 'Keranjang masih kosong.';
			} elseif ($ok) {
				$orderItems = array();
				$orderTotal = 0;
				$transactionStarted = false;
				try {
					$config->beginTransaction();
					$transactionStarted = true;
					if ($pickupMethod === 'delivery' && $customerSession && $deliveryAddressId > 0) {
						$selectedAddressQuery = $config->prepare(
							'SELECT id_alamat, nama_penerima, no_hp, alamat_lengkap
								FROM pelanggan_alamat WHERE id_alamat = ? AND id_pelanggan = ? FOR UPDATE'
						);
						$selectedAddressQuery->execute(array($deliveryAddressId, (int) $customerSession['id_pelanggan']));
						$selectedAddress = $selectedAddressQuery->fetch(PDO::FETCH_ASSOC);
						if (!$selectedAddress) {
							throw new DomainException('Alamat pengiriman tidak ditemukan. Pilih alamat yang tersimpan atau masukkan alamat baru.');
						}
						$deliveryAddress = (string) $selectedAddress['alamat_lengkap'];
						$customerName = (string) $selectedAddress['nama_penerima'];
						$customerPhone = (string) $selectedAddress['no_hp'];
					} else {
						$deliveryAddressId = 0;
					}
					$cartIds = array_keys($cart);
					sort($cartIds, SORT_STRING);
					$productLock = $config->prepare(
						'SELECT id_barang, nama_barang, merk, harga_beli, harga_jual, satuan_barang, stok
							FROM barang WHERE id_barang = ? FOR UPDATE'
					);

					foreach ($cartIds as $cartId) {
						$requestedQuantity = filter_var($cart[$cartId] ?? null, FILTER_VALIDATE_INT);
						if ($requestedQuantity === false || $requestedQuantity < 1 || $requestedQuantity > 999) {
							throw new DomainException('Jumlah salah satu produk tidak valid.');
						}
						$productLock->execute(array($cartId));
						$product = $productLock->fetch(PDO::FETCH_ASSOC);
						if (!$product || (int) $product['stok'] < $requestedQuantity) {
							throw new DomainException('Stok salah satu produk berubah. Periksa kembali keranjang Anda.');
						}
						$product['quantity'] = $requestedQuantity;
						$product['unit_price'] = (int) $product['harga_jual'];
						$product['unit_cost'] = (int) $product['harga_beli'];
						$product['subtotal'] = $product['unit_price'] * $requestedQuantity;
						$product['stock_before'] = (int) $product['stok'];
						$orderTotal += $product['subtotal'];
						$orderItems[] = $product;
					}

					$voucherQuote = null;
					$orderDiscount = 0;
					$voucherCustomerKey = '';
					if ($voucherCode !== '') {
						$voucherCustomerKey = voucher_customer_key(
							$customerSession ? (int) $customerSession['id_pelanggan'] : 0,
							$customerPhone
						);
						$voucherQuote = voucher_quote($config, $voucherCode, $orderTotal, $voucherCustomerKey, true);
						$orderDiscount = (int) $voucherQuote['discount'];
						if ($orderDiscount < 1) {
							throw new DomainException('Voucher tidak menghasilkan potongan untuk subtotal ini.');
						}
					}
					$payableTotal = $orderTotal - $orderDiscount;
					$paymentStatus = $payableTotal === 0 ? 'paid' : 'pending';
					$paymentDate = $payableTotal === 0 ? date('Y-m-d H:i:s') : null;
					$orderCode = 'ORD' . date('YmdHis') . strtoupper(bin2hex(random_bytes(4)));
					$insertOrder = $config->prepare(
						'INSERT INTO pesanan
							(id_pelanggan, id_alamat, id_voucher, kode_voucher, kode_pesanan, nama_pelanggan, no_hp,
								metode_pengambilan, alamat_pengiriman, catatan_pesanan, metode_pembayaran, total,
								subtotal_produk, diskon_voucher, status, status_pengiriman, status_pembayaran, tanggal_pembayaran, tanggal_input)
							VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
					);
					$insertOrder->execute(array(
						$customerSession ? (int) $customerSession['id_pelanggan'] : null,
						$deliveryAddressId > 0 ? $deliveryAddressId : null,
						$voucherQuote ? (int) $voucherQuote['voucher']['id_voucher'] : null,
						$voucherQuote ? $voucherQuote['code'] : null,
						$orderCode,
						$customerName,
						$customerPhone,
						$pickupMethod,
						$deliveryAddress !== '' ? $deliveryAddress : null,
						$orderNote !== '' ? $orderNote : null,
						$paymentMethod,
						$payableTotal,
						$orderTotal,
						$orderDiscount,
						'pending',
						$pickupMethod === 'delivery' ? 'pending' : 'not_applicable',
						$paymentStatus,
						$paymentDate,
						date('Y-m-d H:i:s')
					));
					$orderId = (int) $config->lastInsertId();
					if ($voucherQuote) {
						$insertVoucherUse = $config->prepare(
							'INSERT INTO voucher_pemakaian
								(id_voucher, id_pesanan, id_pelanggan, customer_key, kode_voucher, subtotal_produk, diskon, tanggal_input)
								VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
						);
						$insertVoucherUse->execute(array(
							(int) $voucherQuote['voucher']['id_voucher'],
							$orderId,
							$customerSession ? (int) $customerSession['id_pelanggan'] : null,
							$voucherCustomerKey,
							$voucherQuote['code'],
							$orderTotal,
							$orderDiscount,
							date('Y-m-d H:i:s')
						));
					}
					customer_workflow_record_status($config, $orderId, null, 'pending', 'Pesanan dibuat pelanggan', null, $customerSession ? (int) $customerSession['id_pelanggan'] : null);
					$insertDetail = $config->prepare(
						'INSERT INTO detail_pesanan
							(id_pesanan, id_barang, nama_barang, merk, satuan_barang, jumlah, harga_jual, harga_modal, subtotal)
							VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
					);
					$updateStock = $config->prepare(
						'UPDATE barang SET stok = ? WHERE id_barang = ? AND CAST(stok AS UNSIGNED) = ?'
					);
					foreach ($orderItems as $item) {
						$insertDetail->execute(array(
							$orderId,
							$item['id_barang'],
							$item['nama_barang'],
							$item['merk'],
							$item['satuan_barang'],
							$item['quantity'],
							$item['unit_price'],
							$item['unit_cost'],
							$item['subtotal']
						));
						$updateStock->execute(array(
							$item['stock_before'] - $item['quantity'],
							$item['id_barang'],
							$item['stock_before']
						));
						if ($updateStock->rowCount() !== 1) {
							throw new DomainException('Stok berubah saat pesanan dibuat. Silakan coba kembali.');
						}
						customer_workflow_notify(
							$config,
							$customerSession ? (int) $customerSession['id_pelanggan'] : null,
							$orderId,
							'Pesanan diterima',
							'Pesanan ' . $orderCode . ' berhasil dibuat dan menunggu konfirmasi toko.'
						);
						record_stock_movement(
							$config,
							$item['id_barang'],
							'keluar',
							$item['quantity'],
							$item['stock_before'],
							$item['stock_before'] - $item['quantity'],
							'Stok dicadangkan untuk pesanan pelanggan',
							$orderCode,
							null
						);
					}
					$config->commit();
					$transactionStarted = false;
					$_SESSION['customer_cart'] = array();
					unset($_SESSION['customer_order_token']);
					$_SESSION['customer_order_created'] = array(
						'code' => $orderCode,
						'total' => $payableTotal,
						'subtotal' => $orderTotal,
						'discount' => $orderDiscount,
						'voucher' => $voucherCode
					);
					header('Location: katalog_pelanggan.php?order=created');
					exit;
				} catch (DomainException $exception) {
					if ($transactionStarted && $config->inTransaction()) {
						$config->rollBack();
					}
					$ok = false;
					$message = $exception->getMessage();
				} catch (Throwable $exception) {
					if ($transactionStarted && $config->inTransaction()) {
						$config->rollBack();
					}
					error_log('Customer order creation failed: ' . $exception->getMessage());
					$ok = false;
					$message = 'Pesanan belum dapat dibuat. Silakan coba kembali beberapa saat lagi.';
				}
			}
		} elseif ($action === 'add' || $action === 'update') {
			$delta = filter_var($_POST['delta'] ?? null, FILTER_VALIDATE_INT);
			$hasDelta = $action === 'update' && $delta !== false && in_array($delta, array(-1, 1), true);
			$invalidDelta = $action === 'update' && array_key_exists('delta', $_POST) && !$hasDelta;
			if ($productId === '' || $invalidDelta || (!$hasDelta && ($quantity === false || $quantity < 1 || $quantity > 999))) {
				$ok = false;
				$message = 'Jumlah produk tidak valid.';
			} else {
				$productQuery = $config->prepare('SELECT nama_barang, stok FROM barang WHERE id_barang = ? LIMIT 1');
				$productQuery->execute(array($productId));
				$product = $productQuery->fetch(PDO::FETCH_ASSOC);
				if (!$product) {
					$ok = false;
					$message = 'Produk tidak ditemukan.';
				} else {
					$currentQuantity = (int) ($cart[$productId] ?? 0);
					$requestedQuantity = $hasDelta
						? $currentQuantity + $delta
						: ($action === 'add' ? $currentQuantity + $quantity : $quantity);
					if ($requestedQuantity < 1) {
						$ok = false;
						$message = 'Jumlah produk minimal 1.';
					} elseif ($requestedQuantity > 999) {
						$ok = false;
						$message = 'Jumlah produk maksimal 999.';
					} elseif ((int) $product['stok'] < $requestedQuantity) {
						$ok = false;
						$message = 'Stok ' . $product['nama_barang'] . ' tidak mencukupi. Sisa stok ' . (int) $product['stok'] . '.';
					} else {
						$cart[$productId] = $requestedQuantity;
						$message = $action === 'add'
							? $product['nama_barang'] . ' ditambahkan ke keranjang.'
							: 'Jumlah ' . $product['nama_barang'] . ' diperbarui.';
					}
				}
			}
		} elseif ($action === 'remove') {
			unset($cart[$productId]);
			$message = 'Produk dihapus dari keranjang.';
		} elseif ($action === 'clear') {
			$cart = array();
			$message = 'Keranjang dikosongkan.';
		} else {
			$ok = false;
			$message = 'Aksi keranjang tidak dikenali.';
		}

		if ($isAjax) {
			$cartItems = array();
			$cartSubtotal = 0;
			if ($cart) {
				$cartIds = array_keys($cart);
				$placeholders = implode(',', array_fill(0, count($cartIds), '?'));
				$cartProductQuery = $config->prepare(
					'SELECT id_barang, harga_jual, stok FROM barang WHERE id_barang IN (' . $placeholders . ')'
				);
				$cartProductQuery->execute($cartIds);
				$cartProductRows = array();
				foreach ($cartProductQuery->fetchAll(PDO::FETCH_ASSOC) as $cartProduct) {
					$cartProductRows[$cartProduct['id_barang']] = $cartProduct;
				}
				foreach ($cart as $cartId => $cartQuantity) {
					if (!isset($cartProductRows[$cartId])) {
						continue;
					}
					$cartItemSubtotal = (int) $cartProductRows[$cartId]['harga_jual'] * (int) $cartQuantity;
					$cartSubtotal += $cartItemSubtotal;
					$cartItems[] = array(
						'product_id' => (string) $cartId,
						'quantity' => (int) $cartQuantity,
						'stock' => (int) $cartProductRows[$cartId]['stok'],
						'max_quantity' => min(999, (int) $cartProductRows[$cartId]['stok']),
						'subtotal' => $cartItemSubtotal
					);
				}
			}
			header('Content-Type: application/json; charset=utf-8');
			echo json_encode(array(
				'ok' => $ok,
				'message' => $message,
				'count' => storefront_cart_count($cart),
				'total' => $cartSubtotal,
				'items' => $cartItems
			));
			exit;
		}
		if ($ok && $action === 'add' && isset($_POST['return_to']) && is_string($_POST['return_to'])
			&& preg_match('/^produk\\.php\\?id=[A-Za-z0-9_-]{1,255}$/', $_POST['return_to'])) {
			header('Location: ' . $_POST['return_to'] . '&added=1');
			exit;
		}
		$notice = $message;
		$noticeType = $ok ? 'success' : 'danger';
		$orderError = $action === 'create_order' && !$ok ? $message : '';
	}
}

$storeBankAccount = trim((string) (getenv('STORE_BANK_ACCOUNT') ?: ''));
$storeQuery = $config->query('SELECT nama_toko, alamat_toko, tlp FROM toko WHERE id_toko = 1 LIMIT 1');
$store = $storeQuery->fetch(PDO::FETCH_ASSOC);
$storeName = trim((string) ($store['nama_toko'] ?? 'ATK Suka Suka'));
if ($storeName === '') {
	$storeName = 'ATK Suka Suka';
}

$categoriesQuery = $config->query("SELECT id_kategori, nama_kategori FROM kategori
	ORDER BY FIELD(nama_kategori,
		'Alat Tulis (Pen, Pensil, Spidol)',
		'Buku & Kertas (HVS, Buku Tulis)',
		'Peralatan Kantor & Arsip',
		'Perekat & Alat Pemotong',
		'Perlengkapan Sekolah & Menggambar',
		'Aksesoris Meja & Lainnya'
	), nama_kategori");
$categories = $categoriesQuery->fetchAll(PDO::FETCH_ASSOC);
$brandsQuery = $config->query("SELECT DISTINCT merk FROM barang WHERE TRIM(merk) <> '' ORDER BY merk");
$brands = $brandsQuery->fetchAll(PDO::FETCH_COLUMN);
$requestedCategory = filter_var($_GET['kategori'] ?? null, FILTER_VALIDATE_INT);
$categoryIds = array_map('intval', array_column($categories, 'id_kategori'));
$selectedCategory = $requestedCategory !== false && $requestedCategory !== null
	&& in_array((int) $requestedCategory, $categoryIds, true)
	? (int) $requestedCategory
	: null;
$requestedBrand = trim((string) ($_GET['merk'] ?? ''));
$selectedBrand = in_array($requestedBrand, $brands, true) ? $requestedBrand : '';
$filterError = $requestedBrand !== '' && $selectedBrand === '' ? 'Merek yang dipilih tidak tersedia.' : '';
$minimumPriceInput = trim((string) ($_GET['harga_min'] ?? ''));
$maximumPriceInput = trim((string) ($_GET['harga_max'] ?? ''));
$minimumPrice = $minimumPriceInput !== '' && preg_match('/^\d{1,12}$/', $minimumPriceInput) ? (int) $minimumPriceInput : null;
$maximumPrice = $maximumPriceInput !== '' && preg_match('/^\d{1,12}$/', $maximumPriceInput) ? (int) $maximumPriceInput : null;
if (($minimumPriceInput !== '' && $minimumPrice === null) || ($maximumPriceInput !== '' && $maximumPrice === null)) {
	if ($filterError === '') {
		$filterError = 'Batas harga harus berupa angka yang valid.';
	}
	$minimumPrice = $minimumPriceInput !== '' && $minimumPrice === null ? null : $minimumPrice;
	$maximumPrice = $maximumPriceInput !== '' && $maximumPrice === null ? null : $maximumPrice;
}
if ($minimumPrice !== null && $maximumPrice !== null && $minimumPrice > $maximumPrice) {
	if ($filterError === '') {
		$filterError = 'Harga minimum tidak boleh lebih besar daripada harga maksimum.';
	}
	$minimumPrice = null;
	$maximumPrice = null;
}
$search = trim((string) ($_GET['q'] ?? ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 100, 'UTF-8') : substr($search, 0, 100);
$sort = (string) ($_GET['sort'] ?? 'name');
if (!in_array($sort, array('name', 'price_asc', 'price_desc'), true)) {
	$sort = 'name';
}
$pageSize = 12;
$catalogPage = filter_var($_GET['halaman'] ?? 1, FILTER_VALIDATE_INT);
$catalogPage = $catalogPage === false ? 1 : max(1, $catalogPage);

$conditions = array();
$parameters = array();
if ($selectedCategory !== false && $selectedCategory !== null) {
	$conditions[] = 'barang.id_kategori = ?';
	$parameters[] = (int) $selectedCategory;
}
if ($search !== '') {
	$conditions[] = '(barang.nama_barang LIKE ? OR barang.merk LIKE ?)';
	$searchPattern = '%' . $search . '%';
	$parameters[] = $searchPattern;
	$parameters[] = $searchPattern;
}
if ($selectedBrand !== '') {
	$conditions[] = 'barang.merk = ?';
	$parameters[] = $selectedBrand;
}
if ($minimumPrice !== null) {
	$conditions[] = 'CAST(barang.harga_jual AS UNSIGNED) >= ?';
	$parameters[] = $minimumPrice;
}
if ($maximumPrice !== null) {
	$conditions[] = 'CAST(barang.harga_jual AS UNSIGNED) <= ?';
	$parameters[] = $maximumPrice;
}
$where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
$countQuery = $config->prepare(
	'SELECT COUNT(*) FROM barang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori ' . $where
);
$countQuery->execute($parameters);
$catalogTotal = (int) $countQuery->fetchColumn();
$catalogPages = max(1, (int) ceil($catalogTotal / $pageSize));
$catalogPage = min($catalogPage, $catalogPages);
$sortSql = array(
	'name' => 'barang.nama_barang ASC, barang.id_barang ASC',
	'price_asc' => 'CAST(barang.harga_jual AS UNSIGNED) ASC, barang.nama_barang ASC',
	'price_desc' => 'CAST(barang.harga_jual AS UNSIGNED) DESC, barang.nama_barang ASC'
);
$productImageColumn = $config->query("SHOW COLUMNS FROM barang LIKE 'gambar'")->fetch(PDO::FETCH_ASSOC);
$productImageSelect = $productImageColumn ? 'barang.gambar' : 'NULL AS gambar';
$productsQuery = $config->prepare(
	'SELECT barang.id_barang, barang.nama_barang, barang.merk, ' . $productImageSelect . ', barang.harga_jual,
		barang.stok, barang.satuan_barang, kategori.nama_kategori
		FROM barang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori
		' . $where . ' ORDER BY ' . $sortSql[$sort] . ' LIMIT ? OFFSET ?'
);
$productParameterIndex = 1;
foreach ($parameters as $parameter) {
	$productsQuery->bindValue($productParameterIndex++, $parameter, PDO::PARAM_STR);
}
$productsQuery->bindValue($productParameterIndex++, $pageSize, PDO::PARAM_INT);
$productsQuery->bindValue($productParameterIndex, ($catalogPage - 1) * $pageSize, PDO::PARAM_INT);
$productsQuery->execute();
$products = $productsQuery->fetchAll(PDO::FETCH_ASSOC);

$cartProducts = array();
$cartTotal = 0;
$validCart = array();
if ($cart) {
	$cartIds = array_keys($cart);
	$placeholders = implode(',', array_fill(0, count($cartIds), '?'));
	$cartQuery = $config->prepare(
		'SELECT barang.id_barang, barang.nama_barang, barang.merk, barang.gambar, barang.harga_jual,
				barang.stok, barang.satuan_barang, kategori.nama_kategori
			FROM barang LEFT JOIN kategori ON kategori.id_kategori = barang.id_kategori
			WHERE barang.id_barang IN (' . $placeholders . ')'
	);
	$cartQuery->execute($cartIds);
	$productsById = array();
	foreach ($cartQuery->fetchAll(PDO::FETCH_ASSOC) as $product) {
		$productsById[$product['id_barang']] = $product;
	}
	foreach ($cart as $id => $cartQuantity) {
		if (!isset($productsById[$id]) || (int) $productsById[$id]['stok'] < (int) $cartQuantity) {
			continue;
		}
		$product = $productsById[$id];
		$product['quantity'] = (int) $cartQuantity;
		$product['subtotal'] = (int) $product['harga_jual'] * (int) $cartQuantity;
		$cartProducts[] = $product;
		$cartTotal += $product['subtotal'];
		$validCart[$id] = (int) $cartQuantity;
	}
	$cart = $validCart;
}
$catalogQueryParams = array();
if ($selectedCategory !== null) {
	$catalogQueryParams['kategori'] = $selectedCategory;
}
if ($search !== '') {
	$catalogQueryParams['q'] = $search;
}
if ($sort !== 'name') {
	$catalogQueryParams['sort'] = $sort;
}
if ($selectedBrand !== '') {
	$catalogQueryParams['merk'] = $selectedBrand;
}
if ($minimumPrice !== null) {
	$catalogQueryParams['harga_min'] = $minimumPrice;
}
if ($maximumPrice !== null) {
	$catalogQueryParams['harga_max'] = $maximumPrice;
}
$catalogPageUrl = static function ($targetPage) use ($catalogQueryParams) {
	$params = $catalogQueryParams;
	$params['halaman'] = (int) $targetPage;
	return 'katalog_pelanggan.php?' . http_build_query($params) . '#produk';
};

$phoneDigits = preg_replace('/\D+/', '', (string) ($store['tlp'] ?? ''));
if (substr($phoneDigits, 0, 1) === '0') {
	$phoneDigits = '62' . substr($phoneDigits, 1);
}
$whatsAppAvailable = strlen($phoneDigits) >= 8 && strlen($phoneDigits) <= 15;
$isAdminLoggedIn = !empty($_SESSION['admin']['id_member'])
	&& in_array($_SESSION['admin']['level'] ?? '', array('admin', 'pembeli'), true);
$loginLink = $isAdminLoggedIn ? 'index.php' : 'login.php';
$loginLinkLabel = $isAdminLoggedIn ? 'Dashboard Admin' : 'Masuk Admin / Kasir';
$cartCount = storefront_cart_count($cart);
$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Belanja alat tulis, buku, kertas dan perlengkapan kantor di <?php echo storefront_escape($storeName);?>">
	<title>Katalog ATK | <?php echo storefront_escape($storeName);?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css?v=<?php echo (int) filemtime(__DIR__ . '/assets/css/storefront.css');?>" rel="stylesheet">
</head>
<body>
	<div class="shop-promo">
		<div class="shop-container shop-promo-inner">
			<span><i class="fa fa-bullhorn" aria-hidden="true"></i> Belanja ATK lebih mudah, cepat, dan terpercaya!</span>
			<a href="<?php echo storefront_escape($loginLink);?>"><i class="fa <?php echo $isAdminLoggedIn ? 'fa-tachometer' : 'fa-user';?>" aria-hidden="true"></i> <?php echo storefront_escape($loginLinkLabel);?></a>
		</div>
	</div>
	<header class="shop-header">
		<div class="shop-container shop-header-inner">
			<a class="shop-brand" href="katalog_pelanggan.php" aria-label="Beranda <?php echo storefront_escape($storeName);?>">
				<span class="shop-brand-mark"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
				<span><strong><?php echo storefront_escape($storeName);?></strong><small>Lengkap, Murah, dan Berkualitas</small></span>
			</a>
			<nav class="shop-navigation" aria-label="Navigasi utama">
				<a class="is-current" href="katalog_pelanggan.php"><i class="fa fa-home" aria-hidden="true"></i> Beranda</a>
				<a href="#tentang">Tentang Kami</a>
				<a href="#produk">Produk</a>
				<a href="#transaksi">Transaksi</a>
				<a href="riwayat_pesanan.php">Cek Pesanan</a>
				<a href="#kontak">Kontak</a>
				<?php if ($customerSession) { ?>
					<a class="customer-account-nav" href="profil_pelanggan.php"><i class="fa fa-user" aria-hidden="true"></i> Profil &amp; Pesanan</a>
					<a class="customer-account-nav" href="logout_pelanggan.php">Keluar</a>
				<?php } else { ?>
					<a class="customer-account-nav" href="masuk_pelanggan.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Masuk</a>
					<a class="customer-account-nav" href="daftar_pelanggan.php">Daftar</a>
				<?php } ?>
			</nav>
			<form class="shop-search nav-search" method="GET" action="katalog_pelanggan.php" role="search">
				<label class="sr-only" for="productSearch">Cari nama atau merek produk</label>
				<input type="search" id="productSearch" name="q" value="<?php echo storefront_escape($search);?>" placeholder="Cari produk..." autocomplete="off">
				<?php if ($selectedCategory !== false && $selectedCategory !== null) { ?><input type="hidden" name="kategori" value="<?php echo (int) $selectedCategory;?>"><?php } ?>
				<?php if ($sort !== 'name') { ?><input type="hidden" name="sort" value="<?php echo storefront_escape($sort);?>"><?php } ?>
				<?php if ($selectedBrand !== '') { ?><input type="hidden" name="merk" value="<?php echo storefront_escape($selectedBrand);?>"><?php } ?>
				<?php if ($minimumPrice !== null) { ?><input type="hidden" name="harga_min" value="<?php echo $minimumPrice;?>"><?php } ?>
				<?php if ($maximumPrice !== null) { ?><input type="hidden" name="harga_max" value="<?php echo $maximumPrice;?>"><?php } ?>
				<button type="submit" aria-label="Cari produk"><i class="fa fa-search" aria-hidden="true"></i></button>
			</form>
			<button class="cart-open" type="button" aria-controls="cartPanel" aria-expanded="false">
				<i class="fa fa-shopping-cart" aria-hidden="true"></i><span>Keranjang</span><b id="cartCount"><?php echo $cartCount;?></b>
			</button>
		</div>
	</header>

	<main>
		<?php if ($createdOrder && is_array($createdOrder)) { ?>
			<div class="shop-container order-confirmation" role="status">
				<i class="fa fa-check-circle" aria-hidden="true"></i>
				<div><strong>Pesanan berhasil dibuat.</strong><span>Kode pesanan <?php echo storefront_escape($createdOrder['code'] ?? '');?>.<?php if (!empty($createdOrder['voucher'])) { ?> Voucher <?php echo storefront_escape($createdOrder['voucher']);?> menghemat Rp <?php echo number_format((int) ($createdOrder['discount'] ?? 0), 0, ',', '.');?>.<?php } ?> Stok sudah dicadangkan; admin akan mengonfirmasi pesanan Anda. <a href="riwayat_pesanan.php?kode=<?php echo rawurlencode((string) ($createdOrder['code'] ?? ''));?>">Lihat status pesanan</a></span></div>
				<strong class="order-confirmation-total">Rp <?php echo number_format((int) ($createdOrder['total'] ?? 0), 0, ',', '.');?></strong>
			</div>
		<?php } ?>
		<section class="shop-hero">
			<div class="shop-container shop-hero-inner">
				<div class="shop-hero-copy">
					<span class="hero-tag"><i class="fa fa-star" aria-hidden="true"></i> Teman produktif setiap hari</span>
					<h1><span><?php echo storefront_escape($storeName);?></span>Solusi lengkap kebutuhan alat tulis Anda</h1>
					<p>Produk berkualitas, harga bersahabat, dan pelayanan terbaik untuk Anda.</p>
					<a href="#katalog" class="hero-cta"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Belanja Sekarang <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
				</div>
				<div class="hero-scene" aria-hidden="true">
					<div class="scene-sparkle sparkle-one"><i class="fa fa-star"></i></div>
					<div class="scene-sparkle sparkle-two"><i class="fa fa-circle"></i></div>
					<div class="scene-notebooks"><span></span><span></span><span></span></div>
					<div class="scene-pencil-cup"><i class="fa fa-pencil"></i><i class="fa fa-pencil"></i><i class="fa fa-pencil"></i><i class="fa fa-pencil"></i><span></span></div>
					<div class="scene-pencil-box"><small>FABER-CASTELL</small><strong>2B</strong></div>
					<div class="scene-paper-pack"><strong>SIDU</strong><span>A4 70</span></div>
					<div class="scene-ruler"><i></i></div>
					<div class="scene-desk"></div>
				</div>
			</div>
		</section>

		<section class="shop-container benefits-strip" id="benefits" aria-label="Keunggulan toko">
			<div class="benefit-item"><i class="fa fa-truck" aria-hidden="true"></i><span><strong>Pengiriman Cepat</strong><small>Ke seluruh Indonesia</small></span></div>
			<div class="benefit-item"><i class="fa fa-shield" aria-hidden="true"></i><span><strong>Produk Original</strong><small>Kualitas terjamin</small></span></div>
			<div class="benefit-item"><i class="fa fa-tag" aria-hidden="true"></i><span><strong>Harga Terjangkau</strong><small>Belanja lebih hemat</small></span></div>
			<div class="benefit-item"><i class="fa fa-headphones" aria-hidden="true"></i><span><strong>Pelayanan Ramah</strong><small>Siap membantu Anda</small></span></div>
		</section>

		<section class="shop-container about-section" id="tentang">
			<div class="about-visual" aria-hidden="true">
				<div class="about-shelf shelf-one"><span></span><span></span><span></span><span></span></div>
				<div class="about-shelf shelf-two"><span></span><span></span><span></span><span></span></div>
				<div class="about-counter"></div>
				<div class="about-plant"><i class="fa fa-leaf"></i><i class="fa fa-leaf"></i><i class="fa fa-leaf"></i></div>
			</div>
			<div class="about-copy">
				<span class="section-kicker">Tentang toko kami</span>
				<h2><?php echo storefront_escape($storeName);?></h2>
				<h3>Teman setia kebutuhan ATK Anda</h3>
				<p><?php echo storefront_escape($storeName);?> hadir untuk membantu memenuhi kebutuhan perlengkapan sekolah, kantor, dan kreativitas. Temukan alat tulis, buku, kertas, serta perlengkapan kerja pilihan dengan harga yang bersahabat.</p>
				<p>Kami berkomitmen memberikan pengalaman belanja yang mudah dan layanan yang ramah. Pilih produk melalui katalog, masukkan ke keranjang, lalu kirim pesanan yang langsung tercatat pada sistem toko.</p>
				<a class="text-link" href="#produk">Jelajahi katalog <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
			</div>
			<aside class="about-promises">
				<h3>Mengapa memilih kami?</h3>
				<p><i class="fa fa-check-circle" aria-hidden="true"></i> Produk berkualitas</p>
				<p><i class="fa fa-check-circle" aria-hidden="true"></i> Harga terjangkau</p>
				<p><i class="fa fa-check-circle" aria-hidden="true"></i> Pelayanan ramah</p>
				<p><i class="fa fa-check-circle" aria-hidden="true"></i> Pemesanan praktis</p>
			</aside>
			<div class="about-stats">
				<div><i class="fa fa-users" aria-hidden="true"></i><strong>Ramah</strong><span>Untuk setiap pelanggan</span></div>
				<div><i class="fa fa-cubes" aria-hidden="true"></i><strong><?php echo count($categories);?> kategori</strong><span>Pilihan kebutuhan ATK</span></div>
				<div><i class="fa fa-shield" aria-hidden="true"></i><strong>Belanja nyaman</strong><span>Konfirmasi langsung dengan toko</span></div>
			</div>
		</section>

		<section class="shop-container catalog-section" id="produk">
			<div id="katalog">
			<div class="catalog-heading">
				<div><span class="section-kicker">Pilihan terbaik untuk Anda</span><h2>Produk Unggulan</h2><p>Temukan perlengkapan favorit Anda dengan mudah.</p></div>
				<span class="catalog-count"><?php echo number_format($catalogTotal);?> produk</span>
			</div>

			<?php if ($notice !== '') { ?>
				<div class="shop-notice shop-notice-<?php echo storefront_escape($noticeType);?>" role="status"><?php echo storefront_escape($notice);?></div>
			<?php } ?>
			<?php if ($filterError !== '') { ?><div class="shop-notice shop-notice-danger" role="alert"><?php echo storefront_escape($filterError);?></div><?php } ?>

			<div class="catalog-toolbar">
				<form class="catalog-sort-form" method="GET" action="katalog_pelanggan.php#produk">
					<?php if ($selectedCategory !== null) { ?><input type="hidden" name="kategori" value="<?php echo $selectedCategory;?>"><?php } ?>
					<?php if ($search !== '') { ?><input type="hidden" name="q" value="<?php echo storefront_escape($search);?>"><?php } ?>
					<label for="catalogBrand">Merek</label>
					<select id="catalogBrand" name="merk">
						<option value="">Semua merek</option>
						<?php foreach ($brands as $brand) { ?><option value="<?php echo storefront_escape($brand);?>" <?php echo $selectedBrand === $brand ? 'selected' : '';?>><?php echo storefront_escape($brand);?></option><?php } ?>
					</select>
					<label for="catalogMinPrice">Harga min.</label>
					<input id="catalogMinPrice" type="number" name="harga_min" min="0" step="1" value="<?php echo $minimumPrice === null ? '' : $minimumPrice;?>" placeholder="Rp">
					<label for="catalogMaxPrice">Harga maks.</label>
					<input id="catalogMaxPrice" type="number" name="harga_max" min="0" step="1" value="<?php echo $maximumPrice === null ? '' : $maximumPrice;?>" placeholder="Rp">
					<label for="catalogSort">Urutkan harga</label>
					<select id="catalogSort" name="sort">
						<option value="name" <?php echo $sort === 'name' ? 'selected' : '';?>>Nama produk</option>
						<option value="price_asc" <?php echo $sort === 'price_asc' ? 'selected' : '';?>>Harga termurah</option>
						<option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : '';?>>Harga termahal</option>
					</select>
					<button class="store-button store-button-outline" type="submit">Terapkan filter</button>
				</form>
				<div class="category-pills" aria-label="Filter kategori">
					<a class="category-pill <?php echo $selectedCategory === null ? 'is-selected' : '';?>" href="<?php
						$allCategoryParams = $catalogQueryParams;
						unset($allCategoryParams['kategori'], $allCategoryParams['halaman']);
						echo storefront_escape('katalog_pelanggan.php' . ($allCategoryParams ? '?' . http_build_query($allCategoryParams) : '') . '#produk');
					?>">Semua Produk</a>
					<?php foreach ($categories as $category) {
						$categoryId = (int) $category['id_kategori'];
						$categoryParams = $catalogQueryParams;
						$categoryParams['kategori'] = $categoryId;
						unset($categoryParams['halaman']);
						$categoryUrl = 'katalog_pelanggan.php?' . http_build_query($categoryParams) . '#produk';
					?>
						<a class="category-pill <?php echo $selectedCategory === $categoryId ? 'is-selected' : '';?>" href="<?php echo storefront_escape($categoryUrl);?>"><?php echo storefront_escape($category['nama_kategori']);?></a>
					<?php } ?>
				</div>
			</div>

			<div class="product-grid" id="productGrid">
				<?php foreach ($products as $product) {
					$available = (int) $product['stok'] > 0;
					$imageName = basename((string) ($product['gambar'] ?? ''));
					$imagePath = __DIR__ . '/assets/img/produk/' . $imageName;
					$hasProductImage = $imageName !== '' && is_file($imagePath);
					$imageFallback = product_image_placeholder(
						$product['nama_kategori'] ?? '',
						$product['nama_barang'] ?? '',
						$product['merk'] ?? ''
					);
					$imageHref = $hasProductImage
						? 'assets/img/produk/' . rawurlencode($imageName) . '?v=' . (int) filemtime($imagePath)
						: $imageFallback;
				?>
						<article class="product-card" data-product-card>
							<div class="product-art<?php echo $hasProductImage ? ' has-product-image' : ' has-no-product-image';?>">
								<img class="product-image" src="<?php echo storefront_escape($imageHref);?>" data-fallback-src="<?php echo storefront_escape($imageFallback);?>" data-fallback-alt="<?php echo storefront_escape('Ilustrasi ' . $product['nama_barang']);?>" alt="<?php echo storefront_escape(($hasProductImage ? '' : 'Ilustrasi ') . $product['nama_barang'] . ' ' . $product['merk']);?>" loading="lazy" decoding="async">
							</div>
						<div class="product-info">
							<p class="product-brand"><?php echo storefront_escape($product['merk']);?></p>
							<h3><?php echo storefront_escape($product['nama_barang']);?></h3>
							<div class="product-meta">
								<span class="product-price">Rp <?php echo number_format((int) $product['harga_jual'], 0, ',', '.');?></span>
								<span class="product-unit">/ <?php echo storefront_escape($product['satuan_barang']);?></span>
							</div>
							<div class="product-card-footer">
								<span class="stock-status <?php echo $available ? 'stock-in' : 'stock-out';?>">
									<i class="fa <?php echo $available ? 'fa-check-circle' : 'fa-times-circle';?>" aria-hidden="true"></i>
									<?php echo $available ? 'Stok tersedia' : 'Stok habis';?>
								</span>
								<?php if ($available) { ?>
									<form method="POST" action="katalog_pelanggan.php?ajax=cart" class="add-to-cart-form">
										<input type="hidden" name="_csrf" value="<?php echo storefront_escape($csrf);?>">
										<input type="hidden" name="action" value="add">
										<input type="hidden" name="product_id" value="<?php echo storefront_escape($product['id_barang']);?>">
										<input type="hidden" name="quantity" value="1">
										<button type="submit" class="add-cart-button" aria-label="Tambah <?php echo storefront_escape($product['nama_barang']);?> ke keranjang"><i class="fa fa-plus" aria-hidden="true"></i><span>Tambah</span></button>
									</form>
								<?php } else { ?>
									<button class="add-cart-button is-disabled" type="button" disabled><i class="fa fa-ban" aria-hidden="true"></i><span>Habis</span></button>
								<?php } ?>
							</div>
							<a class="product-detail-link" href="produk.php?id=<?php echo rawurlencode((string) $product['id_barang']);?>">Detail produk <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
						</div>
					</article>
				<?php } ?>
				<?php if (!$products) { ?>
					<div class="empty-catalog"><span><i class="fa fa-search" aria-hidden="true"></i></span><h3>Produk tidak ditemukan</h3><p>Coba ubah kata pencarian atau pilih kategori lain.</p><a href="katalog_pelanggan.php">Lihat semua produk</a></div>
				<?php } ?>
			</div>
			<?php if ($catalogPages > 1) { ?>
				<nav class="catalog-pagination" aria-label="Halaman produk">
					<span>Menampilkan <?php echo number_format(($catalogPage - 1) * $pageSize + 1);?>–<?php echo number_format(min($catalogPage * $pageSize, $catalogTotal));?> dari <?php echo number_format($catalogTotal);?> produk</span>
					<div>
						<?php if ($catalogPage > 1) { ?><a class="store-button store-button-outline" href="<?php echo storefront_escape($catalogPageUrl($catalogPage - 1));?>">Sebelumnya</a><?php } ?>
						<span>Halaman <?php echo $catalogPage;?> dari <?php echo $catalogPages;?></span>
						<?php if ($catalogPage < $catalogPages) { ?><a class="store-button store-button-outline" href="<?php echo storefront_escape($catalogPageUrl($catalogPage + 1));?>">Berikutnya</a><?php } ?>
					</div>
				</nav>
			<?php } ?>
			</div>
		</section>

		<section class="shop-container transaction-section" id="transaksi">
			<div class="section-heading">
				<div><span class="section-kicker">Pesanan Anda</span><h2>Transaksi &amp; Keranjang Belanja</h2><p>Periksa pilihan produk Anda sebelum mengirim permintaan pesanan ke toko.</p></div>
				<span class="transaction-count"><i class="fa fa-shopping-bag" aria-hidden="true"></i> <span id="transactionCountValue"><?php echo $cartCount;?> item</span></span>
			</div>
			<div class="transaction-card">
				<div class="transaction-items">
					<?php if (!$cartProducts) { ?>
						<div class="transaction-empty"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span><div><h3>Keranjang Anda masih kosong</h3><p>Tambahkan produk dari katalog untuk mulai menyusun pesanan.</p></div><a class="store-button store-button-outline" href="#produk">Pilih Produk</a></div>
					<?php } else { foreach ($cartProducts as $product) { ?>
						<?php
							$cartImageName = basename((string) ($product['gambar'] ?? ''));
							$cartImagePath = __DIR__ . '/assets/img/produk/' . $cartImageName;
							$cartImageSrc = $cartImageName !== '' && is_file($cartImagePath)
								? 'assets/img/produk/' . rawurlencode($cartImageName)
								: product_image_placeholder($product['nama_kategori'] ?? '', $product['nama_barang'] ?? '', $product['merk'] ?? '');
						?>
						<div class="transaction-item">
							<img class="transaction-item-image" src="<?php echo storefront_escape($cartImageSrc);?>" alt="" loading="lazy">
							<div><strong><?php echo storefront_escape($product['nama_barang']);?></strong><small><?php echo storefront_escape($product['merk']);?> &middot; Rp <?php echo number_format((int) $product['harga_jual'], 0, ',', '.');?> / <?php echo storefront_escape($product['satuan_barang']);?></small></div>
							<span class="transaction-quantity">x<?php echo (int) $product['quantity'];?></span>
							<strong class="transaction-subtotal">Rp <?php echo number_format((int) $product['subtotal'], 0, ',', '.');?></strong>
						</div>
					<?php } } ?>
				</div>
				<div class="transaction-summary">
					<div><span>Jumlah item</span><strong id="transactionItemCount"><?php echo $cartCount;?></strong></div>
					<div class="transaction-total"><span>Subtotal pesanan</span><strong id="transactionSubtotal">Rp <?php echo number_format($cartTotal, 0, ',', '.');?></strong></div>
					<p>Pesanan tersimpan langsung di sistem toko. Admin akan menghubungi Anda untuk konfirmasi.</p>
					<?php if ($cartProducts) { ?>
						<button class="store-button" type="button" data-open-cart><i class="fa fa-shopping-bag" aria-hidden="true"></i> Lanjutkan Pesanan</button>
					<?php } else { ?>
						<a class="store-button" href="#produk"><i class="fa fa-shopping-bag" aria-hidden="true"></i> Belanja Sekarang</a>
					<?php } ?>
				</div>
			</div>
			<div class="transaction-steps">
				<div><span>1</span><strong>Pilih produk</strong><small>Tambahkan barang ke keranjang</small></div>
				<div><span>2</span><strong>Periksa pesanan</strong><small>Cek jumlah dan subtotal pilihan</small></div>
				<div><span>3</span><strong>Konfirmasi dari toko</strong><small>Admin menghubungi Anda untuk pembayaran dan pengambilan</small></div>
			</div>
		</section>

		<section class="contact-section" id="kontak">
			<div class="shop-container">
				<div class="section-heading">
					<div><span class="section-kicker">Kami siap membantu Anda</span><h2>Kontak Kami</h2><p>Hubungi toko untuk bertanya tentang produk, stok, dan pesanan.</p></div>
				</div>
				<div class="contact-grid">
					<div class="contact-details">
						<h3>Informasi toko</h3>
						<div class="contact-detail"><span><i class="fa fa-map-marker" aria-hidden="true"></i></span><div><strong>Alamat</strong><p><?php echo storefront_escape($store['alamat_toko'] ?? 'Silakan hubungi toko untuk informasi alamat.');?></p></div></div>
						<?php if (!empty($store['tlp'])) { ?>
							<div class="contact-detail"><span><i class="fa fa-phone" aria-hidden="true"></i></span><div><strong>Telepon / WhatsApp</strong><a href="tel:<?php echo storefront_escape(preg_replace('/[^0-9+]/', '', (string) $store['tlp']));?>"><?php echo storefront_escape($store['tlp']);?></a></div></div>
						<?php } ?>
						<div class="contact-detail"><span><i class="fa fa-clock-o" aria-hidden="true"></i></span><div><strong>Jam layanan</strong><p>Silakan hubungi kami untuk ketersediaan layanan dan jam operasional.</p></div></div>
						<?php if ($whatsAppAvailable) { ?><a class="contact-whatsapp" href="https://wa.me/<?php echo storefront_escape($phoneDigits);?>" target="_blank" rel="noopener noreferrer"><i class="fa fa-whatsapp" aria-hidden="true"></i> Chat WhatsApp toko</a><?php } ?>
					</div>
					<form class="contact-form" id="contactForm" data-phone="<?php echo storefront_escape($phoneDigits);?>" data-store="<?php echo storefront_escape($storeName);?>">
						<h3>Kirim pesan</h3>
						<label for="contactName">Nama lengkap</label>
						<input id="contactName" name="name" type="text" maxlength="80" placeholder="Nama Anda" required>
						<label for="contactEmail">Email (opsional)</label>
						<input id="contactEmail" name="email" type="email" maxlength="120" placeholder="nama@email.com">
						<label for="contactMessage">Pesan</label>
						<textarea id="contactMessage" name="message" maxlength="500" placeholder="Tuliskan pertanyaan atau kebutuhan Anda..." required></textarea>
						<button class="store-button" type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i> Kirim via WhatsApp</button>
						<p class="contact-form-note">Pesan akan dibuka di WhatsApp agar dapat Anda tinjau sebelum dikirim.</p>
					</form>
				</div>
			</div>
		</section>
	</main>

	<footer class="shop-footer" id="kontak">
		<div class="shop-container shop-footer-grid">
			<div class="footer-about">
				<a class="shop-brand shop-brand-footer" href="katalog_pelanggan.php"><span class="shop-brand-mark"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span><span><strong><?php echo storefront_escape($storeName);?></strong><small>Lengkap, Murah, dan Berkualitas</small></span></a>
			</div>
			<div class="footer-links"><h2>Navigasi</h2><a href="katalog_pelanggan.php">Beranda</a><a href="#tentang">Tentang Kami</a><a href="#produk">Produk</a><a href="#transaksi">Transaksi</a><a href="#kontak">Kontak</a></div>
			<div class="footer-contact"><h2>Kontak Kami</h2>
				<?php if (!empty($store['tlp'])) { ?><a href="tel:<?php echo storefront_escape(preg_replace('/[^0-9+]/', '', (string) $store['tlp']));?>"><i class="fa fa-phone" aria-hidden="true"></i><?php echo storefront_escape($store['tlp']);?></a><?php } ?>
				<?php if (!empty($store['alamat_toko'])) { ?><p><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo storefront_escape($store['alamat_toko']);?></p><?php } ?>
			</div>
			<div class="footer-social"><h2>Belanja bersama kami</h2><p>Perlengkapan belajar dan kerja, lengkap dalam satu tempat.</p><a href="#katalog">Jelajahi Produk <i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
		</div>
		<div class="shop-container footer-bottom"><span>&copy; <?php echo date('Y');?> <?php echo storefront_escape($storeName);?></span><span>Belanja praktis, kebutuhan produktif terpenuhi.</span></div>
	</footer>

	<div class="cart-scrim" id="cartScrim"></div>
	<aside class="cart-panel" id="cartPanel" aria-label="Keranjang belanja" aria-hidden="true">
		<div class="cart-panel-header">
			<div><span class="section-kicker">Pesanan Anda</span><h2>Keranjang Belanja <span id="cartPanelCount">(<?php echo $cartCount;?>)</span></h2></div>
			<button class="cart-close" type="button" aria-label="Tutup keranjang"><i class="fa fa-times"></i></button>
		</div>
		<div class="cart-panel-body" id="cartPanelBody">
			<?php if (!$cartProducts) { ?>
				<div class="cart-empty"><span><i class="fa fa-shopping-bag"></i></span><h3>Keranjang masih kosong</h3><p>Tambahkan produk pilihan Anda untuk mulai berbelanja.</p></div>
			<?php } else { foreach ($cartProducts as $product) { ?>
				<?php
					$cartImageName = basename((string) ($product['gambar'] ?? ''));
					$cartImagePath = __DIR__ . '/assets/img/produk/' . $cartImageName;
					$cartImageSrc = $cartImageName !== '' && is_file($cartImagePath)
						? 'assets/img/produk/' . rawurlencode($cartImageName)
						: product_image_placeholder($product['nama_kategori'] ?? '', $product['nama_barang'] ?? '', $product['merk'] ?? '');
				?>
				<div class="cart-item" data-cart-item="<?php echo storefront_escape($product['id_barang']);?>">
					<img class="cart-item-image" src="<?php echo storefront_escape($cartImageSrc);?>" alt="" loading="lazy">
					<div class="cart-item-main">
						<div class="cart-item-info"><strong><?php echo storefront_escape($product['nama_barang']);?></strong><small>Rp <?php echo number_format((int) $product['harga_jual'], 0, ',', '.');?> / <?php echo storefront_escape($product['satuan_barang']);?></small></div>
						<strong class="cart-item-subtotal">Rp <?php echo number_format($product['subtotal'], 0, ',', '.');?></strong>
					</div>
					<form method="POST" action="katalog_pelanggan.php?ajax=cart" class="cart-quantity-form">
						<input type="hidden" name="_csrf" value="<?php echo storefront_escape($csrf);?>">
						<input type="hidden" name="action" value="update">
						<input type="hidden" name="product_id" value="<?php echo storefront_escape($product['id_barang']);?>">
						<button type="submit" name="delta" value="-1" aria-label="Kurangi jumlah <?php echo storefront_escape($product['nama_barang']);?>" <?php echo (int) $product['quantity'] <= 1 ? 'disabled' : '';?>>−</button>
						<input type="number" name="quantity" min="1" max="<?php echo min(999, (int) $product['stok']);?>" value="<?php echo (int) $product['quantity'];?>" aria-label="Jumlah <?php echo storefront_escape($product['nama_barang']);?>">
						<button type="submit" name="delta" value="1" aria-label="Tambah jumlah <?php echo storefront_escape($product['nama_barang']);?>" <?php echo (int) $product['quantity'] >= min(999, (int) $product['stok']) ? 'disabled' : '';?>>+</button>
					</form>
					<form method="POST" action="katalog_pelanggan.php?ajax=cart" class="cart-remove-form">
						<input type="hidden" name="_csrf" value="<?php echo storefront_escape($csrf);?>">
						<input type="hidden" name="action" value="remove">
						<input type="hidden" name="product_id" value="<?php echo storefront_escape($product['id_barang']);?>">
						<button type="submit" aria-label="Hapus <?php echo storefront_escape($product['nama_barang']);?>"><i class="fa fa-trash" aria-hidden="true"></i><span>Hapus</span></button>
					</form>
				</div>
			<?php } } ?>
		</div>
		<div class="cart-panel-footer">
			<div class="cart-total"><span>Subtotal</span><strong id="cartTotal">Rp <?php echo number_format($cartTotal, 0, ',', '.');?></strong></div>
			<?php if ($orderError !== '') { ?>
				<p class="checkout-error" role="alert"><?php echo storefront_escape($orderError);?></p>
			<?php } ?>
			<?php if ($cartProducts) { ?>
				<form class="customer-order-form" method="POST" action="katalog_pelanggan.php#cartPanel">
					<input type="hidden" name="_csrf" value="<?php echo storefront_escape($csrf);?>">
					<input type="hidden" name="action" value="create_order">
					<input type="hidden" name="order_submission_token" value="<?php echo storefront_escape($orderSubmissionToken);?>">
					<h3 class="checkout-form-title">Checkout Pesanan</h3>
					<label class="checkout-label" for="customerName">Nama pembeli</label>
					<input class="checkout-input" id="customerName" name="customer_name" type="text" maxlength="120" autocomplete="name" placeholder="Nama lengkap" value="<?php echo storefront_escape($customerSession['nama_pelanggan'] ?? '');?>" required>
					<label class="checkout-label" for="customerPhone">No. HP / WhatsApp</label>
					<input class="checkout-input" id="customerPhone" name="customer_phone" type="tel" maxlength="30" autocomplete="tel" placeholder="Contoh: 081234567890" value="<?php echo storefront_escape($customerSession['no_hp'] ?? '');?>" required>
					<label class="checkout-label" for="pickupMethod">Metode pengambilan</label>
					<select class="checkout-input" id="pickupMethod" name="pickup_method" required>
						<option value="store_pickup">Ambil di toko</option>
						<option value="delivery">Pengiriman</option>
					</select>
					<div id="deliveryAddressField" hidden>
						<?php if ($customerSession && $customerAddresses) { ?>
							<label class="checkout-label" for="deliveryAddressId">Alamat tersimpan</label>
							<select class="checkout-input" id="deliveryAddressId" name="delivery_address_id">
								<?php foreach ($customerAddresses as $savedAddress) { ?>
									<option value="<?php echo (int) $savedAddress['id_alamat'];?>" <?php echo (int) $savedAddress['id_alamat'] === (int) ($_POST['delivery_address_id'] ?? 0) ? 'selected' : '';?>>
										<?php echo storefront_escape($savedAddress['label'] . ' — ' . $savedAddress['nama_penerima'] . ', ' . $savedAddress['alamat_lengkap']);?>
									</option>
								<?php } ?>
								<option value="0" <?php echo (int) ($_POST['delivery_address_id'] ?? 0) === 0 ? 'selected' : '';?>>Gunakan alamat baru di bawah</option>
							</select>
						<?php } else { ?>
							<input type="hidden" name="delivery_address_id" value="0">
						<?php } ?>
						<label class="checkout-label" for="deliveryAddress">Alamat pengiriman</label>
						<textarea class="checkout-input checkout-note" id="deliveryAddress" name="delivery_address" maxlength="1000" placeholder="Alamat lengkap penerima"><?php echo storefront_escape($_POST['delivery_address'] ?? ($customerSession['alamat'] ?? ''));?></textarea>
						<?php if ($customerSession && $customerAddresses) { ?><small>Jika memilih alamat tersimpan, kolom alamat baru diabaikan.</small><?php } ?>
						<small>Ongkos kirim belum dihitung otomatis dan akan dikonfirmasi toko secara terpisah.</small>
					</div>
					<label class="checkout-label" for="orderNote">Catatan pesanan <span>(opsional)</span></label>
					<textarea class="checkout-input checkout-note" id="orderNote" name="order_note" maxlength="1000" placeholder="Catatan tambahan untuk toko"></textarea>
					<label class="checkout-label" for="paymentMethod">Metode pembayaran</label>
					<select class="checkout-input" id="paymentMethod" name="payment_method" required>
						<option value="pay_at_store">Bayar di Toko (Tunai / QRIS Kasir)</option>
						<option value="bank_transfer">Transfer bank</option>
					</select>
					<label class="checkout-label" for="voucherCode">Kode voucher <span>(opsional)</span></label>
					<div class="voucher-entry">
						<input class="checkout-input" id="voucherCode" name="voucher_code" maxlength="40" autocapitalize="characters" autocomplete="off" placeholder="Masukkan kode voucher" value="<?php echo storefront_escape($_POST['voucher_code'] ?? '');?>">
						<button class="store-button store-button-outline" id="validateVoucher" type="button">Cek Voucher</button>
					</div>
					<p class="voucher-feedback" id="voucherFeedback" aria-live="polite"></p>
					<div class="payment-method-info" id="paymentMethodInfo" aria-live="polite">
						<div class="payment-info-store">
							<i class="fa fa-info-circle" aria-hidden="true"></i>
							<span>Silakan tunjukkan nama pemesan ke kasir saat pengambilan.</span>
						</div>
						<div class="payment-info-transfer" hidden>
							<i class="fa fa-university" aria-hidden="true"></i>
							<span>
								<?php if ($storeBankAccount !== '') { ?>
									<strong>Rekening tujuan</strong><br><?php echo storefront_escape($storeBankAccount);?><br><small>Pastikan nama toko sesuai sebelum melakukan transfer.</small>
								<?php } else { ?>
									<strong>Rekening belum dikonfirmasi</strong><br><small>Hubungi toko untuk meminta detail rekening. Jangan melakukan transfer sebelum menerima konfirmasi.</small>
								<?php } ?>
							</span>
							<a id="transferProofLink" href="<?php echo $whatsAppAvailable ? 'https://wa.me/' . storefront_escape($phoneDigits) : '#';?>" target="_blank" rel="noopener noreferrer" <?php echo !$whatsAppAvailable ? 'hidden' : '';?>><?php echo $storeBankAccount !== '' ? 'Kirim bukti transfer via WhatsApp' : 'Konfirmasi rekening via WhatsApp';?></a>
							<?php if (!$whatsAppAvailable) { ?><small>Nomor WhatsApp toko belum tersedia. Silakan pilih pembayaran di toko.</small><?php } ?>
						</div>
					</div>
					<button class="whatsapp-checkout" type="submit"><i class="fa fa-check" aria-hidden="true"></i> Buat Pesanan</button>
					<p class="checkout-caption">Stok dicadangkan setelah pesanan berhasil dibuat. Pembayaran dikonfirmasi oleh toko.</p>
				</form>
			<?php } ?>
		</div>
	</aside>

	<div class="shop-toast" id="shopToast" role="status" aria-live="polite"></div>
	<script>
	(function () {
		var csrf = <?php echo json_encode($csrf, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);?>;
		var panel = document.getElementById('cartPanel');
		var scrim = document.getElementById('cartScrim');
		var countBadge = document.getElementById('cartCount');
		var panelCount = document.getElementById('cartPanelCount');
		var toast = document.getElementById('shopToast');
		var toastTimer;

		function showCart(open) {
			panel.classList.toggle('is-open', open);
			scrim.classList.toggle('is-visible', open);
			panel.setAttribute('aria-hidden', open ? 'false' : 'true');
			document.querySelector('.cart-open').setAttribute('aria-expanded', open ? 'true' : 'false');
			document.body.classList.toggle('cart-opened', open);
		}
		if (<?php echo $orderError !== '' ? 'true' : 'false';?>) {
			showCart(true);
		}

		function notify(message, error) {
			toast.textContent = message;
			toast.classList.toggle('is-error', !!error);
			toast.classList.add('is-visible');
			window.clearTimeout(toastTimer);
			toastTimer = window.setTimeout(function () { toast.classList.remove('is-visible'); }, 2800);
		}

		function updateCartDisplay(data, form) {
			var formattedTotal = 'Rp ' + Number(data.total).toLocaleString('id-ID');
			document.getElementById('cartTotal').textContent = formattedTotal;
			document.getElementById('transactionSubtotal').textContent = formattedTotal;
			if (form.classList.contains('cart-quantity-form')) {
				var productId = form.querySelector('input[name="product_id"]').value;
				var item = data.items.find(function (cartItem) { return cartItem.product_id === productId; });
				if (item) {
					var row = form.closest('.cart-item');
					var quantityInput = form.querySelector('input[name="quantity"]');
					quantityInput.value = item.quantity;
					quantityInput.max = item.max_quantity;
					form.querySelector('button[value="-1"]').disabled = item.quantity <= 1;
					form.querySelector('button[value="1"]').disabled = item.quantity >= item.max_quantity;
					row.querySelector('.cart-item-subtotal').textContent = 'Rp ' + Number(item.subtotal).toLocaleString('id-ID');
				}
			} else if (form.classList.contains('cart-remove-form')) {
				var removedRow = form.closest('.cart-item');
				if (removedRow) { removedRow.remove(); }
				if (data.count === 0) {
					document.getElementById('cartPanelBody').innerHTML = '<div class="cart-empty"><span><i class="fa fa-shopping-bag" aria-hidden="true"></i></span><h3>Keranjang masih kosong</h3><p>Tambahkan produk pilihan Anda untuk mulai berbelanja.</p></div>';
					var orderForm = document.querySelector('.customer-order-form');
					if (orderForm) { orderForm.hidden = true; }
				}
			}
		}

		document.querySelector('.cart-open').addEventListener('click', function () { showCart(true); });
		document.querySelector('.cart-close').addEventListener('click', function () { showCart(false); });
		scrim.addEventListener('click', function () { showCart(false); });
		document.addEventListener('keydown', function (event) { if (event.key === 'Escape') { showCart(false); } });
		document.querySelectorAll('[data-open-cart]').forEach(function (button) {
			button.addEventListener('click', function () { showCart(true); });
		});
		document.querySelectorAll('.product-image').forEach(function (image) {
			image.addEventListener('error', function () {
				if (image.dataset.fallbackSrc && image.dataset.usingFallback !== 'true') {
					image.dataset.usingFallback = 'true';
					image.src = image.dataset.fallbackSrc;
					image.alt = image.dataset.fallbackAlt || 'Placeholder perlengkapan alat tulis kantor';
					image.parentNode.classList.remove('has-product-image');
					image.parentNode.classList.add('has-no-product-image');
					return;
				}
				image.hidden = true;
				image.parentNode.classList.remove('has-product-image');
				image.parentNode.classList.add('has-no-product-image');
			});
		});

		document.querySelectorAll('.shop-navigation a[href^="#"]').forEach(function (link) {
			link.addEventListener('click', function () {
				document.querySelectorAll('.shop-navigation a').forEach(function (item) {
					item.classList.toggle('is-current', item === link);
				});
			});
		});

		document.querySelectorAll('.add-to-cart-form, .cart-remove-form, .cart-quantity-form').forEach(function (form) {
			form.addEventListener('submit', function (event) {
				event.preventDefault();
				var button = event.submitter || form.querySelector('button[type="submit"]');
				var quantityInput = form.querySelector('input[name="quantity"]');
				var previousQuantity = quantityInput ? quantityInput.value : null;
				if (form.classList.contains('cart-quantity-form') && button && button.name === 'delta') {
					quantityInput.value = String(Number(quantityInput.value) + Number(button.value));
				}
				if (quantityInput && !quantityInput.checkValidity()) {
					quantityInput.value = previousQuantity;
					quantityInput.reportValidity();
					return;
				}
				if (button) { button.disabled = true; }
				fetch(form.getAttribute('action'), {
					method: 'POST',
					body: new FormData(form),
					headers: { 'X-Requested-With': 'XMLHttpRequest' },
					credentials: 'same-origin'
				}).then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok || !data.ok) {
							throw new Error(data.message || 'Keranjang gagal diperbarui.');
						}
						return data;
					});
				}).then(function (data) {
					countBadge.textContent = data.count;
					panelCount.textContent = '(' + data.count + ')';
					document.getElementById('transactionCountValue').textContent = data.count + ' item';
					document.getElementById('transactionItemCount').textContent = data.count;
					notify(data.message, false);
					if (form.classList.contains('add-to-cart-form')) {
						sessionStorage.setItem('customerCartDrawerOpen', '1');
						window.setTimeout(function () { window.location.reload(); }, 220);
					} else {
						updateCartDisplay(data, form);
					}
				}).catch(function (error) {
					notify(error.message, true);
					if (quantityInput) { quantityInput.value = previousQuantity; }
					if (button) { button.disabled = false; }
				});
			});
			var customerOrderForm = document.querySelector('.customer-order-form');
			if (customerOrderForm) {
				customerOrderForm.addEventListener('submit', function (event) {
					if (!customerOrderForm.checkValidity()) {
						event.preventDefault();
						customerOrderForm.reportValidity();
						return;
					}
					var submitButton = customerOrderForm.querySelector('button[type="submit"]');
					if (submitButton) {
						submitButton.disabled = true;
						submitButton.setAttribute('aria-busy', 'true');
						submitButton.textContent = 'Mengirim pesanan…';
					}
				});
			}
		});
		var voucherForm = document.querySelector('.customer-order-form');
		var voucherButton = document.getElementById('validateVoucher');
		var voucherCodeInput = document.getElementById('voucherCode');
		var voucherFeedback = document.getElementById('voucherFeedback');
		if (voucherForm && voucherButton && voucherCodeInput && voucherFeedback) {
			voucherButton.addEventListener('click', function () {
				if (!voucherCodeInput.value.trim()) {
					voucherFeedback.textContent = 'Masukkan kode voucher terlebih dahulu.';
					voucherFeedback.className = 'voucher-feedback is-error';
					return;
				}
				var voucherData = new FormData(voucherForm);
				voucherData.set('action', 'validate_voucher');
				voucherButton.disabled = true;
				voucherButton.textContent = 'Memeriksa…';
				fetch('katalog_pelanggan.php?ajax=voucher', {
					method: 'POST',
					body: voucherData,
					headers: {'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'},
					credentials: 'same-origin'
				}).then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok || !data.ok) throw new Error(data.message || 'Voucher belum dapat diterapkan.');
						return data;
					});
				}).then(function (data) {
					var money = function (amount) {
						return 'Rp ' + new Intl.NumberFormat('id-ID').format(amount);
					};
					voucherFeedback.textContent = data.message + ' Potongan ' + money(data.discount) + '; total produk setelah diskon ' + money(data.total) + '. Ongkos kirim belum termasuk.';
					voucherFeedback.className = 'voucher-feedback is-success';
				}).catch(function (error) {
					voucherFeedback.textContent = error.message;
					voucherFeedback.className = 'voucher-feedback is-error';
				}).then(function () {
					voucherButton.disabled = false;
					voucherButton.textContent = 'Cek Voucher';
				});
			});
			voucherCodeInput.addEventListener('input', function () {
				voucherFeedback.textContent = '';
				voucherFeedback.className = 'voucher-feedback';
			});
		}
		if (sessionStorage.getItem('customerCartDrawerOpen') === '1') {
			sessionStorage.removeItem('customerCartDrawerOpen');
			showCart(true);
		}

		var pickupMethod = document.getElementById('pickupMethod');
		var deliveryAddress = document.getElementById('deliveryAddress');
		var deliveryAddressField = document.getElementById('deliveryAddressField');
		if (pickupMethod && deliveryAddress && deliveryAddressField) {
			var deliveryAddressId = document.getElementById('deliveryAddressId');
			function updateDeliveryAddress() {
				var needsAddress = pickupMethod.value === 'delivery';
				var usesSavedAddress = deliveryAddressId && deliveryAddressId.value !== '0';
				deliveryAddressField.hidden = !needsAddress;
				deliveryAddress.required = needsAddress && !usesSavedAddress;
			}
			pickupMethod.addEventListener('change', updateDeliveryAddress);
			if (deliveryAddressId) deliveryAddressId.addEventListener('change', updateDeliveryAddress);
			updateDeliveryAddress();
		}
		var paymentMethod = document.getElementById('paymentMethod');
		var paymentMethodInfo = document.getElementById('paymentMethodInfo');
		var storePaymentInfo = document.querySelector('.payment-info-store');
		var transferPaymentInfo = document.querySelector('.payment-info-transfer');
		var transferProofLink = document.getElementById('transferProofLink');
		if (paymentMethod && paymentMethodInfo && storePaymentInfo && transferPaymentInfo) {
			function updatePaymentMethodInfo() {
				var bankTransfer = paymentMethod.value === 'bank_transfer';
				storePaymentInfo.hidden = bankTransfer;
				transferPaymentInfo.hidden = !bankTransfer;
				if (transferProofLink && bankTransfer && transferProofLink.href !== '#') {
					var message = '<?php echo $storeBankAccount !== '' ? 'Halo, saya ingin mengirim bukti transfer untuk pesanan atas nama ' : 'Halo, saya ingin meminta detail rekening untuk pesanan atas nama ';?>' +
						(document.getElementById('customerName').value.trim() || '[nama pemesan]') + '.';
					transferProofLink.href = transferProofLink.href.split('?')[0] + '?text=' + encodeURIComponent(message);
				}
			}
			paymentMethod.addEventListener('change', updatePaymentMethodInfo);
			document.getElementById('customerName').addEventListener('input', updatePaymentMethodInfo);
			updatePaymentMethodInfo();
		}

		var contactForm = document.getElementById('contactForm');
		if (contactForm) {
			contactForm.addEventListener('submit', function (event) {
				event.preventDefault();
				var phone = contactForm.getAttribute('data-phone');
				if (!phone) {
					notify('Nomor WhatsApp toko belum tersedia. Silakan hubungi toko melalui telepon.', true);
					return;
				}
				var name = document.getElementById('contactName').value.trim();
				var email = document.getElementById('contactEmail').value.trim();
				var message = document.getElementById('contactMessage').value.trim();
				var lines = ['Halo ' + contactForm.getAttribute('data-store') + ', saya ' + name + '.'];
				if (email) { lines.push('Email: ' + email); }
				lines.push('', message);
				window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(lines.join('\n')), '_blank', 'noopener');
			});
		}
	}());
	</script>
</body>
</html>
