<?php
require __DIR__ . '/../../../fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses ditolak.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	http_response_code(405);
	exit('Metode permintaan tidak diizinkan.');
}
if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code(403);
	exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
}

$action = (string) ($_POST['action'] ?? '');
$returnId = filter_var($_POST['return_id'] ?? 0, FILTER_VALIDATE_INT);
$refundId = filter_var($_POST['refund_id'] ?? 0, FILTER_VALIDATE_INT);
$returnActions = array('review_return', 'mark_received', 'inspect_return');
$refundActions = array('record_refund', 'verify_refund', 'reject_refund');
if (!in_array($action, array_merge($returnActions, $refundActions), true)
	|| ($action !== 'record_refund' && $action !== 'verify_refund' && $action !== 'reject_refund' && ($returnId === false || $returnId < 1))
	|| (in_array($action, $refundActions, true) && ($refundId === false || $refundId < 1))) {
	header('Location: ../../../index.php?page=retur&result=invalid');
	exit;
}

require __DIR__ . '/../../../config.php';
require_once __DIR__ . '/../../../fungsi/customer_workflows.php';
require_once __DIR__ . '/../../../fungsi/refund_workflow.php';
require_once __DIR__ . '/../../../fungsi/stock_movement.php';
require_once __DIR__ . '/../../../fungsi/order_pricing.php';
$redirect = 'Location: ../../../index.php?page=retur';
$memberId = (int) $_SESSION['admin']['id_member'];

try {
	$config->beginTransaction();
	if (in_array($action, $returnActions, true)) {
		$returnQuery = $config->prepare(
			'SELECT r.*, p.kode_pesanan, p.total, p.subtotal_produk, p.diskon_voucher, p.id_pelanggan, p.status_pembayaran
				FROM retur_pesanan r INNER JOIN pesanan p ON p.id_pesanan = r.id_pesanan
				WHERE r.id_retur = ? FOR UPDATE'
		);
		$returnQuery->execute(array((int) $returnId));
		$return = $returnQuery->fetch(PDO::FETCH_ASSOC);
		if (!$return) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}

		if ($action === 'review_return') {
			$decision = (string) ($_POST['decision'] ?? '');
			$note = trim((string) ($_POST['note'] ?? ''));
			if ($return['status'] !== 'pending' || !in_array($decision, array('approve', 'reject'), true)
				|| strlen($note) > 1000 || ($decision === 'reject' && $note === '')) {
				$config->rollBack();
				header($redirect . '&result=invalid');
				exit;
			}
			$newStatus = $decision === 'approve' ? 'approved' : 'rejected';
			$config->prepare(
				'UPDATE retur_pesanan SET status = ?, catatan_admin = ?, id_member_peninjau = ?, tanggal_update = ?
					WHERE id_retur = ? AND status = ?'
			)->execute(array($newStatus, $note !== '' ? $note : null, $memberId, date('Y-m-d H:i:s'), (int) $returnId, 'pending'));
			customer_workflow_notify(
				$config,
				$return['id_pelanggan'],
				(int) $return['id_pesanan'],
				$decision === 'approve' ? 'Retur disetujui' : 'Permintaan retur ditolak',
				$decision === 'approve'
					? 'Retur pesanan ' . $return['kode_pesanan'] . ' disetujui. Admin akan menerima dan memeriksa barang.'
					: 'Permintaan retur pesanan ' . $return['kode_pesanan'] . ' ditolak.' . ($note !== '' ? ' Catatan: ' . $note : '')
			);
			customer_workflow_audit($config, $memberId, $decision === 'approve' ? 'Approve order return' : 'Reject order return', 'retur_pesanan', (int) $returnId, array('status' => 'pending'), array('status' => $newStatus, 'catatan' => $note));
			$config->commit();
			header($redirect . '&result=return-updated');
			exit;
		}

		if ($action === 'mark_received') {
			if ($return['status'] !== 'approved') {
				$config->rollBack();
				header($redirect . '&result=invalid');
				exit;
			}
			$config->prepare(
				"UPDATE retur_pesanan SET status = 'received', tanggal_barang_diterima = ?, tanggal_update = ?
					WHERE id_retur = ? AND status = 'approved'"
			)->execute(array(date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), (int) $returnId));
			customer_workflow_notify($config, $return['id_pelanggan'], (int) $return['id_pesanan'], 'Barang retur diterima', 'Toko telah mencatat barang retur untuk pesanan ' . $return['kode_pesanan'] . ' dan akan memeriksanya.');
			customer_workflow_audit($config, $memberId, 'Receive returned items', 'retur_pesanan', (int) $returnId, array('status' => 'approved'), array('status' => 'received'));
			$config->commit();
			header($redirect . '&result=return-updated');
			exit;
		}

		if ($return['status'] !== 'received' || !is_array($_POST['received'] ?? null) || !is_array($_POST['restock'] ?? null)) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$returnDetailQuery = $config->prepare(
			'SELECT * FROM detail_retur WHERE id_retur = ? ORDER BY id_barang FOR UPDATE'
		);
		$returnDetailQuery->execute(array((int) $returnId));
		$returnLines = $returnDetailQuery->fetchAll(PDO::FETCH_ASSOC);
		if (!$returnLines) {
			throw new RuntimeException('Return has no item rows.');
		}
		$receivedInput = $_POST['received'];
		$restockInput = $_POST['restock'];
		$inspectionNote = trim((string) ($_POST['inspection_note'] ?? ''));
		if (strlen($inspectionNote) > 500) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$stockQuery = $config->prepare('SELECT stok FROM barang WHERE id_barang = ? FOR UPDATE');
		$stockUpdate = $config->prepare('UPDATE barang SET stok = CAST(stok AS UNSIGNED) + ? WHERE id_barang = ?');
		$updateReturnLine = $config->prepare(
			'UPDATE detail_retur SET jumlah_diterima = ?, jumlah_stok_dikembalikan = ?, catatan_pemeriksaan = ?
				WHERE id_detail_retur = ?'
		);
		$receivedCount = 0;
		$restockCount = 0;
		$receivedByProduct = array();
		foreach ($returnLines as $line) {
			$receivedQuantity = filter_var($receivedInput[$line['id_barang']] ?? null, FILTER_VALIDATE_INT);
			$restockQuantity = filter_var($restockInput[$line['id_barang']] ?? null, FILTER_VALIDATE_INT);
			if ($receivedQuantity === false || $receivedQuantity < 0 || $receivedQuantity > (int) $line['jumlah_diminta']
				|| $restockQuantity === false || $restockQuantity < 0 || $restockQuantity > $receivedQuantity) {
				throw new DomainException('Jumlah barang yang dinyatakan layak tidak valid.');
			}
			if ($restockQuantity > 0) {
				$stockQuery->execute(array($line['id_barang']));
				$stockBefore = $stockQuery->fetchColumn();
				if ($stockBefore === false) {
					throw new DomainException('Produk ' . $line['nama_barang'] . ' tidak ditemukan. Stok retur tidak dapat dikembalikan.');
				}
				$stockUpdate->execute(array($restockQuantity, $line['id_barang']));
				if ($stockUpdate->rowCount() !== 1) {
					throw new RuntimeException('Product stock changed during return inspection.');
				}
				record_stock_movement(
					$config,
					$line['id_barang'],
					'masuk',
					$restockQuantity,
					(int) $stockBefore,
					(int) $stockBefore + $restockQuantity,
					'Stok retur dikembalikan setelah inspeksi layak',
					$return['kode_pesanan'] . '-RET' . (int) $returnId,
					$memberId
				);
			}
			$updateReturnLine->execute(array($receivedQuantity, $restockQuantity, $inspectionNote !== '' ? $inspectionNote : null, (int) $line['id_detail_retur']));
			$receivedCount += $receivedQuantity;
			$restockCount += $restockQuantity;
			$receivedByProduct[(string) $line['id_barang']] = $receivedQuantity;
		}
		if ($receivedCount < 1) {
			throw new DomainException('Catat minimal satu unit barang yang benar-benar diterima.');
		}
		$config->prepare(
			"UPDATE retur_pesanan SET status = 'inspected', catatan_admin = ?, id_member_peninjau = ?, tanggal_pemeriksaan = ?, tanggal_update = ?
				WHERE id_retur = ? AND status = 'received'"
		)->execute(array($inspectionNote !== '' ? $inspectionNote : null, $memberId, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), (int) $returnId));
		$orderDetailQuery = $config->prepare(
			'SELECT * FROM detail_pesanan WHERE id_pesanan = ? ORDER BY id_barang FOR UPDATE'
		);
		$orderDetailQuery->execute(array((int) $return['id_pesanan']));
		$orderDetails = $orderDetailQuery->fetchAll(PDO::FETCH_ASSOC);
		$netLineSubtotals = order_net_line_subtotals(
			$orderDetails,
			(int) $return['diskon_voucher'],
			(int) $return['subtotal_produk']
		);
		$acceptedValue = 0;
		foreach ($orderDetails as $orderDetail) {
			$productId = (string) $orderDetail['id_barang'];
			if (array_key_exists($productId, $receivedByProduct)) {
				$acceptedValue += order_returnable_line_value(
					$orderDetail,
					$netLineSubtotals[$productId],
					$receivedByProduct[$productId]
				);
			}
		}
		if ($acceptedValue > 0) {
			refund_workflow_create_waiting($config, (int) $return['id_pesanan'], (int) $returnId, $memberId);
		}
		$refundMessage = $acceptedValue > 0
			? ' Nilai refund maksimal Rp ' . number_format($acceptedValue, 0, ',', '.') . ' menunggu pencatatan admin.'
			: ' Barang yang diterima tidak memiliki nilai refund setelah diskon voucher.';
		customer_workflow_notify($config, $return['id_pelanggan'], (int) $return['id_pesanan'], 'Pemeriksaan retur selesai', 'Toko menyelesaikan pemeriksaan retur pesanan ' . $return['kode_pesanan'] . '. Barang diterima: ' . $receivedCount . ' unit; layak dikembalikan ke stok: ' . $restockCount . ' unit.' . $refundMessage);
		customer_workflow_audit($config, $memberId, 'Inspect returned items', 'retur_pesanan', (int) $returnId, array('status' => 'received'), array('status' => 'inspected', 'jumlah_diterima' => $receivedCount, 'jumlah_stok_dikembalikan' => $restockCount, 'nilai_refund_maksimal' => $acceptedValue));
		$config->commit();
		header($redirect . '&result=return-updated');
		exit;
	}

	$refundQuery = $config->prepare(
		'SELECT refund.*, order_row.kode_pesanan, order_row.total AS total_pesanan,
				order_row.subtotal_produk, order_row.diskon_voucher, order_row.status_pembayaran, order_row.id_pelanggan
			FROM pengembalian_dana refund INNER JOIN pesanan order_row ON order_row.id_pesanan = refund.id_pesanan
			WHERE refund.id_pengembalian_dana = ? FOR UPDATE'
	);
	$refundQuery->execute(array((int) $refundId));
	$refund = $refundQuery->fetch(PDO::FETCH_ASSOC);
	if (!$refund) {
		$config->rollBack();
		header($redirect . '&result=invalid');
		exit;
	}

	if ($action === 'record_refund') {
		if (!in_array($refund['status'], array('waiting', 'rejected'), true)) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$nominal = filter_var($_POST['nominal'] ?? null, FILTER_VALIDATE_INT);
		$method = trim((string) ($_POST['metode_refund'] ?? ''));
		$reference = trim((string) ($_POST['referensi_transaksi'] ?? ''));
		$note = trim((string) ($_POST['note'] ?? ''));
		$dateInput = (string) ($_POST['tanggal_refund'] ?? '');
		$refundDate = DateTime::createFromFormat('Y-m-d\TH:i', $dateInput);
		if ($refundDate && $refundDate->format('Y-m-d\TH:i') !== $dateInput) $refundDate = false;
		if ($nominal === false || $nominal < 1 || $method === '' || strlen($method) > 60
			|| strlen($reference) > 120 || strlen($note) > 1000 || !$refundDate
			|| $refundDate > new DateTime()
			|| $nominal > (int) $refund['total_pesanan']) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$return = null;
		if ($refund['id_retur'] !== null) {
			$returnQuery = $config->prepare('SELECT * FROM retur_pesanan WHERE id_retur = ? FOR UPDATE');
			$returnQuery->execute(array((int) $refund['id_retur']));
			$return = $returnQuery->fetch(PDO::FETCH_ASSOC);
			if (!$return || $return['status'] !== 'inspected') {
				$config->rollBack();
				header($redirect . '&result=invalid');
				exit;
			}
			$orderDetailQuery = $config->prepare(
				'SELECT * FROM detail_pesanan WHERE id_pesanan = ? ORDER BY id_barang FOR UPDATE'
			);
			$orderDetailQuery->execute(array((int) $refund['id_pesanan']));
			$orderDetails = $orderDetailQuery->fetchAll(PDO::FETCH_ASSOC);
			$netLineSubtotals = order_net_line_subtotals(
				$orderDetails,
				(int) $refund['diskon_voucher'],
				(int) $refund['subtotal_produk']
			);
			$returnDetailQuery = $config->prepare(
				'SELECT detail_return.id_barang, detail_return.jumlah_diterima, detail_order.jumlah
					FROM detail_retur detail_return
					INNER JOIN detail_pesanan detail_order
						ON detail_order.id_pesanan = ? AND detail_order.id_barang = detail_return.id_barang
					WHERE detail_return.id_retur = ?'
			);
			$returnDetailQuery->execute(array((int) $refund['id_pesanan'], (int) $return['id_retur']));
			$acceptedValue = 0;
			foreach ($returnDetailQuery->fetchAll(PDO::FETCH_ASSOC) as $returnLine) {
				$productId = (string) $returnLine['id_barang'];
				if (!array_key_exists($productId, $netLineSubtotals)) {
					throw new DomainException('Return details do not match the saved order.');
				}
				$acceptedValue += order_returnable_line_value(
					$returnLine,
					$netLineSubtotals[$productId],
					(int) $returnLine['jumlah_diterima']
				);
			}
			if ($acceptedValue < 1 || $nominal > $acceptedValue) {
				$config->rollBack();
				header($redirect . '&result=invalid');
				exit;
			}
		} elseif ($refund['status_pembayaran'] !== 'refund_pending') {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$oldStatus = $refund['status'];
		$updateRefund = $config->prepare(
			"UPDATE pengembalian_dana SET nominal = ?, tanggal_refund = ?, metode_refund = ?,
				referensi_transaksi = ?, status = 'processing', catatan_admin = ?,
				id_member_pemroses = ?, id_member_verifikator = NULL, tanggal_verifikasi = NULL,
				tanggal_update = ? WHERE id_pengembalian_dana = ? AND status = ?"
		);
		$updateRefund->execute(array(
			(int) $nominal,
			$refundDate->format('Y-m-d H:i:s'),
			$method,
			$reference !== '' ? $reference : null,
			$note !== '' ? $note : null,
			$memberId,
			date('Y-m-d H:i:s'),
			(int) $refundId,
			$oldStatus
		));
		refund_workflow_record_status($config, (int) $refundId, $oldStatus, 'processing', $note !== '' ? $note : 'Refund dicatat; menunggu verifikasi setelah dana dikembalikan', $memberId);
		customer_workflow_notify($config, $refund['id_pelanggan'], (int) $refund['id_pesanan'], 'Pengembalian dana diproses', 'Refund pesanan ' . $refund['kode_pesanan'] . ' sebesar Rp ' . number_format((int) $nominal, 0, ',', '.') . ' sedang diproses dan menunggu verifikasi.');
		customer_workflow_audit($config, $memberId, 'Record order refund', 'pengembalian_dana', (int) $refundId, array('status' => $oldStatus), array('status' => 'processing', 'nominal' => (int) $nominal, 'metode' => $method, 'referensi' => $reference));
		$config->commit();
		header($redirect . '&result=refund-updated');
		exit;
	}

	if ($action === 'verify_refund') {
		if ($refund['status'] !== 'processing' || (int) $refund['nominal'] < 1
			|| !in_array($refund['status_pembayaran'], array('paid', 'refund_pending'), true)) {
			$config->rollBack();
			header($redirect . '&result=invalid');
			exit;
		}
		$config->prepare(
			"UPDATE pengembalian_dana SET status = 'success', id_member_verifikator = ?, tanggal_verifikasi = ?, tanggal_update = ?
				WHERE id_pengembalian_dana = ? AND status = 'processing'"
		)->execute(array($memberId, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), (int) $refundId));
		$config->prepare(
			"UPDATE pesanan SET status_pembayaran = CASE
				WHEN ? < total THEN 'partially_refunded'
				ELSE 'refunded' END
				WHERE id_pesanan = ? AND status_pembayaran IN ('paid', 'refund_pending')"
		)->execute(array((int) $refund['nominal'], (int) $refund['id_pesanan']));
		if ($refund['id_retur'] !== null) {
			$config->prepare(
				"UPDATE retur_pesanan SET status = 'refunded', tanggal_update = ? WHERE id_retur = ? AND status = 'inspected'"
			)->execute(array(date('Y-m-d H:i:s'), (int) $refund['id_retur']));
		}
		refund_workflow_record_status($config, (int) $refundId, 'processing', 'success', 'Admin mengonfirmasi dana benar-benar telah dikembalikan', $memberId);
		customer_workflow_notify($config, $refund['id_pelanggan'], (int) $refund['id_pesanan'], 'Pengembalian dana berhasil', 'Refund pesanan ' . $refund['kode_pesanan'] . ' sebesar Rp ' . number_format((int) $refund['nominal'], 0, ',', '.') . ' telah diverifikasi.');
		customer_workflow_audit($config, $memberId, 'Verify order refund success', 'pengembalian_dana', (int) $refundId, array('status' => 'processing'), array('status' => 'success', 'nominal' => (int) $refund['nominal']));
		$config->commit();
		header($redirect . '&result=refund-updated');
		exit;
	}

	$note = trim((string) ($_POST['note'] ?? ''));
	if (!in_array($refund['status'], array('waiting', 'processing'), true) || $note === '' || strlen($note) > 1000) {
		$config->rollBack();
		header($redirect . '&result=invalid');
		exit;
	}
	$config->prepare(
		"UPDATE pengembalian_dana SET status = 'rejected', catatan_admin = ?, id_member_pemroses = ?, tanggal_update = ?
			WHERE id_pengembalian_dana = ? AND status IN ('waiting', 'processing')"
	)->execute(array($note, $memberId, date('Y-m-d H:i:s'), (int) $refundId));
	refund_workflow_record_status($config, (int) $refundId, $refund['status'], 'rejected', $note, $memberId);
	customer_workflow_notify($config, $refund['id_pelanggan'], (int) $refund['id_pesanan'], 'Pengembalian dana ditolak', 'Refund pesanan ' . $refund['kode_pesanan'] . ' ditolak.' . ($note !== '' ? ' Catatan: ' . $note : ''));
	customer_workflow_audit($config, $memberId, 'Reject order refund', 'pengembalian_dana', (int) $refundId, array('status' => $refund['status']), array('status' => 'rejected', 'catatan' => $note));
	$config->commit();
	header($redirect . '&result=refund-updated');
	exit;
} catch (DomainException $exception) {
	if ($config->inTransaction()) $config->rollBack();
	error_log('Return/refund domain transition failed: ' . $exception->getMessage());
	header($redirect . '&result=invalid');
	exit;
} catch (Throwable $exception) {
	if ($config->inTransaction()) $config->rollBack();
	error_log('Return/refund processing failed: ' . $exception->getMessage());
	header($redirect . '&result=error');
	exit;
}
