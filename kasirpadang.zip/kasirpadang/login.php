<?php
ob_start();
require __DIR__ . '/fungsi/session.php';
start_secure_session();
$loginError = '';

if (!empty($_SESSION['admin']['id_member'])
	&& in_array($_SESSION['admin']['level'] ?? '', array('admin', 'pembeli'), true)) {
	header('Location: index.php');
	exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proses'])) {
	$loginUsername = trim((string) ($_POST['user'] ?? ''));
	$loginPassword = (string) ($_POST['pass'] ?? '');

	if (!valid_csrf_token($_POST['_csrf'] ?? null) || $loginUsername === '' || strlen($loginUsername) > 255 || $loginPassword === '' || strlen($loginPassword) > 4096) {
		$loginError = 'Username atau password salah.';
	} else {
		try {
			require 'config.php';
			$sql = 'SELECT member.*, login.id_login, login.user, login.pass, login.level
					FROM member INNER JOIN login ON member.id_member = login.id_member
					WHERE login.user = ? LIMIT 1';
			$row = $config->prepare($sql);
			$row->execute(array($loginUsername));
			$hasil = $row->fetch(PDO::FETCH_ASSOC);
			$storedPassword = $hasil ? trim((string) $hasil['pass']) : '';
			$passwordInfo = $storedPassword !== '' ? password_get_info($storedPassword) : array('algo' => null);
			$isPasswordHash = $passwordInfo['algo'] !== null && $passwordInfo['algo'] !== 0;
			$passwordMatches = $isPasswordHash
				? password_verify($loginPassword, $storedPassword)
				: ($storedPassword !== '' && hash_equals($storedPassword, md5($loginPassword)));

			if ($passwordMatches && in_array($hasil['level'], array('admin', 'pembeli'), true)) {
				if (!$isPasswordHash || password_needs_rehash($storedPassword, PASSWORD_DEFAULT)) {
					$updatePassword = $config->prepare('UPDATE login SET pass = ? WHERE id_login = ?');
					$updatePassword->execute(array(password_hash($loginPassword, PASSWORD_DEFAULT), (int) $hasil['id_login']));
				}
				session_regenerate_id(true);
				unset($hasil['pass'], $hasil['id_login']);
				$_SESSION['admin'] = $hasil;
				header('Location: index.php');
				exit;
			}
			$loginError = 'Username atau password salah.';
		} catch (Throwable $exception) {
			error_log('Login failed: ' . $exception->getMessage());
			$loginError = 'Login sedang tidak tersedia. Silakan coba kembali.';
		}
	}
}
?>
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Masuk ke sistem kasir dan inventaris toko ATK">

    <title>Masuk Admin &amp; Kasir | ATK Suka Suka</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/modern.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body class="login-page">
	  <div id="login-page">
	  	<div class="container">
		      <form class="form-login" method="POST">
	  	        <?php echo csrf_field();?>
	  	        <h2 class="form-login-heading">ATK Suka Suka</h2>
		        <div class="login-wrap">
		            <p class="login-intro">Masuk ke dashboard admin dan kasir toko.</p>
		            <?php if($loginError !== ''){?><div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($loginError, ENT_QUOTES, 'UTF-8');?></div><?php }?>
		            <label class="sr-only" for="login-user">Username</label>
		            <input id="login-user" type="text" class="form-control" name="user" placeholder="Username" autocomplete="username" maxlength="255" required autofocus>
		            <br>
		            <label class="sr-only" for="login-password">Password</label>
		            <input id="login-password" type="password" class="form-control" name="pass" placeholder="Password" autocomplete="current-password" maxlength="4096" required>
		            <br>
		            <button class="btn btn-primary btn-block" name="proses" type="submit"><i class="fa fa-lock"></i> Masuk</button>
		            <p class="text-center" style="margin-top:16px;"><a href="katalog_pelanggan.php"><i class="fa fa-arrow-left"></i> Kembali ke katalog pelanggan</a></p>
		        </div>
		      </form>	  	
	  	
	  	</div>
	  </div>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
  </body>
</html>
