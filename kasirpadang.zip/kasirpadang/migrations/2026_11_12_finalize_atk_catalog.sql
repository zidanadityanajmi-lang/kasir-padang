-- Jalankan pada db_toko setelah 2026_11_12_add_nota_transaction_snapshots.sql.
-- Harga merupakan estimasi awal dalam Rupiah; sesuaikan dengan pemasok setempat.
START TRANSACTION;

INSERT INTO `kategori` (`nama_kategori`, `tgl_input`)
SELECT seed.`nama_kategori`, DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
FROM (
  SELECT 'Alat Tulis (Pen, Pensil, Spidol)' AS `nama_kategori`
  UNION ALL SELECT 'Buku & Kertas (HVS, Buku Tulis)'
  UNION ALL SELECT 'Peralatan Kantor & Arsip'
  UNION ALL SELECT 'Perekat & Alat Pemotong'
  UNION ALL SELECT 'Perlengkapan Sekolah & Menggambar'
  UNION ALL SELECT 'Aksesoris Meja & Lainnya'
) AS seed
LEFT JOIN `kategori` existing ON existing.`nama_kategori` = seed.`nama_kategori`
WHERE existing.`id_kategori` IS NULL;

SET @cat_writing := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Alat Tulis (Pen, Pensil, Spidol)');
SET @cat_paper := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Buku & Kertas (HVS, Buku Tulis)');
SET @cat_office := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Peralatan Kantor & Arsip');
SET @cat_cutting := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Perekat & Alat Pemotong');
SET @cat_school := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Perlengkapan Sekolah & Menggambar');
SET @cat_accessories := (SELECT MIN(`id_kategori`) FROM `kategori` WHERE `nama_kategori` = 'Aksesoris Meja & Lainnya');

-- Gabungkan kategori ATK lama/duplikat ke enam kategori resmi.
UPDATE `barang` product
INNER JOIN `kategori` old_category ON old_category.`id_kategori` = product.`id_kategori`
SET product.`id_kategori` = CASE LOWER(old_category.`nama_kategori`)
  WHEN 'atk' THEN @cat_writing
  WHEN 'alat tulis' THEN @cat_writing
  WHEN 'alat tulis & menulis' THEN @cat_writing
  WHEN 'alat tulis (pen, pensil, spidol)' THEN @cat_writing
  WHEN 'alat tulis (pulpen, pensil, spidol)' THEN @cat_writing
  WHEN 'buku & kertas' THEN @cat_paper
  WHEN 'kertas & buku' THEN @cat_paper
  WHEN 'buku & kertas (hvs, buku tulis)' THEN @cat_paper
  WHEN 'buku & kertas (hvs, buku tulis, nota)' THEN @cat_paper
  WHEN 'peralatan arsip & filing' THEN @cat_office
  WHEN 'arsip & filing' THEN @cat_office
  WHEN 'peralatan kantor & arsip' THEN @cat_office
  WHEN 'peralatan arsip & filing (map, odner, klip)' THEN @cat_office
  WHEN 'peralatan meja & perekat' THEN @cat_cutting
  WHEN 'peralatan meja & kantor' THEN @cat_accessories
  WHEN 'peralatan meja & perekat (staples, lem, lakban)' THEN @cat_cutting
  WHEN 'perekat & alat pemotong' THEN @cat_cutting
  WHEN 'peralatan menggambar & seni' THEN @cat_school
  WHEN 'perlengkapan menggambar & presentasi' THEN @cat_school
  WHEN 'perlengkapan sekolah & menggambar' THEN @cat_school
  WHEN 'aksesoris meja & lainnya' THEN @cat_accessories
  ELSE product.`id_kategori`
END
WHERE LOWER(old_category.`nama_kategori`) IN (
  'atk', 'alat tulis', 'alat tulis & menulis', 'alat tulis (pen, pensil, spidol)',
  'alat tulis (pulpen, pensil, spidol)',
  'buku & kertas', 'kertas & buku', 'buku & kertas (hvs, buku tulis)',
  'buku & kertas (hvs, buku tulis, nota)',
  'peralatan arsip & filing', 'arsip & filing', 'peralatan kantor & arsip',
  'peralatan arsip & filing (map, odner, klip)',
  'peralatan meja & perekat', 'peralatan meja & kantor',
  'peralatan meja & perekat (staples, lem, lakban)', 'perekat & alat pemotong',
  'peralatan menggambar & seni', 'perlengkapan menggambar & presentasi',
  'perlengkapan sekolah & menggambar', 'aksesoris meja & lainnya'
);

-- Simpan jejak transaksi, lalu hapus barang dan kategori yang bukan ATK.
UPDATE `nota` receipt
INNER JOIN `barang` product ON product.`id_barang` = receipt.`id_barang`
SET receipt.`nama_barang_snapshot` = COALESCE(NULLIF(receipt.`nama_barang_snapshot`, ''), product.`nama_barang`),
    receipt.`harga_modal` = CASE
      WHEN receipt.`harga_modal` IS NULL OR receipt.`harga_modal` = '' THEN product.`harga_beli`
      ELSE receipt.`harga_modal`
    END
WHERE product.`id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_office, @cat_cutting, @cat_school, @cat_accessories);

DELETE cart
FROM `penjualan` cart
INNER JOIN `barang` product ON product.`id_barang` = cart.`id_barang`
WHERE product.`id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_office, @cat_cutting, @cat_school, @cat_accessories);

DELETE FROM `barang`
WHERE `id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_office, @cat_cutting, @cat_school, @cat_accessories);

DELETE FROM `kategori`
WHERE `id_kategori` NOT IN (@cat_writing, @cat_paper, @cat_office, @cat_cutting, @cat_school, @cat_accessories);

INSERT INTO `barang`
  (`id_barang`, `id_kategori`, `nama_barang`, `merk`, `harga_beli`, `harga_jual`, `satuan_barang`, `stok`, `tgl_input`)
SELECT products.`id_barang`, categories.`id_kategori`, products.`nama_barang`, products.`merk`,
       products.`harga_beli`, products.`harga_jual`, products.`satuan_barang`, products.`stok`,
       DATE_FORMAT(NOW(), '%e %M %Y, %H:%i')
FROM (
  SELECT 'ATK0001' AS `id_barang`, 'Alat Tulis (Pen, Pensil, Spidol)' AS `kategori`, 'Pulpen Standard AE7 Hitam' AS `nama_barang`, 'Standard' AS `merk`, 2000 AS `harga_beli`, 3000 AS `harga_jual`, 'PCS' AS `satuan_barang`, 100 AS `stok`
  UNION ALL SELECT 'ATK0002', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pulpen Pilot G-2 0.5 mm', 'Pilot', 9000, 12000, 'PCS', 24
  UNION ALL SELECT 'ATK0003', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pulpen Pilot BP-1RT', 'Pilot', 3500, 5000, 'PCS', 36
  UNION ALL SELECT 'ATK0004', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pulpen Faster C600', 'Faster', 1500, 2500, 'PCS', 48
  UNION ALL SELECT 'ATK0005', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pulpen Snowman V-5', 'Snowman', 6000, 8000, 'PCS', 20
  UNION ALL SELECT 'ATK0006', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pensil 2B', 'Faber-Castell', 2500, 3500, 'PCS', 40
  UNION ALL SELECT 'ATK0007', 'Alat Tulis (Pen, Pensil, Spidol)', 'Pensil Noris HB', 'Staedtler', 3000, 4000, 'PCS', 30
  UNION ALL SELECT 'ATK0008', 'Alat Tulis (Pen, Pensil, Spidol)', 'Spidol Permanent Hitam', 'Snowman', 4000, 5500, 'PCS', 24
  UNION ALL SELECT 'ATK0009', 'Alat Tulis (Pen, Pensil, Spidol)', 'Spidol Whiteboard Hitam', 'Joyko', 3500, 5000, 'PCS', 30
  UNION ALL SELECT 'ATK0010', 'Alat Tulis (Pen, Pensil, Spidol)', 'Highlighter Boss Kuning', 'Stabilo', 8500, 11000, 'PCS', 18
  UNION ALL SELECT 'ATK0011', 'Buku & Kertas (HVS, Buku Tulis)', 'Kertas HVS A4 70 gsm', 'PaperOne', 50000, 58000, 'RIM', 18
  UNION ALL SELECT 'ATK0012', 'Buku & Kertas (HVS, Buku Tulis)', 'Kertas HVS F4 70 gsm', 'Sinar Dunia', 46000, 54000, 'RIM', 16
  UNION ALL SELECT 'ATK0013', 'Buku & Kertas (HVS, Buku Tulis)', 'Buku Tulis 38 Lembar', 'Sinar Dunia', 2500, 3500, 'PCS', 60
  UNION ALL SELECT 'ATK0014', 'Buku & Kertas (HVS, Buku Tulis)', 'Buku Tulis 58 Lembar', 'Kiky', 4000, 5500, 'PCS', 48
  UNION ALL SELECT 'ATK0015', 'Buku & Kertas (HVS, Buku Tulis)', 'Buku Gambar A4', 'Kiky', 4500, 6500, 'PCS', 24
  UNION ALL SELECT 'ATK0016', 'Buku & Kertas (HVS, Buku Tulis)', 'Buku Catatan Spiral A5', 'Bantex', 10000, 14000, 'PCS', 15
  UNION ALL SELECT 'ATK0017', 'Buku & Kertas (HVS, Buku Tulis)', 'Buku Kas Folio 100 Lembar', 'Kiky', 18000, 24000, 'PCS', 10
  UNION ALL SELECT 'ATK0018', 'Buku & Kertas (HVS, Buku Tulis)', 'Kertas Folio Bergaris', 'Sinar Dunia', 38000, 46000, 'PAK', 12
  UNION ALL SELECT 'ATK0019', 'Buku & Kertas (HVS, Buku Tulis)', 'Kertas Buffalo Warna', 'Paperline', 22000, 30000, 'PAK', 8
  UNION ALL SELECT 'ATK0020', 'Buku & Kertas (HVS, Buku Tulis)', 'Kertas Origami 15 cm', 'Joyko', 8000, 12000, 'PAK', 20
  UNION ALL SELECT 'ATK0021', 'Peralatan Kantor & Arsip', 'Map Odner Folio', 'Bantex', 22000, 28000, 'PCS', 12
  UNION ALL SELECT 'ATK0022', 'Peralatan Kantor & Arsip', 'Map Plastik Kancing', 'Joyko', 2000, 3000, 'PCS', 50
  UNION ALL SELECT 'ATK0023', 'Peralatan Kantor & Arsip', 'Map Snelhecter Folio', 'Bantex', 3000, 4500, 'PCS', 35
  UNION ALL SELECT 'ATK0024', 'Peralatan Kantor & Arsip', 'Binder Clip No. 107', 'Joyko', 4000, 6000, 'BOX', 18
  UNION ALL SELECT 'ATK0025', 'Peralatan Kantor & Arsip', 'Paper Clip No. 3', 'Kenko', 3000, 5000, 'BOX', 16
  UNION ALL SELECT 'ATK0026', 'Peralatan Kantor & Arsip', 'Clear Holder A4 Isi 10', 'Bantex', 15000, 21000, 'PAK', 14
  UNION ALL SELECT 'ATK0027', 'Peralatan Kantor & Arsip', 'Ordner Besar A4', 'Bantex', 26000, 34000, 'PCS', 8
  UNION ALL SELECT 'ATK0028', 'Peralatan Kantor & Arsip', 'Laci Arsip Plastik 3 Susun', 'Lion Star', 48000, 62000, 'PCS', 5
  UNION ALL SELECT 'ATK0029', 'Peralatan Kantor & Arsip', 'Label Nama Putih', 'Tom & Jerry', 5000, 7500, 'PAK', 20
  UNION ALL SELECT 'ATK0030', 'Peralatan Kantor & Arsip', 'Amplop Cokelat Folio', 'Paperline', 18000, 25000, 'BOX', 10
  UNION ALL SELECT 'ATK0031', 'Perekat & Alat Pemotong', 'Lem Kertas Stick 25 gr', 'Kenko', 4000, 6000, 'PCS', 24
  UNION ALL SELECT 'ATK0032', 'Perekat & Alat Pemotong', 'Lem PVAc 40 gr', 'Fox', 5000, 7000, 'PCS', 18
  UNION ALL SELECT 'ATK0033', 'Perekat & Alat Pemotong', 'Lakban Bening 2 inch', 'Daimaru', 8000, 11000, 'ROLL', 18
  UNION ALL SELECT 'ATK0034', 'Perekat & Alat Pemotong', 'Lakban Cokelat 2 inch', 'Daimaru', 8500, 12000, 'ROLL', 15
  UNION ALL SELECT 'ATK0035', 'Perekat & Alat Pemotong', 'Double Tape 1 inch', 'Best Tape', 5000, 7500, 'ROLL', 20
  UNION ALL SELECT 'ATK0036', 'Perekat & Alat Pemotong', 'Cutter Besar L-500', 'Kenko', 7000, 10000, 'PCS', 12
  UNION ALL SELECT 'ATK0037', 'Perekat & Alat Pemotong', 'Pisau Cutter Besar', 'Kenko', 4000, 6000, 'BOX', 10
  UNION ALL SELECT 'ATK0038', 'Perekat & Alat Pemotong', 'Gunting Serbaguna 7 inch', 'Joyko', 7000, 10000, 'PCS', 14
  UNION ALL SELECT 'ATK0039', 'Perekat & Alat Pemotong', 'Correction Tape', 'Joyko', 4000, 6000, 'PCS', 24
  UNION ALL SELECT 'ATK0040', 'Perekat & Alat Pemotong', 'Lem UHU 35 ml', 'UHU', 12000, 16000, 'PCS', 8
  UNION ALL SELECT 'ATK0041', 'Perlengkapan Sekolah & Menggambar', 'Pensil Warna 12 Warna', 'Faber-Castell', 18000, 24000, 'SET', 12
  UNION ALL SELECT 'ATK0042', 'Perlengkapan Sekolah & Menggambar', 'Krayon 12 Warna', 'Titi', 12000, 17000, 'SET', 15
  UNION ALL SELECT 'ATK0043', 'Perlengkapan Sekolah & Menggambar', 'Cat Air 12 Warna', 'Joyko', 14000, 19000, 'SET', 10
  UNION ALL SELECT 'ATK0044', 'Perlengkapan Sekolah & Menggambar', 'Kuas Lukis 6 ukuran', 'Joyko', 16000, 22000, 'SET', 8
  UNION ALL SELECT 'ATK0045', 'Perlengkapan Sekolah & Menggambar', 'Penggaris 30 cm', 'Butterfly', 2500, 4000, 'PCS', 30
  UNION ALL SELECT 'ATK0046', 'Perlengkapan Sekolah & Menggambar', 'Penggaris Segitiga 30 cm', 'Joyko', 5000, 7500, 'SET', 12
  UNION ALL SELECT 'ATK0047', 'Perlengkapan Sekolah & Menggambar', 'Jangka Matematika', 'Joyko', 9000, 13000, 'SET', 10
  UNION ALL SELECT 'ATK0048', 'Perlengkapan Sekolah & Menggambar', 'Buku Kotak Matematika', 'Kiky', 4000, 6000, 'PCS', 20
  UNION ALL SELECT 'ATK0049', 'Perlengkapan Sekolah & Menggambar', 'Kertas Karton Warna', 'Sinar Dunia', 3000, 4500, 'PCS', 25
  UNION ALL SELECT 'ATK0050', 'Perlengkapan Sekolah & Menggambar', 'Kertas Origami 20 cm', 'Sidu', 12000, 17000, 'PAK', 14
  UNION ALL SELECT 'ATK0051', 'Aksesoris Meja & Lainnya', 'Stapler HD-10', 'Kenko', 14000, 19000, 'PCS', 12
  UNION ALL SELECT 'ATK0052', 'Aksesoris Meja & Lainnya', 'Isi Staples No. 10', 'Kenko', 1500, 2500, 'BOX', 40
  UNION ALL SELECT 'ATK0053', 'Aksesoris Meja & Lainnya', 'Tempat Pensil Meja', 'Deli', 18000, 25000, 'PCS', 8
  UNION ALL SELECT 'ATK0054', 'Aksesoris Meja & Lainnya', 'Dispenser Selotip Meja', 'Joyko', 12000, 17000, 'PCS', 7
  UNION ALL SELECT 'ATK0055', 'Aksesoris Meja & Lainnya', 'Tempat Dokumen 3 Susun', 'Lion Star', 45000, 60000, 'PCS', 5
  UNION ALL SELECT 'ATK0056', 'Aksesoris Meja & Lainnya', 'Tinta Stempel Biru', 'Kenko', 7000, 10000, 'PCS', 12
  UNION ALL SELECT 'ATK0057', 'Aksesoris Meja & Lainnya', 'Bantalan Stempel No. 1', 'Trodat', 10000, 14000, 'PCS', 8
  UNION ALL SELECT 'ATK0058', 'Aksesoris Meja & Lainnya', 'Kalkulator 12 Digit', 'Casio', 85000, 105000, 'PCS', 5
  UNION ALL SELECT 'ATK0059', 'Aksesoris Meja & Lainnya', 'Papan Jalan A4', 'Bantex', 12000, 17000, 'PCS', 10
  UNION ALL SELECT 'ATK0060', 'Aksesoris Meja & Lainnya', 'Tempat Kartu Nama Meja', 'Deli', 22000, 30000, 'PCS', 6
) AS products
INNER JOIN (
  SELECT MIN(`id_kategori`) AS `id_kategori`, `nama_kategori`
  FROM `kategori`
  GROUP BY `nama_kategori`
) categories ON categories.`nama_kategori` = products.`kategori`
WHERE NOT EXISTS (
  SELECT 1 FROM `barang` existing WHERE existing.`id_barang` = products.`id_barang`
);

UPDATE `toko` SET `nama_toko` = 'ATK Suka Suka' WHERE `id_toko` = 1;

COMMIT;