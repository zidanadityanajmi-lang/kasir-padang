<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<?php require_once __DIR__ . '/../../../../fungsi/product_image.php'; ?>
 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
<?php
	$id = isset($_GET['barang']) && is_string($_GET['barang']) ? trim($_GET['barang']) : '';
	$hasil = $id !== '' ? $lihat->barang_edit($id) : false;
	if (!$hasil) {
		http_response_code(404);
		echo '<section id="main-content"><section class="wrapper"><div class="alert alert-warning">Barang tidak ditemukan.</div></section></section>';
		return;
	}
?>
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-12 main-chart">
					  	<a href="index.php?page=barang"><button class="btn btn-primary"><i class="fa fa-angle-left"></i> Balik </button></a>
						<h3>Details Barang</h3>
						<?php if(isset($_GET['success'])){?>
						<div class="alert alert-success">
							<p>Edit Data Berhasil !</p>
						</div>
						<?php }?>
						<?php if(isset($_GET['error']) && $_GET['error'] === 'image'){?>
						<div class="alert alert-danger" role="alert">Foto produk gagal diunggah. Gunakan gambar JPG, JPEG, PNG, atau WebP maksimal 2 MB.</div>
						<?php }?>
						<?php if(isset($_GET['remove'])){?>
						<div class="alert alert-danger">
							<p>Hapus Data Berhasil !</p>
						</div>
						<?php }?>
						<form action="fungsi/edit/edit.php?barang=edit" method="POST" enctype="multipart/form-data">
								<?php echo csrf_field();?>
							<table class="table table-striped inventory-form-table">
								<tr>
									<td>ID Barang</td>
									<td><input type="text" readonly="readonly" class="form-control" value="<?php echo htmlspecialchars($hasil['id_barang'], ENT_QUOTES, 'UTF-8');?>" name="id"></td>
								</tr>
								<tr>
									<td>Kategori</td>
									<td>
									<select name="kategori" class="form-control" required>
										<option value="<?php echo htmlspecialchars($hasil['id_kategori'], ENT_QUOTES, 'UTF-8');?>" selected><?php echo htmlspecialchars($hasil['nama_kategori'], ENT_QUOTES, 'UTF-8');?></option>
										<?php $kat = $lihat -> kategori(); foreach($kat as $isi){ if($isi['id_kategori'] != $hasil['id_kategori']){ ?>
										<option value="<?php echo htmlspecialchars($isi['id_kategori'], ENT_QUOTES, 'UTF-8');?>"><?php echo htmlspecialchars($isi['nama_kategori'], ENT_QUOTES, 'UTF-8');?></option>
										<?php }}?>
									</select>
									</td>
								</tr>
								<tr>
									<td>Nama Barang</td>
									<td><input type="text" required class="form-control" value="<?php echo htmlspecialchars($hasil['nama_barang'], ENT_QUOTES, 'UTF-8');?>" name="nama"></td>
								</tr>
								<tr>
									<td>Merk Barang</td>
									<td><input type="text" required class="form-control" value="<?php echo htmlspecialchars($hasil['merk'], ENT_QUOTES, 'UTF-8');?>" name="merk"></td>
								</tr>
								<tr>
									<td>Deskripsi</td>
									<td><textarea class="form-control" name="deskripsi" maxlength="4000" rows="3" placeholder="Informasi singkat tentang produk (opsional)"><?php echo htmlspecialchars($hasil['deskripsi'] ?? '', ENT_QUOTES, 'UTF-8');?></textarea></td>
								</tr>
								<tr>
									<td>Foto Produk</td>
									<td>
										<?php
											$currentProductImage = basename((string) ($hasil['gambar'] ?? ''));
											$currentProductImagePath = __DIR__ . '/../../../../assets/img/produk/' . $currentProductImage;
											$currentProductImageHref = $currentProductImage !== '' && is_file($currentProductImagePath)
												? 'assets/img/produk/' . rawurlencode($currentProductImage) . '?v=' . (int) filemtime($currentProductImagePath)
												: product_image_placeholder($hasil['nama_kategori'] ?? '', $hasil['nama_barang'] ?? '', $hasil['merk'] ?? '');
										?>
										<div class="product-image-upload">
											<img class="product-image-preview" id="editProductImagePreview" src="<?php echo htmlspecialchars($currentProductImageHref, ENT_QUOTES, 'UTF-8');?>" alt="Foto <?php echo htmlspecialchars($hasil['nama_barang'], ENT_QUOTES, 'UTF-8');?>">
											<label class="sr-only" for="editProductImage">Ganti foto produk</label>
											<input type="file" class="form-control" id="editProductImage" name="gambar" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" data-product-image-input data-preview-target="#editProductImagePreview">
											<small>Opsional. JPG, JPEG, PNG, atau WebP maksimal 2 MB. Kosongkan untuk mempertahankan foto saat ini.</small>
										</div>
									</td>
								</tr>
								<tr>
									<td>Harga Beli</td>
									<td><input type="number" min="0" required class="form-control" value="<?php echo htmlspecialchars($hasil['harga_beli'], ENT_QUOTES, 'UTF-8');?>" name="beli"></td>
								</tr>
								<tr>
									<td>Harga Jual</td>
									<td><input type="number" min="0" required class="form-control" value="<?php echo htmlspecialchars($hasil['harga_jual'], ENT_QUOTES, 'UTF-8');?>" name="jual"></td>
								</tr>
								<tr>
									<td>Satuan Barang</td>
									<td>
										<?php $unitOptions = array('PCS' => 'Pcs', 'RIM' => 'Rim', 'KOTAK' => 'Kotak', 'PAK' => 'Pak', 'LUSIN' => 'Lusin', 'BATANG' => 'Batang', 'BOTOL' => 'Botol', 'SET' => 'Set', 'BOX' => 'Box', 'ROLL' => 'Roll'); ?>
										<select name="satuan" class="form-control" required>
											<?php if(!isset($unitOptions[$hasil['satuan_barang']])){?>
											<option value="<?php echo htmlspecialchars($hasil['satuan_barang'], ENT_QUOTES, 'UTF-8');?>" selected><?php echo htmlspecialchars($hasil['satuan_barang'], ENT_QUOTES, 'UTF-8');?></option>
											<?php } foreach($unitOptions as $unitValue => $unitLabel){?>
											<option value="<?php echo $unitValue;?>" <?php echo $hasil['satuan_barang'] === $unitValue ? 'selected' : '';?>><?php echo $unitLabel;?></option>
											<?php }?>
										</select>
									</td>
								</tr>
								<tr>
									<td>Stok</td>
									<td><input type="number" min="0" required class="form-control" value="<?php echo htmlspecialchars($hasil['stok'], ENT_QUOTES, 'UTF-8');?>" name="stok"></td>
								</tr>
								<tr>
									<td>Tanggal Update</td>
									<td><input type="text" readonly="readonly" class="form-control" value="<?php echo  date("j F Y, G:i");?>" name="tgl"></td>
								</tr>
								<tr>
									<td></td>
									<td><button class="btn btn-primary"><i class="fa fa-edit"></i> Update Data</button></td>
								</tr>
							</table>
						</form>
						<div class="clearfix" style="padding-top:16%;"></div>
				  </div>
              </div>
          </section>
      </section>
