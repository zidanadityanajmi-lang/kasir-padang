ALTER TABLE `nota`
  ADD COLUMN `kode_transaksi` varchar(32) DEFAULT NULL AFTER `id_nota`,
  ADD COLUMN `nama_barang_snapshot` text DEFAULT NULL AFTER `id_barang`;

UPDATE `nota` receipt
LEFT JOIN `barang` product ON product.`id_barang` = receipt.`id_barang`
SET receipt.`nama_barang_snapshot` = product.`nama_barang`,
    receipt.`harga_modal` = CASE
      WHEN receipt.`harga_modal` IS NULL OR receipt.`harga_modal` = ''
      THEN product.`harga_beli`
      ELSE receipt.`harga_modal`
    END
WHERE product.`id_barang` IS NOT NULL;
