<?php 
require __DIR__ . '/../session.php';
start_secure_session();
require_once __DIR__ . '/../stock_movement.php';
	if (empty($_SESSION['admin']['id_member']) || !isset($_SESSION['admin']['level']) || !in_array($_SESSION['admin']['level'], array('admin', 'pembeli'), true)) {
		http_response_code(401);
	exit('Silakan login kembali.');
}
	$role = $_SESSION['admin']['level'];
	$adminActions = array('pengaturan', 'kategori', 'stok', 'barang', 'gambar', 'profil', 'pass');
	if ($role !== 'admin') {
		foreach ($adminActions as $action) {
			if (isset($_GET[$action])) {
				http_response_code(403);
				exit('Akses ditolak.');
			}
		}
	}
	$mutatingActions = array('pengaturan', 'kategori', 'stok', 'barang', 'gambar', 'profil', 'pass', 'jual');
	foreach ($mutatingActions as $action) {
		if (isset($_GET[$action])) {
			if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
				http_response_code(405);
				exit('Metode permintaan tidak diizinkan.');
			}
			if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
				http_response_code(403);
				exit('Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.');
			}
		}
	}
	{
	require '../../config.php';
	require_once __DIR__ . '/../product_image.php';
	if(!empty($_GET['pengaturan'])){
		$nama = trim((string) ($_POST['namatoko'] ?? ''));
		$alamat = trim((string) ($_POST['alamat'] ?? ''));
		$kontak = trim((string) ($_POST['kontak'] ?? ''));
		$pemilik = trim((string) ($_POST['pemilik'] ?? ''));
		if ($nama === '' || strlen($nama) > 255 || strlen($alamat) > 10000 || strlen($kontak) > 255 || strlen($pemilik) > 255) {
			http_response_code(400);
			exit('Data toko tidak valid.');
		}
		$id = '1';
		
		$data[] = $nama;
		$data[] = $alamat;
		$data[] = $kontak;
		$data[] = $pemilik;
		$data[] = $id;
		$sql = 'UPDATE toko SET nama_toko=?, alamat_toko=?, tlp=?, nama_pemilik=? WHERE id_toko = ?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=pengaturan&success=edit-data"</script>';
	}

	if(!empty($_GET['kategori'])){
		$nama = trim((string) ($_POST['kategori'] ?? ''));
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		if ($nama === '' || strlen($nama) > 255 || $id === false) {
			header('Location: ../../index.php?page=kategori&error=validation');
			exit;
		}
		$duplicateCategory = $config->prepare('SELECT 1 FROM kategori WHERE nama_kategori = ? AND id_kategori <> ? LIMIT 1');
		$duplicateCategory->execute(array($nama, $id));
		if ($duplicateCategory->fetchColumn()) {
			header('Location: ../../index.php?page=kategori&uid=' . (int) $id . '&error=duplicate');
			exit;
		}
		$data[] = $nama;
		$data[] = $id;
		$sql = 'UPDATE kategori SET  nama_kategori=? WHERE id_kategori=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=kategori&uid='.$id.'&success-edit=edit-data"</script>';
	}

	if(!empty($_GET['stok'])){
		$id = trim((string) ($_POST['id'] ?? ''));
		$restock = filter_var($_POST['restok'] ?? null, FILTER_VALIDATE_INT);
		if ($id === '' || $restock === false || $restock < 1) {
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}

		try {
			$config->beginTransaction();
			$stockQuery = $config->prepare('SELECT stok FROM barang WHERE id_barang = ? FOR UPDATE');
			$stockQuery->execute(array($id));
			$currentStock = $stockQuery->fetchColumn();
			if ($currentStock === false) {
				$config->rollBack();
				header('Location: ../../index.php?page=barang&error=notfound');
				exit;
			}

			$updateStock = $config->prepare('UPDATE barang SET stok = ? WHERE id_barang = ?');
			$updateStock->execute(array((int) $currentStock + $restock, $id));
			record_stock_movement(
				$config,
				$id,
				'masuk',
				$restock,
				(int) $currentStock,
				(int) $currentStock + $restock,
				'Restock manual',
				null,
				(int) $_SESSION['admin']['id_member']
			);
			$config->commit();
			$returnPage = isset($_POST['return_page']) && $_POST['return_page'] === 'dashboard' ? 'dashboard' : 'barang';
			header('Location: ../../index.php?page=' . $returnPage . ($returnPage === 'barang' ? '&success-stok=stok-data' : '&success-stok=1'));
			exit;
		} catch (Exception $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			error_log('Inventory restock failed: ' . $exception->getMessage());
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}
	}

	if(!empty($_GET['barang'])){
		$id = trim((string) ($_POST['id'] ?? ''));
		$kategori = filter_var($_POST['kategori'] ?? null, FILTER_VALIDATE_INT);
		$nama = trim((string) ($_POST['nama'] ?? ''));
		$merk = trim((string) ($_POST['merk'] ?? ''));
		$deskripsi = trim((string) ($_POST['deskripsi'] ?? ''));
		$beli = filter_var($_POST['beli'] ?? null, FILTER_VALIDATE_INT);
		$jual = filter_var($_POST['jual'] ?? null, FILTER_VALIDATE_INT);
		$satuan = strtoupper(trim((string) ($_POST['satuan'] ?? '')));
		$stok = filter_var($_POST['stok'] ?? null, FILTER_VALIDATE_INT);
		$units = array('PCS', 'RIM', 'KOTAK', 'PAK', 'LUSIN', 'BATANG', 'BOTOL', 'SET', 'BOX', 'ROLL');

		if ($id === '' || $kategori === false || $nama === '' || $merk === '' || strlen($deskripsi) > 4000 || $beli === false || $beli < 0 || $jual === false || $jual < 0 || $stok === false || $stok < 0 || !in_array($satuan, $units, true)) {
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}
		$categoryQuery = $config->prepare('SELECT id_kategori FROM kategori WHERE id_kategori = ?');
		$categoryQuery->execute(array($kategori));
		if (!$categoryQuery->fetchColumn()) {
			header('Location: ../../index.php?page=barang&error=validation');
			exit;
		}

		$currentImageQuery = $config->prepare('SELECT gambar, stok FROM barang WHERE id_barang = ? LIMIT 1');
		$currentImageQuery->execute(array($id));
		$currentProduct = $currentImageQuery->fetch(PDO::FETCH_ASSOC);
		if (!$currentProduct) {
			header('Location: ../../index.php?page=barang&error=notfound');
			exit;
		}
		try {
			$newImage = save_product_image_upload('gambar');
		} catch (RuntimeException $exception) {
			header('Location: ../../index.php?page=barang/edit&barang=' . rawurlencode($id) . '&error=image');
			exit;
		}
		$currentImage = (string) ($currentProduct['gambar'] ?? '');
		$stockBefore = (int) $currentProduct['stok'];
		$imageName = $newImage !== null ? $newImage : $currentImage;
		$sql = 'UPDATE barang SET id_kategori=?, nama_barang=?, merk=?, deskripsi=?, harga_beli=?, harga_jual=?, satuan_barang=?, stok=?, tgl_update=?, gambar=? WHERE id_barang=?';
		$row = $config->prepare($sql);
		try {
			$config->beginTransaction();
			$row->execute(array($kategori, $nama, $merk, $deskripsi !== '' ? $deskripsi : null, $beli, $jual, $satuan, $stok, date('j F Y, G:i'), $imageName, $id));
			if ((int) $stok !== $stockBefore) {
				record_stock_movement(
					$config,
					$id,
					'penyesuaian',
					abs((int) $stok - $stockBefore),
					$stockBefore,
					(int) $stok,
					'Penyesuaian stok melalui edit produk',
					null,
					(int) $_SESSION['admin']['id_member']
				);
			}
			$config->commit();
		} catch (PDOException $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			if ($newImage !== null) {
					delete_product_image($newImage, $config);
			}
			throw $exception;
		} catch (Throwable $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			if ($newImage !== null) {
				delete_product_image($newImage, $config);
			}
			throw $exception;
		}
		if ($newImage !== null && $currentImage !== '') {
				delete_product_image($currentImage, $config);
		}
		header('Location: ../../index.php?page=barang/edit&barang=' . rawurlencode($id) . '&success=edit-data');
		exit;
	}

	if(!empty($_GET['gambar'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		$file = $_FILES['foto'] ?? null;
		if ($id === false || !$file || $file['error'] !== UPLOAD_ERR_OK || $file['size'] < 1 || $file['size'] > 4 * 1024 * 1024) {
			http_response_code(400);
			exit('Pilih gambar berukuran maksimal 4 MB.');
		}

		$imageInfo = getimagesize($file['tmp_name']);
		$fileInfo = new finfo(FILEINFO_MIME_TYPE);
		$mimeType = $fileInfo->file($file['tmp_name']);
		$extensions = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif');
		if (!$imageInfo || !isset($extensions[$mimeType])) {
			http_response_code(400);
			exit('Format gambar harus JPG, PNG, atau GIF.');
		}

		$imageDirectory = __DIR__ . '/../../assets/img/user/';
		$newImage = bin2hex(random_bytes(16)) . '.' . $extensions[$mimeType];
		$targetPath = $imageDirectory . $newImage;
		if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
			http_response_code(500);
			exit('Gambar gagal disimpan.');
		}

		$updateImage = $config->prepare('UPDATE member SET gambar = ? WHERE id_member = ?');
		$updateImage->execute(array($newImage, $id));
		$oldImage = basename((string) ($_POST['foto2'] ?? ''));
		if ($oldImage !== '' && $oldImage !== $newImage && is_file($imageDirectory . $oldImage)) {
			unlink($imageDirectory . $oldImage);
		}
		header('Location: ../../index.php?page=user&success=edit-data');
		exit;
	}

	if(!empty($_GET['profil'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		$nama = trim((string) ($_POST['nama'] ?? ''));
		$alamat = trim((string) ($_POST['alamat'] ?? ''));
		$tlp = trim((string) ($_POST['tlp'] ?? ''));
		$email = trim((string) ($_POST['email'] ?? ''));
		$nik = trim((string) ($_POST['nik'] ?? ''));
		if ($id === false || $nama === '' || strlen($nama) > 255 || strlen($alamat) > 10000 || strlen($tlp) > 255 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 255 || strlen($nik) > 255) {
			http_response_code(400);
			exit('Data profil tidak valid.');
		}
		
		$data[] = $nama;
		$data[] = $alamat;
		$data[] = $tlp;
		$data[] = $email;
		$data[] = $nik;
		$data[] = $id;
		$sql = 'UPDATE member SET nm_member=?,alamat_member=?,telepon=?,email=?,NIK=? WHERE id_member=?';
		$row = $config -> prepare($sql);
		$row -> execute($data);
		echo '<script>window.location="../../index.php?page=user&success=edit-data"</script>';
	}
	if(!empty($_GET['pass'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		$user = trim((string) ($_POST['user'] ?? ''));
		$pass = (string) ($_POST['pass'] ?? '');
		if ($id === false || $user === '' || strlen($user) > 255 || strlen($pass) < 8 || strlen($pass) > 4096) {
			http_response_code(400);
			exit('Username atau password baru tidak memenuhi ketentuan.');
		}
		$duplicateUser = $config->prepare('SELECT 1 FROM login WHERE user = ? AND id_member <> ? LIMIT 1');
		$duplicateUser->execute(array($user, $id));
		if ($duplicateUser->fetchColumn()) {
			http_response_code(409);
			exit('Username sudah digunakan.');
		}
		$updateLogin = $config->prepare('UPDATE login SET user = ?, pass = ? WHERE id_member = ?');
		$updateLogin->execute(array($user, password_hash($pass, PASSWORD_DEFAULT), $id));
		echo '<script>window.location="../../index.php?page=user&success=edit-data"</script>';
	}

	if(!empty($_GET['jual'])){
		$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
		$idBarang = trim($_POST['id_barang'] ?? '');
		$memberId = (int) $_SESSION['admin']['id_member'];
		if ($id === false || $idBarang === '') {
			header('Location: ../../index.php?page=jual&error=cart#keranjang');
			exit;
		}

		try {
			$config->beginTransaction();
			$memberLock = $config->prepare('SELECT id_member FROM member WHERE id_member = ? FOR UPDATE');
			$memberLock->execute(array($memberId));
			$productQuery = $config->prepare('SELECT id_barang, nama_barang, stok, harga_jual FROM barang WHERE id_barang = ? FOR UPDATE');
			$productQuery->execute(array($idBarang));
			$product = $productQuery->fetch(PDO::FETCH_ASSOC);
			$cartQuery = $config->prepare('SELECT id_penjualan, id_barang, jumlah FROM penjualan WHERE id_penjualan = ? AND id_member = ? FOR UPDATE');
			$cartQuery->execute(array($id, $memberId));
			$cartRow = $cartQuery->fetch(PDO::FETCH_ASSOC);
			if (!$product || !$cartRow || $cartRow['id_barang'] !== $product['id_barang']) {
				$config->rollBack();
				header('Location: ../../index.php?page=jual&error=cart#keranjang');
				exit;
			}

			if (isset($_POST['delta'])) {
				$delta = filter_var($_POST['delta'], FILTER_VALIDATE_INT);
				if (!in_array($delta, array(-1, 1), true)) {
					throw new RuntimeException('Invalid quantity adjustment');
				}
				$quantity = (int) $cartRow['jumlah'] + $delta;
			}else{
				$quantity = filter_var($_POST['jumlah'] ?? null, FILTER_VALIDATE_INT);
			}

			if ($quantity === false || $quantity < 1) {
				$config->rollBack();
				header('Location: ../../index.php?page=jual&error=minqty#keranjang');
				exit;
			}
			if ($quantity > (int) $product['stok']) {
				$config->rollBack();
				header('Location: ../../index.php?page=jual&error=stock&barang=' . rawurlencode($product['nama_barang']) . '#keranjang');
				exit;
			}

			$total = (int) $product['harga_jual'] * (int) $quantity;
			$updateCart = $config->prepare('UPDATE penjualan SET jumlah = ?, total = ? WHERE id_penjualan = ? AND id_member = ?');
			$updateCart->execute(array($quantity, $total, $id, $memberId));
			$config->commit();
			header('Location: ../../index.php?page=jual&success=updated#keranjang');
			exit;
		} catch (Exception $exception) {
			if ($config->inTransaction()) {
				$config->rollBack();
			}
			error_log('POS cart update failed: ' . $exception->getMessage());
			header('Location: ../../index.php?page=jual&error=checkout#keranjang');
			exit;
		}
	}

	if(!empty($_GET['cari_barang'])){
		$cari = trim($_POST['keyword'] ?? '');
		if($cari !== ''){
			$keyword = '%' . $cari . '%';
			$sql = 'SELECT barang.*, kategori.id_kategori, kategori.nama_kategori
					FROM barang INNER JOIN kategori ON barang.id_kategori = kategori.id_kategori
					WHERE barang.id_barang LIKE ? OR barang.nama_barang LIKE ? OR barang.merk LIKE ?
					ORDER BY barang.nama_barang LIMIT 30';
			$row = $config->prepare($sql);
			$row->execute(array($keyword, $keyword, $keyword));
			$hasil1 = $row->fetchAll(PDO::FETCH_ASSOC);
	?>
			<?php if($hasil1){?>
				<table class="table inventory-search-table" width="100%">
					<thead><tr><th>Kode</th><th>Nama Barang</th><th>Merk</th><th>Stok</th><th>Harga</th><th>Aksi</th></tr></thead>
					<tbody>
					<?php foreach($hasil1 as $hasil){?>
						<tr>
							<td><?php echo htmlspecialchars($hasil['id_barang'], ENT_QUOTES, 'UTF-8');?></td>
							<td><?php echo htmlspecialchars($hasil['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
							<td><?php echo htmlspecialchars($hasil['merk'], ENT_QUOTES, 'UTF-8');?></td>
							<td><?php echo htmlspecialchars($hasil['stok'], ENT_QUOTES, 'UTF-8');?> <?php echo htmlspecialchars($hasil['satuan_barang'], ENT_QUOTES, 'UTF-8');?></td>
							<td>Rp.<?php echo number_format((int) $hasil['harga_jual']);?></td>
							<td>
								<?php if((int) $hasil['stok'] > 0){?>
									<form method="POST" action="fungsi/tambah/tambah.php?jual=jual" class="pos-search-add-form">
										<?php echo csrf_field();?>
										<input type="hidden" name="id" value="<?php echo htmlspecialchars($hasil['id_barang'], ENT_QUOTES, 'UTF-8');?>">
										<input type="hidden" name="id_barang" value="<?php echo htmlspecialchars($hasil['id_barang'], ENT_QUOTES, 'UTF-8');?>">
										<button type="submit" class="btn btn-success btn-sm" title="Tambah ke keranjang"><i class="fa fa-cart-plus" aria-hidden="true"></i><span class="sr-only">Tambah ke keranjang</span></button>
									</form>
								<?php }else{?>
									<span class="label label-danger">Stok habis</span>
								<?php }?>
							</td>
						</tr>
					<?php }?>
					</tbody>
				</table>
			<?php }else{?>
				<p class="search-empty">Barang tidak ditemukan.</p>
			<?php }?>
<?php	
		}
	}
}
