<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code(403);
	exit('Permintaan logout tidak valid.');
}
$_SESSION = array();
if (ini_get('session.use_cookies')) {
	$cookie = session_get_cookie_params();
	setcookie(session_name(), '', time() - 42000, $cookie['path'], $cookie['domain'], $cookie['secure'], $cookie['httponly']);
}
session_destroy();
header('Location: login.php');
exit;
?>
