<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin'])) {
	header('Location: login.php');
	exit;
}

$receipt = $_SESSION['last_receipt'] ?? null;
if (!isset($_GET['receipt']) || $_GET['receipt'] !== 'last' || !$receipt) {
	header('Location: index.php?page=jual');
	exit;
}

require 'config.php';
include $view;
$lihat = new view($config);
$toko = $lihat->toko();
?>
<!DOCTYPE html>
<html lang="id">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Nota #<?php echo (int) $receipt['number'];?></title>
		<link rel="stylesheet" href="assets/css/bootstrap.css">
		<style>
			body { color: #202a24; font-family: Arial, sans-serif; }
			.receipt { width: 80mm; max-width: 100%; margin: 24px auto; padding: 20px; }
			.receipt-header { padding-bottom: 14px; border-bottom: 1px dashed #9ba79f; text-align: center; }
			.receipt-header h1 { margin: 0 0 8px; font-size: 19px; font-weight: 700; }
			.receipt-header p { margin: 3px 0; font-size: 11px; }
			.receipt-meta { display: flex; justify-content: space-between; gap: 12px; margin: 12px 0; font-size: 11px; }
			.receipt-lines { width: 100%; font-size: 11px; }
			.receipt-lines th, .receipt-lines td { padding: 7px 4px; }
			.receipt-lines th:last-child, .receipt-lines td:last-child { text-align: right; white-space: nowrap; }
			.receipt-total { padding-top: 10px; border-top: 1px dashed #9ba79f; text-align: right; font-size: 11px; line-height: 1.8; }
			.receipt-total strong { font-size: 14px; }
			.receipt-thanks { margin-top: 16px; text-align: center; font-size: 11px; }
			@page { size: 80mm auto; margin: 4mm; }
			@media print { .receipt { width: 72mm; max-width: none; margin: 0 auto; padding: 0; } }
		</style>
	</head>
	<body>
		<div class="receipt">
			<header class="receipt-header">
				<h1><?php echo htmlspecialchars($toko['nama_toko'], ENT_QUOTES, 'UTF-8');?></h1>
				<p><?php echo htmlspecialchars($toko['alamat_toko'], ENT_QUOTES, 'UTF-8');?></p>
			</header>
			<div class="receipt-meta">
				<span>Nota #<?php echo (int) $receipt['number'];?></span>
				<span><?php echo htmlspecialchars($receipt['date'], ENT_QUOTES, 'UTF-8');?></span>
			</div>
			<p style="font-size:11px;">Kasir: <?php echo htmlspecialchars($receipt['cashier'], ENT_QUOTES, 'UTF-8');?></p>
			<?php if (!empty($receipt['customer_name'])) { ?>
				<p style="font-size:11px;">Pelanggan: <?php echo htmlspecialchars($receipt['customer_name'], ENT_QUOTES, 'UTF-8');?></p>
				<p style="font-size:11px;">No. HP: <?php echo htmlspecialchars($receipt['customer_phone'] ?? '', ENT_QUOTES, 'UTF-8');?></p>
				<?php if (!empty($receipt['order_code'])) { ?><p style="font-size:11px;">Kode pesanan: <?php echo htmlspecialchars($receipt['order_code'], ENT_QUOTES, 'UTF-8');?></p><?php } ?>
			<?php } ?>
			<table class="receipt-lines">
				<thead><tr><th>Barang</th><th>Qty</th><th>Total</th></tr></thead>
				<tbody>
				<?php foreach ($receipt['rows'] as $line) { ?>
					<tr>
						<td><?php echo htmlspecialchars($line['nama_barang'], ENT_QUOTES, 'UTF-8');?></td>
						<td><?php echo (int) $line['jumlah'];?></td>
						<td>Rp <?php echo number_format((int) $line['total'], 0, ',', '.');?></td>
					</tr>
				<?php } ?>
				</tbody>
			</table>
			<div class="receipt-total">
				<div>Total: Rp <?php echo number_format((int) $receipt['total'], 0, ',', '.');?></div>
				<div>Bayar: Rp <?php echo number_format((int) $receipt['paid'], 0, ',', '.');?></div>
				<strong>Kembali: Rp <?php echo number_format((int) $receipt['change'], 0, ',', '.');?></strong>
			</div>
			<p class="receipt-thanks">Terima kasih telah berbelanja.</p>
		</div>
		<script>window.print();</script>
	</body>
</html>
