<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(404); exit; } ?>
<section id="main-content">
	<section class="wrapper">
		<div class="page-heading inventory-page-heading">
			<div><p class="dashboard-eyebrow">Inventaris &amp; katalog</p><h1>Tambah Kategori</h1></div>
		</div>

		<?php
			$categoryErrors = array(
				'validation' => 'Nama kategori wajib diisi dan maksimal 255 karakter.',
				'duplicate' => 'Nama kategori sudah digunakan.'
			);
			$errorCode = isset($_GET['error']) && is_string($_GET['error']) ? $_GET['error'] : '';
			if (isset($categoryErrors[$errorCode])) {
		?>
			<div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($categoryErrors[$errorCode], ENT_QUOTES, 'UTF-8');?></div>
		<?php } ?>

		<div class="dashboard-card inventory-form-card inventory-category-form-card">
			<form action="fungsi/tambah/tambah.php?kategori=tambah" method="POST">
				<?php echo csrf_field();?>
				<div class="form-group">
					<label for="categoryName">Nama Kategori</label>
					<input type="text" id="categoryName" name="kategori" class="form-control" maxlength="255" required autofocus placeholder="Contoh: Alat Tulis &amp; Menulis">
				</div>
				<div class="inventory-form-actions">
					<a class="btn btn-default" href="index.php?page=kategori">Batal</a>
					<button type="submit" class="btn btn-primary"><i class="fa fa-check" aria-hidden="true"></i> Simpan Kategori</button>
				</div>
			</form>
		</div>
	</section>
</section>
