<?php
require __DIR__ . '/fungsi/session.php';
start_secure_session();
require __DIR__ . '/config.php';
require_once __DIR__ . '/fungsi/customer_account.php';

if (customer_account_session()) {
	header('Location: profil_pelanggan.php');
	exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$name = trim((string) ($_POST['nama_pelanggan'] ?? ''));
	$email = strtolower(trim((string) ($_POST['email'] ?? '')));
	$phone = trim((string) ($_POST['no_hp'] ?? ''));
	$address = trim((string) ($_POST['alamat'] ?? ''));
	$password = (string) ($_POST['password'] ?? '');
	$passwordConfirmation = (string) ($_POST['password_confirmation'] ?? '');
	if (!valid_csrf_token($_POST['_csrf'] ?? null)) {
		$error = 'Sesi formulir tidak valid. Muat ulang halaman dan coba kembali.';
	} elseif ($name === '' || strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190
		|| !customer_account_phone_is_valid($phone) || strlen($phone) > 30 || strlen($address) > 2000
		|| strlen($password) < 8 || strlen($password) > 4096 || $password !== $passwordConfirmation) {
		$error = 'Periksa nama, email, nomor WhatsApp, alamat, serta password (minimal 8 karakter dan harus sama).';
	} else {
		try {
			$insert = $config->prepare(
				"INSERT INTO pelanggan (nama_pelanggan, email, no_hp, alamat, password_hash, status, tanggal_daftar)
					VALUES (?, ?, ?, ?, ?, 'active', ?)"
			);
			$insert->execute(array(
				$name,
				$email,
				$phone,
				$address !== '' ? $address : null,
				password_hash($password, PASSWORD_DEFAULT),
				date('Y-m-d H:i:s')
			));
			session_regenerate_id(true);
			$_SESSION['customer'] = array(
				'id_pelanggan' => (int) $config->lastInsertId(),
				'nama_pelanggan' => $name,
				'email' => $email,
				'no_hp' => $phone,
				'alamat' => $address
			);
			header('Location: profil_pelanggan.php?success=registered');
			exit;
		} catch (PDOException $exception) {
			if ($exception->getCode() === '23000') {
				$error = 'Email tersebut sudah terdaftar. Silakan masuk atau gunakan email lain.';
			} else {
				error_log('Customer registration failed: ' . $exception->getMessage());
				$error = 'Pendaftaran belum dapat diproses. Silakan coba kembali beberapa saat lagi.';
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Daftar Pelanggan | ATK Suka Suka</title>
	<link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="assets/css/storefront.css" rel="stylesheet">
</head>
<body>
	<div class="shop-promo"><div class="shop-container shop-promo-inner"><span>ATK Suka Suka</span><a href="katalog_pelanggan.php">Kembali ke katalog</a></div></div>
	<main class="shop-container order-history-page">
		<div class="section-heading"><div><span class="section-kicker">Akun pelanggan</span><h1>Daftar</h1><p>Buat akun untuk memudahkan melihat pesanan dan memperbarui informasi kontak.</p></div></div>
		<?php if ($error !== '') { ?><div class="shop-notice shop-notice-danger" role="alert"><?php echo customer_account_escape($error);?></div><?php } ?>
		<form class="order-lookup-form" method="POST" action="daftar_pelanggan.php">
			<?php echo csrf_field();?>
			<label for="customerName">Nama lengkap</label>
			<input id="customerName" name="nama_pelanggan" maxlength="120" autocomplete="name" required value="<?php echo customer_account_escape($_POST['nama_pelanggan'] ?? '');?>">
			<label for="customerEmail">Email</label>
			<input id="customerEmail" type="email" name="email" maxlength="190" autocomplete="email" required value="<?php echo customer_account_escape($_POST['email'] ?? '');?>">
			<label for="customerPhone">Nomor WhatsApp</label>
			<input id="customerPhone" type="tel" name="no_hp" maxlength="30" autocomplete="tel" required value="<?php echo customer_account_escape($_POST['no_hp'] ?? '');?>">
			<label for="customerAddress">Alamat</label>
			<textarea id="customerAddress" name="alamat" maxlength="2000" autocomplete="street-address"><?php echo customer_account_escape($_POST['alamat'] ?? '');?></textarea>
			<label for="customerPassword">Password (minimal 8 karakter)</label>
			<input id="customerPassword" type="password" name="password" minlength="8" maxlength="4096" autocomplete="new-password" required>
			<label for="customerPasswordConfirmation">Ulangi password</label>
			<input id="customerPasswordConfirmation" type="password" name="password_confirmation" minlength="8" maxlength="4096" autocomplete="new-password" required>
			<button class="store-button" type="submit"><i class="fa fa-user-plus" aria-hidden="true"></i> Buat Akun</button>
		</form>
		<p>Sudah mempunyai akun? <a href="masuk_pelanggan.php">Masuk di sini</a>.</p>
	</main>
	<footer class="shop-footer"><div class="shop-container footer-bottom"><a href="riwayat_pesanan.php">Cek pesanan tanpa akun</a><a href="katalog_pelanggan.php#kontak">Kontak toko</a></div></footer>
</body>
</html>
