<?php
require __DIR__ . '/../../../fungsi/session.php';
start_secure_session();
if (empty($_SESSION['admin']['id_member']) || ($_SESSION['admin']['level'] ?? '') !== 'admin') {
	http_response_code(403);
	exit('Akses ditolak.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !valid_csrf_token($_POST['_csrf'] ?? null)) {
	http_response_code($_SERVER['REQUEST_METHOD'] === 'POST' ? 403 : 405);
	exit('Permintaan tidak valid.');
}
$reviewId = filter_var($_POST['review_id'] ?? null, FILTER_VALIDATE_INT);
$status = (string) ($_POST['status'] ?? '');
$note = trim((string) ($_POST['note'] ?? ''));
if ($reviewId === false || $reviewId < 1 || !in_array($status, array('approved', 'rejected'), true)
	|| ($status === 'rejected' && $note === '') || strlen($note) > 500) {
	header('Location: ../../../index.php?page=ulasan&result=invalid');
	exit;
}
require __DIR__ . '/../../../config.php';
require_once __DIR__ . '/../../../fungsi/customer_workflows.php';
try {
	$config->beginTransaction();
	$reviewQuery = $config->prepare('SELECT * FROM ulasan_produk WHERE id_ulasan = ? FOR UPDATE');
	$reviewQuery->execute(array((int) $reviewId));
	$review = $reviewQuery->fetch(PDO::FETCH_ASSOC);
	if (!$review || $review['status'] !== 'pending') {
		$config->rollBack();
		header('Location: ../../../index.php?page=ulasan&result=invalid');
		exit;
	}
	$update = $config->prepare(
		'UPDATE ulasan_produk SET status = ?, catatan_moderasi = ?, id_member_moderator = ?, tanggal_update = ?
			WHERE id_ulasan = ? AND status = ?'
	);
	$update->execute(array(
		$status,
		$status === 'rejected' ? $note : null,
		(int) $_SESSION['admin']['id_member'],
		date('Y-m-d H:i:s'),
		(int) $reviewId,
		'pending'
	));
	if ($update->rowCount() !== 1) {
		throw new RuntimeException('Review moderation state changed unexpectedly.');
	}
	customer_workflow_notify(
		$config,
		(int) $review['id_pelanggan'],
		(int) $review['id_pesanan'],
		$status === 'approved' ? 'Ulasan dipublikasikan' : 'Ulasan tidak dipublikasikan',
		$status === 'approved'
			? 'Ulasan Anda untuk produk ' . $review['id_barang'] . ' telah ditampilkan.'
			: 'Ulasan Anda untuk produk ' . $review['id_barang'] . ' belum dapat ditampilkan.' . ($note !== '' ? ' Catatan: ' . $note : '')
	);
	customer_workflow_audit(
		$config,
		(int) $_SESSION['admin']['id_member'],
		'Moderate product review',
		'ulasan_produk',
		(int) $reviewId,
		array('status' => 'pending'),
		array('status' => $status, 'catatan' => $note)
	);
	$config->commit();
	header('Location: ../../../index.php?page=ulasan&status=' . $status . '&result=updated');
	exit;
} catch (Throwable $exception) {
	if ($config->inTransaction()) $config->rollBack();
	error_log('Product review moderation failed: ' . $exception->getMessage());
	header('Location: ../../../index.php?page=ulasan&result=error');
	exit;
}
